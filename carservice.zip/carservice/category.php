<?php
cs_get_theme_file("/template-blog.php");
?>
