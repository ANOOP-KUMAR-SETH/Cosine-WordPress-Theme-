<?php
$heading = noo_new_heading();
if( $heading['img'] && !empty($heading['img']) ):
?>


<section class="noo-page-heading" style="background-image: url('<?php echo esc_url($heading['img']) ?>')">
    <div class="noo-container">
        <h1 class="page-title"><?php echo esc_html($heading['title']); ?></h1>
    </div><!-- /.container-boxed -->
</section>

<?php endif; ?>
