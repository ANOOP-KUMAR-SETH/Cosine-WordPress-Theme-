<?php

$blog_name		= get_bloginfo( 'name' );
$blog_desc		= get_bloginfo( 'description' );
$image_logo		= '';
$page_logo		= '';
$status_top     = noo_get_option('noo_header_top_status');
$phone          = noo_get_option('noo_header_top_phone');
$email          = noo_get_option('noo_header_top_email');
$working        = noo_get_option('noo_header_top_working');
$findmap        = noo_get_option('noo_header_top_findmap');
$header_style = noo_get_option('noo_header_nav_style','header3');
if ( noo_get_option( 'noo_header_use_image_logo', true ) ) {
    if ( noo_get_image_option( 'noo_header_logo_image', '' ) !=  '' ) {
        $image_logo = noo_get_image_option( 'noo_header_logo_image', '' );
    }else{
        $image_logo  = esc_attr(NOO_ASSETS_URI. '/images/logo.png');
    }
}
if( is_page() ) {
    $page_logo = noo_get_post_meta(get_the_ID(),'_noo_wp_page_menu_transparent_logo');
    if(!empty( $page_logo ) ){
        $image_logo = wp_get_attachment_url( esc_attr($page_logo) );
    }
    $header_page = noo_get_post_meta(get_the_ID(),'_noo_wp_page_header_style');
    if( !empty( $header_page ) && $header_page != 'header' ){
        $header_style = $header_page;
    }
}
?>
<?php if(is_page_template('page-onepage.php')):?>
    <div class="navbar-wrapper">
        <div class="noo-wrap-menu">
            <div class="noo-container">
                <div class="navbar-header pull-left">
                        <?php if ( is_front_page() ) : echo '<h1 class="sr-only">' . esc_html($blog_name) . '</h1>'; endif; ?>
                        <button data-target=".nav-collapse" class="btn-navbar noo_icon_menu" type="button">
                            <i class="fa fa-bars"></i>
                        </button>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand" title="<?php echo esc_attr($blog_desc); ?>">
                            <?php echo ( $image_logo == '' ) ? $blog_name : '<img class="noo-logo-img noo-logo-normal" src="' . esc_url($image_logo) . '" alt="' . esc_attr($blog_desc) . '">'; ?>
                        </a>
                    </div> <!-- / .nav-header -->
                <nav class="noo-main-menu pull-right">
                    <?php
                    if ( has_nav_menu( 'onepage' ) ) :
                        wp_nav_menu( array(
                            'theme_location'  =>  'onepage',
                            'container'       =>  false,
                            'menu_class'      =>  'nav-collapse navbar-nav nav-onepage'
                        ) );
                    else :
                        echo '<ul class="navbar-nav nav"><li><a href="' . esc_url(admin_url( 'nav-menus.php' )) . '">' . esc_html__( 'No menu assigned!', 'noo-carle' ) . '</a></li></ul>';
                    endif;
                    ?>
                </nav>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="navbar-wrapper">
        <div class="navbar navbar-default" role="navigation">
            <?php if( $status_top != 0 &&  $header_style != 'header5' ): ?>
                <div class="noo-topbar">
                    <div class="noo-container">
                        <ul class="pull-left">
                            <?php if( isset($phone) && !empty($phone) && $header_style != 'header6'): ?>
                                <li>
                                    <a href="tel:<?php echo esc_attr($phone) ?>">
                                        <i class="fa fa-phone"></i>
                                        <?php echo esc_html($phone); ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if( isset($email) && !empty($email) ): ?>
                                <li>
                                    <a href="mailto:<?php echo esc_attr($email) ?>">
                                        <i class="fa fa-envelope-o"></i>
                                        <?php echo esc_html($email); ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if( isset($findmap) && !empty($findmap) && $header_style == 'header6'): ?>
                                <li>
                                    <a href="<?php echo esc_url($findmap); ?>" target="_blank">
                                        <i class="fa fa-location-arrow"></i>
                                        <?php echo esc_html__('Find us on map','noo-carle'); ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                        <ul class="pull-right">
                            <?php if( isset($working) && !empty($working) ): ?>
                                <li>
                                    <a href="#">
                                        <i class="fa fa-clock-o"></i>
                                        <?php echo esc_html($working); ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if( isset($findmap) && !empty($findmap) && $header_style != 'header6'): ?>
                                <li>
                                    <a href="<?php echo esc_url($findmap); ?>" target="_blank">
                                        <i class="fa fa-location-arrow"></i>
                                        <?php echo esc_html__('Find us on map','noo-carle'); ?>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
            <?php if( $header_style == 'header1' || $header_style == 'header3' || $header_style == 'header4' ): ?>
                <div class="noo-nav-header4">
                    <div class="noo-container">
                        <div class="noo-nav-wrap">
                            <div class="navbar-header pull-left">
                                <?php if ( is_front_page() ) : echo '<h1 class="sr-only">' . esc_html($blog_name) . '</h1>'; endif; ?>
                                <button data-target=".nav-collapse" class="btn-navbar noo_icon_menu" type="button">
                                    <i class="fa fa-bars"></i>
                                </button>
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand" title="<?php echo esc_attr($blog_desc); ?>">
                                    <?php echo ( $image_logo == '' ) ? $blog_name : '<img class="noo-logo-img noo-logo-normal" src="' . esc_url($image_logo) . '" alt="' . esc_attr($blog_desc) . '">'; ?>
                                </a>
                            </div> <!-- / .nav-header -->
                            <nav class="pull-right noo-main-menu">
                                <?php
                                if ( has_nav_menu( 'primary' ) ) :
                                    wp_nav_menu( array(
                                        'theme_location' => 'primary',
                                        'container'      => false,
                                        'menu_class'     => 'nav-collapse navbar-nav',
                                        'walker'         => new noo_megamenu_walker
                                    ) );
                                else :
                                    echo '<ul class="navbar-nav nav"><li><a href="' . esc_url(admin_url( 'nav-menus.php' )) . '">' . esc_html__( 'No menu assigned!', 'noo-carle' ) . '</a></li></ul>';
                                endif;
                                ?>
                            </nav>
                        </div>
                    </div>
                </div>
            <?php elseif( $header_style == 'header2' ): ?>
                <!--Start main content header-->
                <div class="noo-container">
                    <div class="noo-nav-wrap">
                        <div class="navbar-header pull-left">
                            <?php if ( is_front_page() ) : echo '<h1 class="sr-only">' . esc_html($blog_name) . '</h1>'; endif; ?>
                            <button data-target=".nav-collapse" class="btn-navbar noo_icon_menu" type="button">
                                <i class="fa fa-bars"></i>
                            </button>
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand" title="<?php echo esc_attr($blog_desc); ?>">
                                <?php echo ( $image_logo == '' ) ? $blog_name : '<img class="noo-logo-img noo-logo-normal" src="' . esc_url($image_logo) . '" alt="' . esc_attr($blog_desc) . '">'; ?>
                            </a>
                        </div> <!-- / .nav-header -->
                        <div class="noo-search-wrap pull-right">
                            <div class="noo-infomation-cart">
                                <ul>
                                    <?php if( isset($phone) && !empty($phone) ): ?>
                                        <li class="phone">
                                            <i class="fa fa-phone"></i>
                                            <a href="tel:<?php echo esc_attr($phone); ?>">
                                                <?php echo esc_html__('Call us now','noo-carle') ?>
                                                <strong><?php echo esc_html($phone); ?></strong>
                                            </a>

                                        </li>
                                    <?php endif; ?>

                                    <?php if( function_exists('noo_minicart') ) echo noo_minicart(); ?>
                                </ul>
                            </div>
                            <?php if( NOO_WOOCOMMERCE_EXIST ): ?>
                                <form  method="get" id="form-header"  action="<?php echo esc_url( home_url( '/'  ) ); ?>">
                                <div class="category-tree">
                                    <div class="category-inner">
                                        <span class="cat_name"><?php echo esc_html__('All categories','noo-carle') ?></span><i class="fa fa-caret-down"></i></div>
                                        <div class="nav-dropdown">
                                            <?php
                                                $args = array(
                                                    'type'                     => 'post',
                                                    'child_of'                 => 0,
                                                    'parent'                   => '0',
                                                    'orderby'                  => 'name',
                                                    'order'                    => 'ASC',
                                                    'hide_empty'               => 1,
                                                    'hierarchical'             => 1,
                                                    'exclude'                  => '',
                                                    'include'                  => '',
                                                    'number'                   => '',
                                                    'taxonomy'                 => 'product_cat',
                                                    'pad_counts'               => false

                                                );
                                                $categories = get_categories( $args );
                                            ?>
                                            <ul>
                                                <?php
                                                    if( isset($categories) && !empty($categories) ):
                                                        echo '<li data-name="'.esc_html__('All categories','noo-carle').'" data-id="">'.esc_html__('All categories','noo-carle').'</li>';
                                                        foreach($categories as $cat):
                                                            echo '<li data-name="'.esc_attr($cat->name).'" data-id="'.esc_attr($cat->term_id).'">'.esc_html($cat->name).'</li>';
                                                        endforeach;

                                                    endif;
                                                ?>
                                            </ul>
                                        </div>
                                </div>

                                <div class="search-input">
                                    <input type="search" class="search_ajax_value" value="" name="s"  autocomplete="off">
                                    <input type="hidden" name="post_type" value="product" />
                                    <i class="fa fa-search icon-search-form"></i>
                                    <img class="ajax_load" alt="ajax_load" src="<?php echo esc_url(NOO_ASSETS_URI.'/images/load.GIF') ; ?>">
                                    <div class="returs_ajax">
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <!--End main content-->
                <div class="noo-wrap-menu noo-wrap-menu2">
                    <div class="noo-container">
                        <nav class="noo-main-menu pull-left">
                            <?php
                            if ( has_nav_menu( 'primary' ) ) :
                                wp_nav_menu( array(
                                    'theme_location'  =>  'primary',
                                    'container'       =>  false,
                                    'menu_class'      =>  'nav-collapse navbar-nav',
                                    'walker'         => new noo_megamenu_walker
                                ) );
                            else :
                                echo '<ul class="navbar-nav nav"><li><a href="' . esc_url(admin_url( 'nav-menus.php' )) . '">' . esc_html__( 'No menu assigned!', 'noo-carle' ) . '</a></li></ul>';
                            endif;
                            ?>
                        </nav>
                        <?php  if ( has_nav_menu( 'categories' ) ) : ?>
                            <nav class="noo-left-menu pull-right">
                                <span class="cate-name">
                                    <i class="fa fa-bars icon-bars"></i>
                                    <?php
                                    $menu_name  =  "categories";
                                    $menu_obj   =  get_term_by( 'name', $menu_name, 'nav_menu' );
                                    $menu_id    =  $menu_obj->term_id;
                                    $menu       =  wp_get_nav_menu_object($menu_id );
                                    echo esc_html($menu->name);
                                    ?>
                                    <i class="fa fa-chevron-down pull-right"></i>
                                </span>
                                <?php
                                    wp_nav_menu( array(
                                        'theme_location'  =>  'categories',
                                        'container'       =>  false,
                                        'menu_class'      =>  'menu-categories'
                                    ) );
                                ?>
                            </nav>
                        <?php   endif; ?>
                    </div>
                </div>

            <?php elseif( $header_style == 'header5' ): ?>

                <!--Start main content header-->
                <div class="noo-container">
                    <div class="noo-nav-wrap">
                        <div class="navbar-header pull-left">
                            <?php if ( is_front_page() ) : echo '<h1 class="sr-only">' . esc_html($blog_name) . '</h1>'; endif; ?>
                            <button data-target=".nav-collapse" class="btn-navbar noo_icon_menu" type="button">
                                <i class="fa fa-bars"></i>
                            </button>
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand" title="<?php echo esc_attr($blog_desc); ?>">
                                <?php echo ( $image_logo == '' ) ? $blog_name : '<img class="noo-logo-img noo-logo-normal" src="' . esc_url($image_logo) . '" alt="' . esc_attr($blog_desc) . '">'; ?>
                            </a>
                        </div> <!-- / .nav-header -->
                        <div class="noo-search-wrap pull-right">
                            <div class="noo-infomation-cart">
                                <ul>
                                    <?php if( isset($phone) && !empty($phone) ): ?>
                                        <li class="phone">
                                            <i class="fa fa-phone"></i>
                                            <a href="tel:<?php echo esc_attr($phone); ?>">
                                                <?php echo esc_html__('Call us now','noo-carle') ?>
                                                <strong><?php echo esc_html($phone); ?></strong>
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                    <?php if( isset($working) && !empty($working) ): ?>
                                        <li class="phone">
                                            <i class="fa fa-clock-o"></i>
                                            <a href="#">
                                                 <?php echo esc_html__('Working hours','noo-carle'); ?>
                                                 <strong><?php echo esc_html($working); ?></strong>
                                            </a>

                                        </li>
                                    <?php endif; ?>

                                    <?php if( function_exists('noo_minicart') ) echo noo_minicart(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!--End main content-->
                <div class="noo-header4-position">
                    <div class="noo-container">
                        <div class="noo-wrap-menu">
                            <nav class="noo-main-menu pull-left">
                                <?php
                                if ( has_nav_menu( 'primary' ) ) :
                                    wp_nav_menu( array(
                                        'theme_location'  =>  'primary',
                                        'container'       =>  false,
                                        'menu_class'      =>  'nav-collapse navbar-nav',
                                        'walker'          => new noo_megamenu_walker
                                    ) );
                                else :
                                    echo '<ul class="navbar-nav nav"><li><a href="' . esc_url(admin_url( 'nav-menus.php' )) . '">' . esc_html__( 'No menu assigned!', 'noo-carle' ) . '</a></li></ul>';
                                endif;
                                ?>
                            </nav>
                            <button class="fa fa-search icon-search2"></button>
                        </div>
                    </div>
                </div>
                <div class="search-header5">
                    <img class="search-remove" src="<?php echo esc_url(NOO_ASSETS_URI.'/images/remove_white.png'); ?>" alt="remove">
                    <?php echo get_search_form(); ?>
                </div>
            <?php elseif( $header_style == 'header6' ): ?>
                <!--Start main content header-->
                <div class="noo-container">
                    <div class="noo-nav-wrap">
                        <div class="noo-row">

                            <div class="noo-md-4">
                                <div class="noo-infomation-cart">
                                    <ul>
                                        <?php if( isset($phone) && !empty($phone) ): ?>
                                            <li class="phone">
                                                <i class="fa fa-phone"></i>
                                                <a href="tel:<?php echo esc_attr($phone); ?>">
                                                    <?php echo esc_html__('Call us now','noo-carle') ?>
                                                    <strong><?php echo esc_html($phone); ?></strong>
                                                </a>

                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>

                            <div class="noo-md-4">
                                <div class="navbar-header">

                                    <?php if ( is_front_page() ) : echo '<h1 class="sr-only">' . esc_html($blog_name) . '</h1>'; endif; ?>
                                    <button data-target=".nav-collapse" class="btn-navbar noo_icon_menu" type="button">
                                        <i class="fa fa-bars"></i>
                                    </button>
                                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="navbar-brand" title="<?php echo esc_attr($blog_desc); ?>">
                                        <?php echo ( $image_logo == '' ) ? $blog_name : '<img class="noo-logo-img noo-logo-normal" src="' . esc_url($image_logo) . '" alt="' . esc_attr($blog_desc) . '">'; ?>
                                    </a>
                                </div> <!-- / .nav-header -->
                            </div>

                            <div class="noo-md-4">
                                <div class="noo-infomation-cart pull-right">
                                    <ul>
                                        <li class="search">
                                            <button class="fa fa-search icon-search2"></button>
                                        </li>
                                        <?php if( function_exists('noo_minicart') ) echo noo_minicart(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!--End main content-->
                <div class="noo-wrap-menu noo-wrap-menu2">
                    <nav class="noo-main-menu">
                        <?php
                        if ( has_nav_menu( 'primary' ) ) :
                            wp_nav_menu( array(
                                'theme_location'  =>  'primary',
                                'container'       =>  false,
                                'menu_class'      =>  'nav-collapse navbar-nav',
                                'walker'          => new noo_megamenu_walker
                            ) );
                        else :
                            echo '<ul class="navbar-nav nav"><li><a href="' . esc_url(admin_url( 'nav-menus.php' )) . '">' . esc_html__( 'No menu assigned!', 'noo-carle' ) . '</a></li></ul>';
                        endif;
                        ?>
                    </nav>
                </div>
                <div class="search-header5">
                    <img class="search-remove" src="<?php echo esc_url(NOO_ASSETS_URI.'/images/remove_white.png'); ?>" alt="remove">
                    <?php echo get_search_form(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>


