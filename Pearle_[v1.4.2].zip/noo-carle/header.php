<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0" />
<!-- Favicon-->
<?php
    if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) :
        $favicon = noo_get_image_option('noo_custom_favicon', '');
        if ($favicon != ''): ?>
        <link rel="shortcut icon" href="<?php echo esc_url($favicon); ?>" />
<?php
        endif;
    endif;
?>
<?php wp_head(); ?>
</head>

<body id="noo_bd" <?php body_class(); ?>>
    <?php if( !is_page_template('page-teamplate-print.php') ): ?>
        <div class="site">
            <?php if(is_page_template('page-onepage.php')):?>
                    <?php
                        $revsl = get_post_meta(get_the_ID(),'_noo_wp_page_slider_rev',true);
                        if( isset($revsl) && !empty($revsl) ):
                    ?>
                        <div class="noo-revo">
                            <?php putRevSlider(esc_attr($revsl)) ?>
                        </div>
                    <?php endif; ?>
                    <header class="noo-header noo-onepage">
                        <?php noo_get_layout('navbar'); ?>
                    </header>
            <?php else: ?>
                    <header class="noo-header <?php noo_header_class(); ?>">
                        <?php noo_get_layout('navbar'); ?>
                    </header>
            <?php endif; ?>

            <?php noo_get_layout( 'heading' ); ?>
    <?php endif; ?>
