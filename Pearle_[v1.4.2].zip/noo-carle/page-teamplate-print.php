<?php
/*
Template Name: Template Print
*/
?>
<?php get_header(); ?>

        <?php
            if( !$_POST && empty($_POST['coupons_id']) ){
                return false;
            }
            $coupont_id = $_POST['coupons_id'];
            if( isset($coupont_id) && !empty($coupont_id) ){
                $new_cou = rtrim($coupont_id, ',');
                $id = explode(',',$new_cou);
            }
            ?>

          <table class="table-print">
              <?php
              $args = array(
                  'post_type'   =>  'coupons',
                  'post__in'    =>    $id
              );
              $query = new WP_Query( $args );
              if( $query->have_posts() ):
                  $i = 0;
                  while( $query->have_posts() ): $query->the_post();
                      if( $i++ % 2 == 0 ):
                          echo '<tr>';
                      endif;
                      ?>
                      <td>
                          <?php the_post_thumbnail('large'); ?>
                      </td>
                      <?php
                        if( $i % 2 == 0 || $i ==  $query->post_count  ):
                            echo '</tr>';
                        endif;
                      ?>
                  <?php
                  endwhile;
              endif; wp_reset_postdata();
              ?>
          </table>
    <script>
        jQuery(window).load(function(){
            window.print();
        })
    </script>
<?php get_footer(); ?>