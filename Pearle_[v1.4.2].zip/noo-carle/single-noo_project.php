
<?php get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main noo-container">
        <div class="noo-row">
            <div class="noo-md-8">
                <?php
                // Start the loop.
                while ( have_posts() ) : the_post();
                    $_attach = noo_get_post_meta(get_the_ID(),'_attach');
                    $_properties = noo_get_post_meta(get_the_ID(),'_properties');
                    $_gallery    = noo_get_post_meta(get_the_ID(),'_gallery');
                    if( isset($_gallery) && !empty($_gallery) ):
                        $_gallery_id = explode(',',$_gallery);
                    ?>
                    <div class="project-slider">
                        <div class="owl-carousel sync1">
                            <?php
                                foreach($_gallery_id as $id ):
                                    echo '<div class="item">';
                                    echo wp_get_attachment_image( esc_attr($id),'full' );
                                    echo '</div>';
                                endforeach;
                            ?>
                        </div>
                        <div class="owl-carousel sync2">
                            <?php
                                foreach($_gallery_id as $id ):
                                    echo '<div class="item">';
                                    echo wp_get_attachment_image( esc_attr($id) );
                                    echo '</div>';
                                endforeach;
                            ?>
                        </div>
                    </div>
                    <?php else:
                        if( has_post_thumbnail() ):
                            the_post_thumbnail('full');
                        endif;
                    ?>
                    <?php endif; ?>

                    <!--Content-->
                    <div class="single-content">
                        <h2 class="project-title"><?php echo esc_html__('project description','noo-carle'); ?></h2>
                        <?php
                        the_content();
                        wp_link_pages();
                        ?>
                    </div>
                    <!--End Content-->

                    <!--Single author-->
                    <div class="single-author-project">
                        <h2 class="project-title"><?php echo esc_html__("Do not hear from us only","noo"); ?></h2>
                        <div class="noo-row">
                            <div class="author-avatar noo-md-2">
                                <?php echo get_avatar( get_the_author_meta( 'user_email' ),100); ?>
                            </div>
                            <div class="author-description noo-md-10">
                                <i class="fa fa-quote-left project-icon"></i>
                                <p>
                                    <?php echo get_the_author_meta('description'); ?>
                                </p>
                                <strong>
                                    <a title="<?php printf( esc_html__( 'Post by %s','noo-carle'), get_the_author() ); ?>" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author">
                                        <?php echo get_the_author() ?>
                                    </a>
                                </strong>
                            </div>
                        </div>
                    </div>
                    <!--End single author-->

                    <!--Start navigation-->
                    <nav class="single-navigation">
                        <span class="s-prev"><?php  echo get_previous_post_link( '<i class="fa fa-long-arrow-left"></i> %link', _x( '%title', 'Previous post link', 'noo-carle' ) ); ?></span>
                        <span class="s-next"><?php  echo get_next_post_link( '%link', _x( '%title <i class="fa fa-long-arrow-right"></i>', 'Next post link', 'noo-carle' ) ); ?></span>
                    </nav>
                    <!--End navigation-->

                    <?php
                    // End the loop.
                endwhile;
                ?>
            </div>
            <div class="noo-md-4">
                <div class="project-sidebar-inner">
                    <h3 class="project-sidebar-title"><?php esc_html_e('project info','noo-carle'); ?></h3>
                    <ul class="info">
                        <?php if( isset($_properties) && !empty($_properties) ):
                                foreach($_properties as $propre):
                            ?>
                                <li>
                                   <span>
                                         <?php echo esc_html($propre['label']) ?>
                                   </span>
                                    <?php echo esc_html($propre['value']) ?>
                                </li>
                                <?php endforeach; ?>
                       <?php endif; ?>
                        <li class="social">
                           <span>
                                <?php echo esc_html__('Share','noo-carle'); ?>
                           </span>
                            <?php noo_social_share(); ?>
                        </li>
                    </ul>
                </div>
                <?php if( isset($_attach) && !empty($_attach) ): ?>
                    <div class="project-sidebar-inner">
                        <h3 class="project-sidebar-title"><?php esc_html_e('Download ','noo-carle'); ?></h3>
                        <ul class="download">
                            <?php foreach($_attach as $att):  ?>
                                <li>
                                    <a href="<?php echo esc_url($att['value']); ?>">
                                        <i class="fa fa-file-pdf-o"></i>
                                        <span><?php echo esc_html($att['label']); ?></span>
                                        <i class="fa  fa-download icon-download"></i>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php
                    $cat = get_the_terms(get_the_ID(),'project_category');
                        if( isset($cat[0]) && !empty($cat[0]) ):

                            $args = array(
                                'post_type'         =>  'noo_project',
                                'posts_per_page'    =>  10,
                                'post__not_in'      =>  array(get_the_ID()),
                                'tax_query'       =>  array(
                                    array(
                                        'taxonomy'     =>  'project_category',
                                        'field'        =>  'term_id',
                                        'terms'         =>  $cat[0]->term_id
                                    )
                                )
                            );
                            $query = new WP_Query( $args );
                            if( $query->have_posts() ):

                ?>
                    <div class="project-sidebar-inner">
                        <h3 class="project-sidebar-title">
                            <button class="projects-prev">
                                <i class="fa fa-long-arrow-left"></i>
                            </button>
                            <?php esc_html_e('related projects','noo-carle'); ?>
                            <button class="projects-next">
                                <i class="fa fa-long-arrow-right"></i>
                            </button>
                        </h3>
                        <?php
                        echo '<ul class="related_projects">';
                        while( $query->have_posts() ):
                        $query->the_post();
                        ?>
                            <li>
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('noo-thumbnail-square'); ?>
                                </a>
                                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                            </li>
                        <?php
                        endwhile;
                        echo '</ul>';
                        ?>
                        <script>
                            jQuery(document).ready(function(){
                                jQuery('.related_projects').each(function(){
                                    jQuery(this).owlCarousel({
                                        items : 1,
                                        itemsDesktop : [1199,1],
                                        itemsDesktopSmall : [979,1],
                                        itemsTablet: [768, 1],
                                        itemsMobile: [479, 1],
                                        slideSpeed:500,
                                        paginationSpeed:1000,
                                        rewindSpeed:1000,
                                        autoHeight: false,
                                        addClassActive: true,
                                        autoPlay: false,
                                        loop:true,
                                        pagination: false
                                    });
                                    var $_parent = jQuery(this);
                                    $_parent.parent().parent().find('.projects-prev').click(function(){
                                        $_parent.trigger('owl.prev');
                                    }) ;
                                    $_parent.parent().parent().find('.projects-next').click(function(){
                                        $_parent.trigger('owl.next');
                                    }) ;
                                });
                            });
                        </script>
                    </div>

                <?php
                        endif;
                    wp_reset_postdata();
                endif;
                ?>
            </div>
        </div>


    </main><!-- .site-main -->
</div><!-- .content-area -->


<?php get_footer(); ?>