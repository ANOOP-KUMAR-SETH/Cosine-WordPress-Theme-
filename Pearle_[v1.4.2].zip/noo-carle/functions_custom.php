<?php


/* =============================================================================
 *
 * Function for specific theme, remember to keep all the functions
 * specified for this theme inside this file.
 *
 * ============================================================================*/


// Define theme specific constant
if (!defined('NOO_THEME_NAME'))
{
  define('NOO_THEME_NAME', 'noo-');
}

if (!defined('NOO_THEME_VERSION'))
{
  define('NOO_THEME_VERSION', '0.0.1');
}

function noo_relative_time($a=''){
    return human_time_diff($a, current_time( 'timestamp' ));
}
function noo_list_comments($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    GLOBAL $post;
    $avatar_size = isset($args['avatar_size']) ? $args['avatar_size'] : 60;
    ?>
        <li id="li-comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
            <div class="comment-wrap">
                <div class="comment-img">
                    <?php echo get_avatar($comment, $avatar_size); ?>
                </div>
                <article id="comment-<?php comment_ID(); ?>" class="comment-block">
                    <header class="comment-header">
                        <cite class="comment-author"><?php echo get_comment_author_link(); ?> 
                            <?php if ($comment->user_id === $post->post_author): ?>
                            <span class="ispostauthor">
                                <?php esc_html_e('Author', 'noo-carle'); ?>
                            </span>
                            <?php endif; ?>
                        </cite>
                        <div class="comment-meta">
                            <span class="time">
                                <?php echo sprintf(esc_html__('%1$s ago', 'noo-carle') , esc_html(noo_relative_time(get_comment_date('U')))); ?>
                            </span>
                            <span class="comment-edit">
                                <?php edit_comment_link('' . esc_html__('Edit', 'noo-carle')); ?>
                            </span>
                        </div>
                        <?php if ('0' == $comment->comment_approved): ?>
                            <p class="comment-pending"><?php esc_html_e('Your comment is awaiting moderation.', 'noo-carle'); ?></p>
                        <?php endif; ?>
                    </header>
                    <section class="comment-content">
                        <?php comment_text(); ?>
                    </section>
                    <span class="comment-reply">
                        <?php comment_reply_link(array_merge($args, array(
                            'reply_text' => (wp_kses(__('<i class="fa fa-reply"></i> Reply', 'noo-carle') . '',noo_allowed_html())) ,
                            'depth' => $depth,
                            'max_depth' => $args['max_depth']
                        ))); ?>
                    </span>
                </article>
            </div>
        <?php
}

function noo_comment_form( $args = array(), $post_id = null ) {
    global $id;
    $user = wp_get_current_user();
    $user_identity = $user->exists() ? $user->display_name : '';

    if ( null === $post_id ) {
        $post_id = $id;
    }
    else {
        $id = $post_id;
    }

    if ( comments_open( $post_id ) ) :
    ?>
    <div id="respond-wrap">
        <?php 
            $commenter = wp_get_current_commenter();
            $req = get_option( 'require_name_email' );
            $aria_req = ( $req ? " aria-required='true'" : '' );
            $fields =  array(
                'author' => '<div class="noo-row"><p class="comment-form-author  noo-sm-6"><input id="author" name="author" type="text" placeholder="' . esc_html__( 'Enter Your Name*', 'noo-carle' ) . '" class="form-control" value="' . esc_attr( $commenter['comment_author'] ) . '" size="30"' . $aria_req . ' /></p>',
                'email' => '<p class="comment-form-email noo-sm-6"><input id="email" name="email" type="text" placeholder="' . esc_html__( 'Enter Your Email*', 'noo-carle' ) . '" class="form-control" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size="30"' . $aria_req . ' /></p>',
                'comment_field'        => '<div class="noo-sm-12"><p class="comment-form-comment"><textarea class="form-control" placeholder="' . esc_html__( 'Enter Your Comment', 'noo-carle' ) . '" id="comment" name="comment" cols="40" rows="6" aria-required="true"></textarea></p></div></div>'
            );
            $comments_args = array(
                    'fields'               => apply_filters( 'comment_form_default_fields', $fields ),
                    'logged_in_as'         => '<p class="logged-in-as">' . sprintf( wp_kses(__( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'noo-carle' ),noo_allowed_html()), admin_url( 'profile.php' ), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( ) ) ) )
                        . '</p>',
                    'title_reply'          => sprintf('<span>%s</span>',esc_html__( 'Leave your thought', 'noo-carle' )),
                    'title_reply_to'       => sprintf('<span>%s</span>',esc_html__( 'Leave a reply to %s', 'noo-carle' )),
                    'cancel_reply_link'    => esc_html__( 'Click here to cancel the reply', 'noo-carle' ),
                    'comment_notes_before' => '',
                    'comment_notes_after'  => '',
                    'label_submit'         => esc_html__( 'Post Comments', 'noo-carle' ),
                    'comment_field'        =>'',
                    'must_log_in'          => ''
            );
            if(is_user_logged_in()){
                $comments_args['comment_field'] = '<p class="comment-form-comment"><textarea class="form-control" placeholder="' . esc_html__( 'Enter Your Comment', 'noo-carle' ) . '" id="comment" name="comment" cols="40" rows="6" aria-required="true"></textarea></p>';
            }
        comment_form($comments_args); 
        ?>
    </div>

    <?php
    endif;
}

function noo_post_nav() {
    global $post;

    // Don't print empty markup if there's nowhere to navigate.
    $previous = ( is_attachment() ) ? get_post( $post->post_parent ) : get_adjacent_post( false, '', true );
    $next     = get_adjacent_post( false, '', false );

    if ( ! $next && ! $previous )
        return;
    ?>
    <?php $prev_link = get_previous_post_link( '%link', _x( '%title', 'Previous post link', 'noo-carle' ) ); ?>
    <?php $next_link = get_next_post_link( '%link', _x( '%title', 'Next post link', 'noo-carle' ) ); ?>
    <nav class="post-navigation<?php echo( (!empty($prev_link) || !empty($next_link) ) ? ' post-navigation-line':'' )?>" role="navigation">     
        <?php if($prev_link):?>
            <div class="prev-post">
                <h5>
                    <i class="fa fa-angle-double-left">&nbsp;</i>
                    <?php echo esc_html($prev_link);?>
                </h5>
            </div>
        <?php endif;?>
                
        <?php if(!empty($next_link)):?>
            <div class="next-post">
                <h5>
                    <i class="fa fa-angle-double-right">&nbsp;</i>
                    <?php echo esc_html($next_link);?>
                </h5>
            </div>
        <?php endif;?>
    </nav>
    <?php
}

function noo_excerpt_read_more( $more ) {
    return '';
}
add_filter( 'excerpt_more', 'noo_excerpt_read_more' );

function noo_content_read_more( $more ) {
    return '';
}

add_filter( 'the_content_more_link', 'noo_content_read_more' );



function _utf8_4byte_to_3byte( $input ) {
         
    if (!empty($input)) {
        $utf8_2byte = 0xC0 /*1100 0000*/; $utf8_2byte_bmask = 0xE0 /*1110 0000*/;
        $utf8_3byte = 0xE0 /*1110 0000*/; $utf8_3byte_bmask = 0XF0 /*1111 0000*/;
        $utf8_4byte = 0xF0 /*1111 0000*/; $utf8_4byte_bmask = 0xF8 /*1111 1000*/;

        $sanitized = "";
        $len = strlen($input);
        for ($i = 0; $i < $len; ++$i) {
            $mb_char = $input[$i]; // Potentially a multibyte sequence
            $byte = ord($mb_char);
            if (($byte & $utf8_2byte_bmask) == $utf8_2byte) {
                $mb_char .= $input[++$i];
            }
            else if (($byte & $utf8_3byte_bmask) == $utf8_3byte) {
                $mb_char .= $input[++$i];
                $mb_char .= $input[++$i];
            }
            else if (($byte & $utf8_4byte_bmask) == $utf8_4byte) {
                // Replace with ? to avoid MySQL exception
                $mb_char = '?';
                $i += 3;
            }

            $sanitized .=  $mb_char;
        }

        $input= $sanitized;
    }

    return $input;
}



if ( ! function_exists( 'noo_entry_meta' ) ) :
    /**
     * Prints HTML with meta information for the categories, tags.
     *
     * @since Twenty Fifteen 1.0
     */
    function noo_entry_meta() {

        printf( '<span class="posted-on"><i class="fa fa-calendar"></i><a href="%1$s" rel="bookmark">%2$s</a></span>',
            esc_url( get_permalink() ),
            get_the_date()
        );
        if ( 'post' == get_post_type() ) {
            printf( '<span class="author vcard"><i class="fa fa-user"></i><a class="url fn n" href="%1$s">%2$s</a></span>',
                esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                get_the_author()
            );
            $categories_list = get_the_category_list( ', ' );
            if ( $categories_list) {
                printf( '<span class="cat-links"><i class="fa fa-briefcase"></i>%1$s</span>',
                    $categories_list
                );
            }
            $tags_list = get_the_tag_list( '', ', ' );
            if ( $tags_list ) {
                printf( '<span class="tags-links"><i class="fa fa-tags"></i>%1$s</span>',
                    $tags_list
                );
            }
        }

        if ( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
            echo '<span class="comments-link"><i class="fa fa-comments"></i>';
            comments_popup_link( esc_html__( 'Leave a comment', 'noo-carle' ), esc_html__( '1 Comment', 'noo-carle' ), esc_html__( '% Comments', 'noo-carle' ) );
            echo '</span>';
        }
    }

endif;