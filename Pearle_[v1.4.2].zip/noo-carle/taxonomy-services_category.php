<?php
/**
 * The main template file
 *
 */

get_header(); ?>
<div class="services-header"></div>
<div id="primary" class="content-area">
    <main id="main" class="site-main noo-container">

            <?php if ( have_posts() ) : ?>
                <?php
                // Start the loop.
                while ( have_posts() ) : the_post();
                    /*
                     * Include the Post-Format-specific template for the content.
                     * If you want to override this in a child theme, then include a file
                     * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                     */
                    ?>

                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                        <!--Start featured-->
                        <?php if( noo_has_featured_content()) : ?>
                            <div class="content-featured">
                                <a href="<?php the_permalink() ?>">
                                    <?php the_post_thumbnail('large') ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        <!--Start end featured-->

                        <!--Start content for post-->
                        <div class="entry-content-wrap">
                            <div class="author-avatar">
                                <?php echo get_avatar( get_the_author_meta( 'user_email' ),70); ?>
                                <h5>
                                    <?php echo get_the_author() ?>
                                </h5>
                                <?php noo_author_blog_social(); ?>

                            </div>
                            <div class="entry-content">
                                <h2>
                                    <a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permanent link to: "%s"','noo-carle' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php the_title(); ?></a>
                                </h2>

                                <!--Start content-->
                                <div class="entry-excerpt">
                                    <?php if(get_the_excerpt()):?>
                                        <?php the_excerpt(); ?>
                                    <?php endif;?>
                                </div>
                                <!--Start end content-->

                            </div>
                        </div>
                        <!--End content for post-->

                    </article> <!-- /#post- -->
                    <?php

                    // End the loop.
                endwhile;
            endif;
            ?>

    </main><!-- .site-main -->
</div><!-- .content-area -->

<?php get_footer(); ?>
