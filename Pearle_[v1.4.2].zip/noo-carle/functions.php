<?php
/**
 * Theme functions for NOO Framework.
 * This file include the framework functions, it should remain intact between themes.
 * For theme specified functions, see file functions-<theme name>.php
 *
 * @package    NOO Framework
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */

// Set global constance


if ( !defined( 'NOO_ASSETS' ) ) {
	define( 'NOO_ASSETS', get_template_directory() . '/assets' );
}

if ( !defined( 'NOO_ASSETS_URI' ) ) {
	define( 'NOO_ASSETS_URI', get_template_directory_uri() . '/assets' );
}

if ( !defined( 'NOO_VENDOR' ) ) {
	define( 'NOO_VENDOR', NOO_ASSETS . '/vendor' );
}

if ( !defined( 'NOO_VENDOR_URI' ) ) {
	define( 'NOO_VENDOR_URI', NOO_ASSETS_URI . '/vendor' );
}

define( 'NOO_INCLUDES', get_template_directory() . '/includes' );
define( 'NOO_INCLUDES_URI', get_template_directory_uri() . '/includes' );
define( 'NOO_FUNCTIONS', NOO_INCLUDES . '/functions' );

define( 'NOO_POST_TYPE', NOO_INCLUDES . '/post_type' );
define( 'NOO_POST_TYPE_URI', NOO_INCLUDES_URI . '/post_type' );

define( 'NOO_FRAMEWORK', NOO_INCLUDES . '/framework' );
define( 'NOO_FRAMEWORK_URI', NOO_INCLUDES_URI . '/framework' );

define( 'NOO_ADMIN_ASSETS', NOO_INCLUDES . '/admin_assets' );
define( 'NOO_ADMIN_ASSETS_URI', NOO_INCLUDES_URI . '/admin_assets' );

// Functions for specific theme
$theme_name = basename(dirname(__FILE__));

if ( !defined( 'NOO_THEME_NAME' ) ) {
	define( 'NOO_THEME_NAME', $theme_name );
}

define( 'NOO_WOOCOMMERCE_EXIST', class_exists( 'WC_API' ) );
define( 'NOO_SUPPORT_PORTFOLIO', false );

// Functions for specific theme
if ( file_exists( get_template_directory() . '/functions_custom.php' ) ) {
	require_once get_template_directory() . '/functions_custom.php';
}

// Theme setup
require_once NOO_INCLUDES . '/theme_setup.php';

//
// Init Framework.
//
require_once NOO_FRAMEWORK . '/_init.php';

//
// Enqueue assets
//
require_once NOO_FUNCTIONS . '/noo-enqueue-css.php';
require_once NOO_FUNCTIONS . '/noo-enqueue-js.php';

// Helper functions
require_once NOO_FUNCTIONS . '/noo-html.php';
require_once NOO_FUNCTIONS . '/noo-utilities.php';
require_once NOO_FUNCTIONS . '/noo-style.php';
require_once NOO_FUNCTIONS . '/noo-wp-style.php';
require_once NOO_FUNCTIONS . '/noo-mailchimp.php';
require_once NOO_FUNCTIONS . '/noo-user.php';



// Mega Menu
require_once NOO_INCLUDES . '/mega-menu/noo_mega_menu.php';

// WooCommerce

 require_once NOO_INCLUDES . '/woocommerce.php';

//
// Widgets
//
$widget_path = get_template_directory() . '/widgets';

if ( file_exists( $widget_path . '/widgets_init.php' ) ) {
	require_once $widget_path . '/widgets_init.php';
	require_once $widget_path . '/widgets.php';
}

add_action('wp_ajax_noo_team_detail','noo_team_detail');
add_action('wp_ajax_nopriv_noo_team_detail','noo_team_detail');
function noo_team_detail(){
    ?>
        <div class="noo-team-content">
            <button class="team-remove fa fa-close"></button>
            <?php
            $id = $_POST['id'];
            $args = array(
                'post_type'     =>  'team_member',
                'p'             =>  $id
            );
            $query = new WP_Query( $args );
            if( $query->have_posts() ):
                while( $query->have_posts() ):
                    $query->the_post();
                    $image       = noo_get_post_meta(get_the_ID(),'_noo_wp_team_image');
                    $name        = get_post_meta(get_the_ID(),'_noo_wp_team_name', true);
                    $position    = get_post_meta(get_the_ID(),'_noo_wp_team_position', true);

                    $phone         = noo_get_post_meta(get_the_ID(),'_noo_wp_team_phone');
                    $email         = get_post_meta(get_the_ID(),'_noo_wp_team_email', true);
                    $experience    = get_post_meta(get_the_ID(),'_noo_wp_team_experience', true);

                    $facebook    = get_post_meta(get_the_ID(),'_noo_wp_team_facebook', true);
                    $twitter     = get_post_meta(get_the_ID(),'_noo_wp_team_twitter', true);
                    $google      = get_post_meta(get_the_ID(),'_noo_wp_team_google', true);
                    $linkedin    = get_post_meta(get_the_ID(),'_noo_wp_team_linkedin', true);
                    $flickr      = get_post_meta(get_the_ID(),'_noo_wp_team_flickr', true);
                    $pinterest   = get_post_meta(get_the_ID(),'_noo_wp_team_pinterest', true);
                    $instagram   = get_post_meta(get_the_ID(),'_noo_wp_team_instagram', true);
                    $tumblr      = get_post_meta(get_the_ID(),'_noo_wp_team_tumblr', true);

                    $sp_description      = get_post_meta(get_the_ID(),'_noo_wp_team_sp_description', true);
                    $sp_properties      = get_post_meta(get_the_ID(),'_team_properties', true);

                    $certificates      = get_post_meta(get_the_ID(),'_noo_wp_team_certificates_description', true);

                    ?>
                    <div class="team-left">
                        <div class="noo-team-image">
                            <?php if( isset($image) && !empty($image) ):
                                echo wp_get_attachment_image(esc_attr($image),'full');
                            endif; ?>
                        </div>
                        <div class="noo-team-info">
                            <h4 class="team_name"><?php echo esc_html($name); ?></h4>
                            <span class="team_position"><?php echo esc_html($position); ?></span>
                        </div>
                    </div>
                    <div class="team-right">
                        <div class="team-contact">
                            <h6 class="team-title"><?php echo esc_html__('Contact','noo-carle'); ?></h6>
                            <ul>
                                <li>
                                    <i class="fa fa-phone"></i>
                                    <span class="team-phone"><?php echo esc_html($phone); ?></span>
                                </li>
                                <li>
                                    <i class="fa fa-envelope"></i>
                                    <a class="team-email"><?php echo esc_html($email); ?></a>
                                </li>
                                <li>
                                    <i class="fa fa-suitcase"></i>
                                    <?php echo esc_html($experience); ?>
                                </li>
                            </ul>
                            <div class="team_socials">
                                <?php if( isset($facebook) && $facebook !='' ): ?>
                                    <a href="<?php echo esc_url($facebook) ?>" class="fa fa-facebook"></a>
                                <?php endif; ?>
                                <?php if( isset($twitter) && $twitter !='' ): ?>
                                    <a href="<?php echo esc_url($twitter) ?>" class="fa fa-twitter"></a>
                                <?php endif; ?>
                                <?php if( isset($google) && $google !='' ): ?>
                                    <a href="<?php echo esc_url($google) ?>" class="fa fa-google-plus"></a>
                                <?php endif; ?>
                                <?php if( isset($linkedin) && $linkedin !='' ): ?>
                                    <a href="<?php echo esc_url($linkedin) ?>" class="fa fa-linkedin"></a>
                                <?php endif; ?>
                                <?php if( isset($flickr) && $flickr !='' ): ?>
                                    <a href="<?php echo esc_url($flickr) ?>" class="fa fa-flickr"></a>
                                <?php endif; ?>
                                <?php if( isset($pinterest) && $pinterest !='' ): ?>
                                    <a href="<?php echo esc_url($pinterest) ?>" class="fa fa-pinterest"></a>
                                <?php endif; ?>
                                <?php if( isset($instagram) && $instagram !='' ): ?>
                                    <a href="<?php echo esc_url($instagram) ?>" class="fa fa-instagram"></a>
                                <?php endif; ?>
                                <?php if( isset($tumblr) && $tumblr !='' ): ?>
                                    <<a href="<?php echo esc_url($tumblr) ?>" class="fa fa-tumblr"></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="team-specialty">
                            <h6 class="team-title"><?php echo esc_html__('SPECIALTY','noo-carle'); ?></h6>
                            <p>
                                <?php echo esc_html($sp_description); ?>
                            </p>

                            <?php

                            if( isset($sp_properties) && !empty($sp_properties) ):
                                echo '<div class="team-specialty-attr">';
                                $i = 0;
                                foreach ( (array) $sp_properties as $properties ) {
                                    if( $i++ % 3 == 0 ): ?>
                                        <ul>
                                    <?php endif; ?>
                                    <li><?php echo esc_html($properties); ?></li>
                                    <?php if( $i % 3 == 0 || $i == count($sp_properties)  ): ?>
                                        </ul>
                                    <?php endif;
                                }
                                echo '</div>';
                            endif;

                            ?>
                        </div>
                        <div class="team-certificates">
                            <h6 class="team-title"><?php echo esc_html__('Certificates','noo-carle'); ?></h6>
                            <p>
                                <?php echo esc_html($certificates); ?>
                            </p>

                        </div>
                    </div>
                <?php
                endwhile;
            endif;
            wp_reset_postdata();
            ?>
        </div>
    <?php
    exit();
}

add_action('wp_ajax_noo_project_slider','noo_project_slider');
add_action('wp_ajax_nopriv_noo_project_slider','noo_project_slider');
function noo_project_slider(){
    $catid = $_POST['catid'];
    $limit = $_POST['limit'];
    $args = array(
        'post_type'     =>  'noo_project',
        'limit'         =>  $limit,
        'order'         =>  'ASC'
    );
    if( $catid != 'all' ){
        $args['tax_query'][] = array(
            'taxonomy'  =>  'project_category',
            'field'     =>  'term_id',
            'terms'   =>  array($catid)
        );
    }
    $query = new WP_Query( $args );
    ?>
        <ul class="noo-project-slider">
            <?php
            $query = new WP_Query($args);
            if( $query->have_posts() ): ?>
                <?php  while( $query->have_posts() ): $query->the_post();
                    ?>
                    <li>
                        <div class="project-item">
                           <div class="project-inner">
                               <a href="<?php the_permalink() ?>" class="project-bk">
                                   <?php the_post_thumbnail('noo-thumbnail-square') ?>
                               </a>
                               <div class="project-ds">
                                   <span class="cat"><?php the_terms(get_the_ID(),'project_category'); ?></span>
                                   <h3><?php the_title(); ?></h3>
                               </div>
                           </div>
                        </div>
                    </li>
                <?php endwhile; ?>
            <?php endif; wp_reset_postdata(); ?>
        </ul>
    <?php
    exit();
}