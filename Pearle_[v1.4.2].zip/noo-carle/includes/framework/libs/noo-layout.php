<?php
/**
 * Utilities Functions for NOO Framework.
 * This file contains various functions for getting and preparing data.
 *
 * @package    NOO Framework
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */

if (!function_exists('noo_get_page_layout')):
	function noo_get_page_layout() {
		$layout = 'fullwidth';

		// Normal Page or Static Front Page
		if (is_page() || (is_front_page() && get_option('show_on_front') == 'page')) {

			// WP page,
			// get the page template setting
			$page_id = get_the_ID();
			$page_template = noo_get_post_meta($page_id, '_wp_page_template', 'default');

			if (strpos($page_template, 'sidebar') !== false) {
				if (strpos($page_template, 'left') !== false) {
					$layout = 'left_sidebar';
				}
				
				$layout = 'sidebar';
			}

		}
        // Single post page
        if (is_single()) {

            // WP post,
            // check if there's overrode setting in this post.
            $post_id = get_the_ID();
            $override_setting = noo_get_post_meta(get_the_ID(),'_noo_wp_post_override_layout',0);

            if ( isset($override_setting) && $override_setting == 1 ) {

                // overrode
                $layout = noo_get_post_meta($post_id, '_noo_wp_post_layout');

            }else{
                $post_layout = noo_get_option('noo_blog_post_layout','same_as_blog');

                if ($post_layout == 'same_as_blog') {
                    $post_layout = noo_get_option('noo_blog_layout');
                }
                $layout = $post_layout;
            }



        }

        // Index or Home
        if (is_home() || is_category() || is_tag() || is_date() || (is_front_page() && get_option('show_on_front') == 'posts')) {
            $layout = noo_get_option('noo_blog_layout', 'sidebar');

        }

		// WooCommerce
		if( NOO_WOOCOMMERCE_EXIST ) {

			if( is_shop() || is_product_category() || is_product_tag() ){
				$layout = noo_get_option('noo_shop_layout', 'fullwidth');

			}

			if( is_product() ) {

				$product_layout = noo_get_option('noo_woocommerce_product_layout', 'same_as_shop');
                $layout = $product_layout;
				if ($product_layout == 'same_as_shop') {
                    $layout = noo_get_option('noo_shop_layout', 'fullwidth');

				}

			}


		}

		global $noo_post_types;
		if( !empty( $noo_post_types ) ) {
			foreach ($noo_post_types as $post_type => $args) {
				if( noo_is_archive( $post_type ) ) {
					if( isset( $args['customizer'] ) ) {
						if( in_array( 'layout', $args['customizer'] ) || in_array( 'list-layout', $args['customizer'] ) ) {
							$layout = noo_get_option("{$post_type}_archive_layout");
						}
					}

					break;
				}
				
				if( is_singular( $post_type ) ) {
					if( isset( $args['customizer'] ) ) {
						if( in_array( 'single-layout', $args['customizer'] ) ) {
							$layout = noo_get_option("{$post_type}_single_layout");
						}

						if( $layout == 'same_as_archive' ) {
							if( in_array( 'layout', $args['customizer'] ) || in_array( 'list-layout', $args['customizer'] ) ) {
								$layout = noo_get_option("{$post_type}_archive_layout");
							} else {
								$layout = 'fullwidth';
							}
						}
					}

					break;
				}
			}

		}
		


        return apply_filters( 'noo_page_layout', $layout );
	}
endif;

if(!function_exists('noo_is_fullwidth')){
	function noo_is_fullwidth(){
		return noo_get_page_layout() == 'fullwidth';
	}
}

if (!function_exists('noo_is_one_page_enabled')):
	function noo_is_one_page_enabled() {
		if( (is_front_page() && get_option('show_on_front' == 'page')) || is_page()) {
			$page_id = get_the_ID();
			return ( noo_get_post_meta( $page_id, '_noo_wp_page_enable_one_page', false ) );
		}

		return false;
	}
endif;

if (!function_exists('noo_get_one_page_menu')):
	function noo_get_one_page_menu() {
		if( noo_is_one_page_enabled() ) {
			if( (is_front_page() && get_option('show_on_front' == 'page')) || is_page()) {
				$page_id = get_the_ID();
				return noo_get_post_meta( $page_id, '_noo_wp_page_one_page_menu', '' );
			}
		}

		return '';
	}
endif;

if (!function_exists('noo_has_home_slider')):
	function noo_has_home_slider() {
		if (class_exists( 'RevSlider' )) {
			if( (is_front_page() && get_option('show_on_front' == 'page')) || is_page()) {
				$page_id = get_the_ID();
				return ( noo_get_post_meta( $page_id, '_noo_wp_page_enable_home_slider', false ) )
					&& ( noo_get_post_meta( $page_id, '_noo_wp_page_slider_rev', '' ) != '' );
			}
		}

		return false;
	}
endif;

if (!function_exists('noo_get_sidebar_id')):
	function noo_get_sidebar_id() {
		$sidebar = '';

		// Normal Page or Static Front Page
		if ( is_page() || (is_front_page() && get_option('show_on_front') == 'page') ) {
			// Get the sidebar setting from
			$sidebar = noo_get_post_meta(get_the_ID(), '_noo_wp_page_sidebar', '');
		}
        // Single post page
        if (is_single()) {
            // Check if there's overrode setting in this post.
            $post_id = get_the_ID();
            $override_setting = noo_get_post_meta($post_id, '_noo_wp_post_override_layout', false);
            if ($override_setting) {
                // overrode
                $overrode_layout = noo_get_post_meta($post_id, '_noo_wp_post_layout', 'fullwidth');
                if ($overrode_layout != 'fullwidth') {
                    $sidebar = noo_get_post_meta($post_id, '_noo_wp_post_sidebar', 'sidebar-main');
                }
            } else{

                $post_layout = noo_get_option('noo_blog_post_layout', 'same_as_blog');
                $sidebar = '';
                if ($post_layout == 'same_as_blog') {
                    $post_layout = noo_get_option('noo_blog_layout', 'sidebar');
                    $sidebar = noo_get_option('noo_blog_sidebar', 'sidebar-main');
                } else {
                    $sidebar = noo_get_option('noo_blog_post_sidebar', 'sidebar-main');
                }

                if($post_layout == 'fullwidth'){
                    $sidebar = '';
                }
            }
        }

        // Archive, Index or Home
        if (is_home() || is_category() || is_date() || is_tag()  || (is_front_page() && get_option('show_on_front') == 'posts')) {

            $blog_layout = noo_get_option('noo_blog_layout', 'sidebar');
            if ($blog_layout != 'fullwidth') {
                $sidebar = noo_get_option('noo_blog_sidebar', 'sidebar-main');
            }
        }
		// WooCommerce Product
		if( NOO_WOOCOMMERCE_EXIST ) {
			if( is_product() ) {
				$product_layout = noo_get_option('noo_woocommerce_product_layout', 'same_as_shop');
				$sidebar = '';
				if ( $product_layout == 'same_as_shop' ) {
					$product_layout = noo_get_option('noo_shop_layout', 'fullwidth');
					$sidebar = noo_get_option('noo_shop_sidebar', '');
				} else {
					$sidebar = noo_get_option('noo_woocommerce_product_sidebar', '');
				}
				
				if ( $product_layout == 'fullwidth' ) {
					$sidebar = '';
				}
			}

			// Shop, Product Category, Product Tag, Cart, Checkout page
			if( is_shop() || is_product_category() || is_product_tag() ) {
				$shop_layout = noo_get_option('noo_shop_layout', 'fullwidth');
				if($shop_layout != 'fullwidth'){
					$sidebar = noo_get_option('noo_shop_sidebar', '');
				}
			}
		}

		global $noo_post_types;
		if( !empty( $noo_post_types ) ) {
			foreach ($noo_post_types as $post_type => $args) {
				if( noo_is_archive( $post_type ) ) {
					if( isset( $args['customizer'] ) ) {
						if( in_array( 'layout', $args['customizer'] ) || in_array( 'list-layout', $args['customizer'] ) ) {
							$layout = noo_get_option("{$post_type}_archive_layout", 'fullwidth');
							if( $layout != 'fullwidth' ) {
								$sidebar = noo_get_option("{$post_type}_archive_sidebar", 'sidebar-main');
							}
						}
					}

					break;
				}
				
				if( is_singular( $post_type ) ) {
					if( isset( $args['customizer'] ) ) {
						if( in_array( 'single-layout', $args['customizer'] ) ) {
							$layout = noo_get_option("{$post_type}_single_layout");
							if( $layout != 'fullwidth' ) {
								$sidebar = noo_get_option("{$post_type}_single_sidebar", 'sidebar-main');
							}
						}

						if( $layout == 'same_as_archive' ) {
							if( in_array( 'layout', $args['customizer'] ) || in_array( 'list-layout', $args['customizer'] ) ) {
								$sidebar = noo_get_option("{$post_type}_archive_sidebar", 'sidebar-main');
							}
						}
					}

					break;
				}
			}
		}
		

		
		return apply_filters( 'noo_sidebar_id', $sidebar );
	}
endif;

if (!function_exists('smk_get_all_sidebars')):
	function smk_get_all_sidebars() {
		global $wp_registered_sidebars;
		$sidebars = array();
		$none_sidebars = array();
		for ($i = 1;$i <= 4;$i++) {
			$none_sidebars[] = "noo-top-{$i}";
			$none_sidebars[] = "noo-footer-{$i}";
		}
		if ($wp_registered_sidebars && !is_wp_error($wp_registered_sidebars)) {
			
			foreach ($wp_registered_sidebars as $sidebar) {
				// Don't include Top Bar & Footer Widget Area
				if (in_array($sidebar['id'], $none_sidebars)) continue;
				
				$sidebars[$sidebar['id']] = $sidebar['name'];
			}
		}
		return $sidebars;
	}
endif;

if (!function_exists('noo_get_sidebar_name')):
	function noo_get_sidebar_name($id = '') {
		if (empty($id)) return '';
		
		global $wp_registered_sidebars;
		if ($wp_registered_sidebars && !is_wp_error($wp_registered_sidebars)) {
			foreach ($wp_registered_sidebars as $sidebar) {
				if ($sidebar['id'] == $id) return $sidebar['name'];
			}
		}
		
		return '';
	}
endif;

if (!function_exists('noo_get_page_link_by_template')):
	function noo_get_page_link_by_template( $page_template ) {
		$pages = get_pages(array(
			'meta_key' => '_wp_page_template',
			'meta_value' => $page_template
		));

		if( $pages ){
			$link = get_permalink( $pages[0]->ID );
		}else{
			$link = home_url();
		}
		return $link;
	}
endif;

if (!function_exists('noo_handle_upload_file')):
	function noo_handle_upload_file($upload_data) {
		$return = false;
		$uploaded_file = wp_handle_upload($upload_data, array('test_form' => false));

		if (isset($uploaded_file['file'])) {
			$file_loc = $uploaded_file['file'];
			$file_name = basename($upload_data['name']);
			$file_type = wp_check_filetype($file_name);

			$attachment = array(
				'post_mime_type' => $file_type['type'],
				'post_title' => preg_replace('/\.[^.]+$/', '', basename($file_name)),
				'post_content' => '',
				'post_status' => 'inherit'
				);

			$attach_id = wp_insert_attachment($attachment, $file_loc);
			$attach_data = wp_generate_attachment_metadata($attach_id, $file_loc);
			wp_update_attachment_metadata($attach_id, $attach_data);

			$return = array('data' => $attach_data, 'id' => $attach_id);

			return $return;
		}

		return $return;
	}
endif;

// Get allowed HTML tag.
if( !function_exists('noo_allowed_html') ) :
    function noo_allowed_html() {
        return apply_filters( 'noo_allowed_html', array(
            'a' => array(
                'href' => array(),
                'target' => array(),
                'title' => array(),
                'rel' => array(),
                'class' => array(),
                'style' => array(),
            ),
            'img' => array(
                'src' => array(),
                'class' => array(),
                'style' => array(),
            ),
            'h1' => array(),
            'h2' => array(),
            'h3' => array(),
            'h4' => array(),
            'h5' => array(),
            'p' => array(
                'class' => array(),
                'style' => array()
            ),
            'br' => array(
                'class' => array(),
                'style' => array()
            ),
            'hr' => array(
                'class' => array(),
                'style' => array()
            ),
            'span' => array(
                'class' => array(),
                'style' => array()
            ),
            'em' => array(
                'class' => array(),
                'style' => array()
            ),
            'strong' => array(
                'class' => array(),
                'style' => array()
            ),
            'small' => array(
                'class' => array(),
                'style' => array()
            ),
            'b' => array(
                'class' => array(),
                'style' => array()
            ),
            'i' => array(
                'class' => array(),
                'style' => array()
            ),
            'u' => array(
                'class' => array(),
                'style' => array()
            ),
            'ul' => array(
                'class' => array(),
                'style' => array()
            ),
            'ol' => array(
                'class' => array(),
                'style' => array()
            ),
            'li' => array(
                'class' => array(),
                'style' => array()
            ),
            'blockquote' => array(
                'class' => array(),
                'style' => array()
            ),
        ) );
    }
endif;


// Allow only unharmed HTML tag.
if( !function_exists('noo_html_content_filter') ) :
    function noo_html_content_filter( $content = '' ) {
        return wp_kses( $content, noo_allowed_html() );
    }
endif;

// Backwards compatibility for wp_title
if ( ! function_exists( '_wp_render_title_tag' ) ) {
	function noo_render_title() {
?>
<title><?php wp_title( '|', true, 'right' ); ?></title>
<?php
	}
	add_action( 'wp_head', 'noo_render_title' );
}