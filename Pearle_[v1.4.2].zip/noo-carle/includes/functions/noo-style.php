<?php
/**
 * Style Functions for NOO Framework.
 * This file contains functions for calculating style (normally it's css class) base on settings from admin side.
 *
 * @package    NOO Framework
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */

if (!function_exists('noo_body_class')):
	function noo_body_class($output) {
		global $wp_customize;
		if (isset($wp_customize)) {
			$output[] = 'is-customize-preview';
		}

		// Preload
		if( noo_get_option( 'noo_preload', false ) ) {
			$output[] = 'enable-preload';
		}
        $theme_style = noo_get_option('noo_choose_theme');
		$page_layout = noo_get_page_layout();
		if ($page_layout == 'fullwidth') {
			$output[] = ' page-fullwidth';
		} elseif ($page_layout == 'left_sidebar') {
			$output[] = ' page-left-sidebar';
		} else {
			$output[] = ' page-right-sidebar';
		}
		
		switch (noo_get_option('noo_site_layout', 'fullwidth')) {
			case 'boxed':
				// if(get_page_template_slug() != 'page-full-width.php')
				$output[] = 'boxed-layout';
			break;
			default:
				$output[] = 'full-width-layout';
			break;
		}

        $color_stt = noo_get_option('noo_multiple_color');
        if( $color_stt == false ):
            switch ($theme_style) {
                case 'theme-printing':
                    $output[] = 'theme-printing';
                break;
                case 'theme-cleaning':
                    $output[] = 'theme-cleaning';
                    break;
                case 'theme-construct':
                    $output[] = 'theme-construct';
                    break;
                case 'theme-transport':
                    $output[] = 'theme-transport';
                    break;
                case 'theme-bikang':
                    $output[] = 'theme-bikang';
                    break;
                default:
                    $output[] = '';
                break;
            }
        endif;
		// SmoothScroll
		if( noo_get_option( 'noo_smooth_scrolling', false ) ) {
			$output[] = 'enable-nice-scroll';
		}

		// Fixed left and/or right Navigation
		$navbar_position = noo_get_option('noo_header_nav_position', 'fixed_top');
		if ($navbar_position == 'fixed_left') {
			$output[] = 'navbar-fixed-left-layout';
		} elseif ($navbar_position == 'fixed_right') {
			$output[] = 'navbar-fixed-right-layout';
		}

		if( noo_is_one_page_enabled() ) {
			$output[] = 'one-page-layout';
		}

        if ( noo_get_option('noo_layout_rtl','no') == 'yes' ){
            $output[] = 'theme-rtl';
        }

        if ( is_admin_bar_showing() ) {
            $output[] = 'noo-wpadminbar';
        }
		
		return $output;
	}
endif;
add_filter('body_class', 'noo_body_class');

if (!function_exists('noo_header_class')):
	function noo_header_class() {
		$class = '';
		$navbar_position = noo_get_option('noo_header_nav_position', 'static_top');
        $transparent = noo_get_post_meta(get_the_ID(),'_noo_wp_page_menu_transparent');
		if ($navbar_position == 'fixed_top') {
			$class = 'fixed_top';
		}
        if( is_page() ){
            if($transparent){
                $class .= ' header_transparent';
            }
        }
        $header_style = noo_get_option('noo_header_nav_style','header3');
        if( is_page() ){
            $headerpage   = noo_get_post_meta(get_the_ID(),'_noo_wp_page_header_style');
            if( !empty($headerpage) && $headerpage != 'header' ){
                $header_style = $headerpage;
            }
        }
        switch($header_style){
            case 'header1';
                $class .= ' header-default';
                break;
            case 'header2';
                $class .= ' header-2 header-style2';
                break;
            case 'header3';
                $class .= ' header-3';
                break;
            case 'header4';
                $class .= ' header-4';
                break;
            case 'header5';
                $class .= ' header-2 header-5';
                break;
            case 'header6';
                $class .= ' header-2 header-style2 header-6';
                break;
            default:
                $class .= ' header-default';
                break;

        }

		echo $class;
	}
endif;


if (!function_exists('noo_main_class')):
	function noo_main_class() {
		$class = 'noo-main';
		$page_layout = noo_get_page_layout();

		if ($page_layout == 'fullwidth') {
			$class.= ' noo-md-12';
		} elseif ($page_layout == 'left_sidebar') {
			$class.= ' noo-md-8 pull-right';
		} else {
			$class.= ' noo-md-8';
		}
		
		echo $class;
	}
endif;

if(!function_exists('noo_container_class')){
	function noo_container_class(){
		
		if(noo_is_fullwidth()) {
			echo  'container-fullwidth';
			return;
		}
		echo 'noo-container';
	}
}

if (!function_exists('noo_sidebar_class')):
	function noo_sidebar_class() {
		$class = ' noo-sidebar noo-md-4';
		$page_layout = noo_get_page_layout();
		
		if ( $page_layout == 'left_sidebar' ) {
			$class .= ' noo-sidebar-left pull-left';
		}
		
		echo $class;
	}
endif;

if (!function_exists('noo_blog_class')):
	function noo_blog_class() {
		$class = ' post-area';
		$blog_style = noo_get_option('noo_blog_style', 'standard');
		
		if ($blog_style == 'masonry') {
			$class.= ' masonry-blog';
		} else {
			$class.= ' standard-blog';
		}
		
		echo $class;
	}
endif;

if (!function_exists('noo_page_class')):
	function noo_page_class() {
		$class = ' noo-page';
		
		echo $class;
	}
endif;

if (!function_exists('noo_portfolio_class')):
	function noo_portfolio_class() {
		$class = ' post-area';
			$class .= ' masonry-portfolio';
			if(noo_get_option('noo_portfolio_items_title', false) === true) {
				$class .= ' no-title';
			}

			if(noo_get_option( 'noo_portfolio_grid_style', 'standard' ) == 'masonry') {
				$class .= ' no-gap';
			}

		echo $class;
	}
endif;

if (!function_exists('noo_post_class')):
	function noo_post_class($output) {
		if (noo_has_featured_content()) {
			$output[] = 'has-featured';
		} else {
			$output[] = 'no-featured';
		}

		if(!is_single()) {

		}

		$post_id = get_the_id();
		$post_type = get_post_type($post_id);


		$post_format = noo_get_post_format($post_id, $post_type);

		// Post format class for NOO Portfolio
		if ($post_type == 'portfolio_project') {
			if( is_single() ) {
				$output[] = 'single-noo-portfolio';
			}
			if(!empty($post_format)) {
				$output[] = "media-{$post_format}";
			}
		}

		// Masonry Style
		if(noo_is_masonry_style()) {
			$prefix = ($post_type == 'portfolio_project') ? '_noo_portfolio' : '_noo_wp_post';
			// if it's portfolio page, get the size from setting
			$masonry_size = noo_get_post_meta($post_id, "{$prefix}_masonry_{$post_format}_size", 'regular');
			$output[] = 'masonry-item ' . $masonry_size;

			if($post_type == 'portfolio_project') {
			    $categories = wp_get_object_terms( $post_id, 'portfolio_category' );
			    foreach ( $categories as $category ) {
			      $output[] = 'noo-portfolio-' . $category->slug;
			    }
			}
		}
		
		return $output;
	}
	
	add_filter('post_class', 'noo_post_class');
endif;
