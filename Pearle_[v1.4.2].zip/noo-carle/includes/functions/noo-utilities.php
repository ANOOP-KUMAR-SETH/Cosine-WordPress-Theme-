<?php
/**
 * Utilities Functions for NOO Framework.
 * This file contains various functions for getting and preparing data.
 *
 * @package    NOO Framework
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */


//
// This function help to create the dynamic thumbnail width,
// but we don't use it at the moment.
// 
if (!function_exists('noo_thumbnail_width')) :
	function noo_thumbnail_width() {
		$site_layout	= noo_get_option('noo_site_layout', 'fullwidth');
		$page_layout	= noo_get_page_layout();
		$width			= 1200; // max width

		if($site_layout == 'boxed') {
			$site_width = (int) noo_get_option('noo_layout_site_width', '90');
			$site_max_width = (int) noo_get_option('noo_layout_site_max_width', '1200');
			$width = min($width * $site_width / 100, $site_max_width);
		}

		if($page_layout != 'fullwidth') {
			$width = $width * 75 / 100; // 75% of col-9
		}

		return $width;
	}
endif;

if (!function_exists('noo_get_thumbnail_width')) :
	function noo_get_thumbnail_width() {

		// if( is_admin()) {
		// 	return 'thumbnail';
		// }

		// NOO Portfolio
		if( is_post_type_archive( 'portfolio_project' ) ) {
			// if it's portfolio page, check if the masonry size is fixed or original
			if(noo_get_option('noo_portfolio_masonry_item_size', 'original' ) == 'fixed') {
				$masonry_size = noo_get_post_meta($post_id, '_noo_portfolio_image_masonry_size', 'regular');
				return "masonry-fixed-{$masonry_size}";
			}
		}

		$site_layout	= noo_get_option('noo_site_layout', 'fullwidth');
		$page_layout	= noo_get_page_layout();

		if($site_layout == 'boxed') {
			if($page_layout == 'fullwidth') {
				return 'boxed-fullwidth';
			} else {
				return 'boxed-sidebar';
			}
		} else {
			if($page_layout == 'fullwidth') {
				return 'fullwidth-fullwidth';
			} else {
				return 'fullwidth-sidebar';
			}
		}

		return 'fullwidth-fullwidth';
	}
endif;


if(!function_exists('noo_is_fullwidth')){
	function noo_is_fullwidth(){
		return noo_get_page_layout() == 'fullwidth';
	}
}

if (!function_exists('noo_is_one_page_enabled')):
	function noo_is_one_page_enabled() {
		if( (is_front_page() && get_option('show_on_front' == 'page')) || is_page()) {
			$page_id = get_the_ID();
			return ( noo_get_post_meta( $page_id, '_noo_wp_page_enable_one_page', false ) );
		}

		return false;
	}
endif;

if (!function_exists('noo_get_one_page_menu')):
	function noo_get_one_page_menu() {
		if( noo_is_one_page_enabled() ) {
			if( (is_front_page() && get_option('show_on_front' == 'page')) || is_page()) {
				$page_id = get_the_ID();
				return noo_get_post_meta( $page_id, '_noo_wp_page_one_page_menu', '' );
			}
		}

		return '';
	}
endif;

if (!function_exists('noo_has_home_slider')):
	function noo_has_home_slider() {
		if (class_exists( 'RevSlider' )) {
			if( (is_front_page() && get_option('show_on_front' == 'page')) || is_page()) {
				$page_id = get_the_ID();
				return ( noo_get_post_meta( $page_id, '_noo_wp_page_enable_home_slider', false ) )
					&& ( noo_get_post_meta( $page_id, '_noo_wp_page_slider_rev', '' ) != '' );
			}
		}

		return false;
	}
endif;

if (!function_exists('noo_is_masonry_style')):
	function noo_is_masonry_style() {
		if( is_post_type_archive( 'portfolio_project' ) || is_tax('portfolio_category') || is_tax('portfolio_tag')  ) {
			return true;
		}

		if(is_home()) {
			return (noo_get_option( 'noo_blog_style' ) == 'masonry');
		}
		
		if(is_archive()) {
			$archive_style = noo_get_option( 'noo_blog_archive_style', 'same_as_blog' );
			if ($archive_style == 'same_as_blog') {
				return (noo_get_option( 'noo_blog_style', 'standard' ) == 'masonry');
			} else {
				return ($archive_style == 'masonry');
			}
		}

		return false;
	}
endif;

if (!function_exists('noo_get_page_heading')):
	function noo_get_page_heading() {
		$heading = '';
		$archive_title = '';
		$archive_desc = '';
		if( ! noo_get_option( 'noo_page_heading', true ) ) {
			return array($heading, $archive_title, $archive_desc);
		}

		if ( is_home() ) {
			$heading = noo_get_option( 'noo_blog_heading_title', esc_html__( 'Blog', 'noo-carle' ) );
		} elseif ( NOO_WOOCOMMERCE_EXIST && is_shop() ) {
            if (is_search()) {
                $heading = esc_html__('Search', 'noo-carle');
            } else {
                $heading = noo_get_option('noo_shop_heading_title', esc_html__('Shop', 'noo-carle'));
            }
        }elseif ( NOO_WOOCOMMERCE_EXIST && is_product() ) {
            $heading = get_the_title();

		} elseif ( is_search() ) {
			$heading = esc_html__( 'Search', 'noo-carle' );
		} elseif ( is_author() ) {
			$curauth = (get_query_var('author_name')) ? get_user_by('slug', get_query_var('author_name')) : get_userdata(get_query_var('author'));
			$heading = esc_html__('Author Archive','noo-carle');

		} elseif ( is_year() ) {
    		$heading = esc_html__( 'Post Archive by Year: ', 'noo-carle' ) . get_the_date( 'Y' );
		} elseif ( is_month() ) {
    		$heading = esc_html__( 'Post Archive by Month: ', 'noo-carle' ) . get_the_date( 'F,Y' );
		} elseif ( is_day() ) {
    		$heading = esc_html__( 'Post Archive by Day: ', 'noo-carle' ) . get_the_date( 'F j, Y' );
		} elseif ( is_404() ) {
    		$heading = esc_html__( 'Oops! We could not find anything to show to you.', 'noo-carle' );
    		$archive_title =  esc_html__( 'Would you like going else where to find your stuff.', 'noo-carle' );
		} elseif ( is_archive() ) {
			$heading        = single_cat_title( '', false );
			// $archive_desc   = term_description();
		} elseif ( is_singular( 'product' ) ) {
			$heading = noo_get_option( 'noo_woocommerce_product_disable_heading', true ) ? '' : get_the_title();
		}  elseif ( is_single() ) {
			$heading = get_the_title();
		} elseif( is_page() ) {
			if( ! noo_get_post_meta(get_the_ID(), '_noo_wp_page_hide_page_title', false) ) {
				$heading = get_the_title();
			}
		}

		return array($heading, $archive_title, $archive_desc);
	}
endif;

if (!function_exists('noo_get_page_heading_image')):
	function noo_get_page_heading_image() {
		$image = '';
		if( ! noo_get_option( 'noo_page_heading', true ) ) {
			return $image;
		}
		if( NOO_WOOCOMMERCE_EXIST && is_shop() ) {
			$image = noo_get_image_option( 'noo_shop_heading_image', '' );
		} elseif ( is_home() ) {
			$image = noo_get_image_option( 'noo_blog_heading_image', '' );
		} elseif( is_category() || is_tag() ) {
			$queried_object = get_queried_object();
			$image			= noo_get_term_meta( $queried_object->term_id, 'heading_image', '' );
			$image			= empty( $image ) ? noo_get_image_option( 'noo_blog_heading_image', '' ) : $image;
		} elseif( is_tax( 'portfolio_category' ) ) {
			$queried_object = get_queried_object();
			$image			= noo_get_term_meta( $queried_object->term_id, 'heading_image', '' );
			$image			= empty( $image ) ? noo_get_image_option( 'noo_portfolio_heading_image', '' ) : $image;
		} elseif( NOO_WOOCOMMERCE_EXIST && ( is_product_category() || is_product_tag() ) ) {
			$queried_object = get_queried_object();
			$image			= noo_get_term_meta( $queried_object->term_id, 'heading_image', '' );
			$image			= empty( $image ) ? noo_get_image_option( 'noo_shop_heading_image', '' ) : $image;
		} elseif ( is_singular('product' ) || is_page() ) {
			$image = noo_get_post_meta(get_the_ID(), '_heading_image', '');
		} elseif ( is_single()) {
			$image = noo_get_image_option( 'noo_blog_heading_image', '' );
		}

		if( !empty( $image ) && is_numeric( $image ) ) $image = wp_get_attachment_url( $image );

		return $image;
	}
endif;

if( !function_exists('noo_new_heading') ){
    function noo_new_heading(){
        $varible = array();
        $image   = '';
        $title   = '';
        if( NOO_WOOCOMMERCE_EXIST && ( is_shop()  || is_product_category() || is_product_tag() )) {
            $image = noo_get_image_option('noo_shop_heading_image', '');
            $title = noo_get_option('noo_shop_heading_title');
        }elseif(  NOO_WOOCOMMERCE_EXIST && is_product() ) {
            $option = noo_get_option('noo_product_single_header', 1);
            $image = noo_get_image_option('noo_shop_heading_image', '');
            $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
            if (isset($thumb) && !empty($thumb) && $option != 1) {
                $image = $thumb[0];
            }
            $title = get_the_title();
        }elseif( is_home() || is_category() || is_tag() || is_date() ) {
            $image = noo_get_image_option('noo_blog_heading_image', '');
            $title = noo_get_option('noo_blog_heading_title', esc_html__('Blog', 'noo-carle'));
        }elseif(is_singular('noo_services' )) {
            $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
            if (isset($thumb) && !empty($thumb)) {
                $image = $thumb[0];
            }
            $title = get_the_title();
        }elseif( is_singular('noo_project') ){
            $thumb = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');
            if (isset($thumb) && !empty($thumb)) {
                $image = $thumb[0];
            }
            $title = get_the_title();

        }elseif ( is_single()) {

            $image  = noo_get_image_option( 'noo_blog_heading_image', '' );
            $option = noo_get_option('noo_blog_single_header', 1);
            $thumb  = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()), 'full');

            if (isset($thumb) && !empty($thumb) && $option != 1) {
                $image = $thumb[0];
            }
            $title = get_the_title();
        }elseif( is_page() ){
            $id_image = noo_get_post_meta(get_the_ID(),'_heading_image');
            if( isset($id_image) && !empty($id_image) ){
                $image = wp_get_attachment_url($id_image);
            }
            $title = get_the_title();

        }
        $varible['img'] =   $image;
        $varible['title'] =   $title;
        return $varible;
    }
}

if (!function_exists('noo_get_post_format')):
	function noo_get_post_format($post_id = null, $post_type = '') {
		$post_id = (null === $post_id) ? get_the_ID() : $post_id;
		$post_type = ('' === $post_type) ? get_post_type($post_id) : $post_type;

		$post_format = '';
		
		if ($post_type == 'post') {
			$post_format = get_post_format($post_id);
		}
		
		if ($post_type == 'portfolio_project') {
			$post_format = noo_get_post_meta($post_id, '_noo_portfolio_media_type', 'image');
		}

		return $post_format;
	}
endif;

if (!function_exists('noo_has_featured_content')):
	function noo_has_featured_content($post_id = null) {
		$post_id = (null === $post_id) ? get_the_ID() : $post_id;

		$post_type = get_post_type($post_id);
		$prefix = '';
		$post_format = '';
		
		if ($post_type == 'post') {
			$prefix = '_noo_wp_post';
			$post_format = get_post_format($post_id);
		}
		
		if ($post_type == 'portfolio_project') {
			$prefix = '_noo_portfolio';
			$post_format = noo_get_post_meta($post_id, "{$prefix}_media_type", 'image');
		}
		
		switch ($post_format) {
			case 'image':
				$main_image = noo_get_post_meta($post_id, "{$prefix}_main_image", 'featured');
				if( $main_image == 'featured') {
					return has_post_thumbnail($post_id);
				}

				return has_post_thumbnail($post_id) || ( (bool)noo_get_post_meta($post_id, "{$prefix}_image", '') );
			case 'gallery':
				if (!is_singular()) {
					$preview_content = noo_get_post_meta($post_id, "{$prefix}_gallery_preview", 'slideshow');
					if ($preview_content == 'featured') {
						return has_post_thumbnail($post_id);
					}
				}
				
				return (bool)noo_get_post_meta($post_id, "{$prefix}_gallery", '');
			case 'video':
				if (!is_singular()) {
					$preview_content = noo_get_post_meta($post_id, "{$prefix}_preview_video", 'both');
					if ($preview_content == 'featured') {
						return has_post_thumbnail($post_id);
					}
				}
				
				$m4v_video = (bool)noo_get_post_meta($post_id, "{$prefix}_video_m4v", '');
				$ogv_video = (bool)noo_get_post_meta($post_id, "{$prefix}_video_ogv", '');
				$embed_video = (bool)noo_get_post_meta($post_id, "{$prefix}_video_embed", '');
				
				return $m4v_video || $ogv_video || $embed_video;
			case 'link':
			case 'quote':
				return false;
				
			case 'audio':
				$mp3_audio = (bool)noo_get_post_meta($post_id, "{$prefix}_audio_mp3", '');
				$oga_audio = (bool)noo_get_post_meta($post_id, "{$prefix}_audio_oga", '');
				$embed_audio = (bool)noo_get_post_meta($post_id, "{$prefix}_audio_embed", '');
				return $mp3_audio || $oga_audio || $embed_audio;
			default: // standard post format
				return has_post_thumbnail($post_id);
		}
		
		return false;
	}
endif;
