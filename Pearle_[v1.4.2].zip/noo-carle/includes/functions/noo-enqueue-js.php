<?php
/**
 * NOO Framework Site Package.
 *
 * Register Script
 * This file register & enqueue scripts used in NOO Themes.
 *
 * @package    NOO Framework
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */
// =============================================================================

//
// Site scripts
//
if ( ! function_exists( 'noo_enqueue_site_scripts' ) ) :
	function noo_enqueue_site_scripts() {

		// Main script

		// vendor script
		wp_register_script( 'vendor-modernizr', NOO_VENDOR_URI . '/modernizr-2.7.1.min.js', null, null, false );
		wp_register_script( 'vendor-touchSwipe', NOO_VENDOR_URI . '/jquery.touchSwipe.js', array( 'jquery' ), null, true );
		wp_register_script( 'vendor-bootstrap', NOO_VENDOR_URI . '/bootstrap.min.js', array( 'vendor-touchSwipe' ), null, true );

    	wp_register_script( 'vendor-jplayer', NOO_VENDOR_URI . '/jplayer/jplayer-2.5.0.min.js', array( 'jquery' ), null, true );
		
		wp_register_script( 'vendor-imagesloaded', NOO_VENDOR_URI . '/imagesloaded.pkgd.min.js', null, null, true );
		wp_register_script( 'vendor-isotope', NOO_VENDOR_URI . '/jquery.isotope.min.js', array('vendor-imagesloaded'), null, true );
		wp_register_script( 'vendor-masonry', NOO_VENDOR_URI . '/masonry.pkgd.min.js', array('vendor-imagesloaded'), null, true );
		wp_register_script( 'vendor-infinitescroll', NOO_VENDOR_URI . '/infinitescroll-2.0.2.min.js', null, null, true );
		wp_register_script( 'vendor-carouFredSel-touchSwipe', NOO_VENDOR_URI . '/carouFredSel/helper-plugins/jquery.touchSwipe.min.js', array( 'jquery' ), null, true );
		wp_register_script( 'vendor-carouFredSel', NOO_VENDOR_URI . '/carouFredSel/jquery.carouFredSel-6.2.1-packed.js', array( 'jquery', 'vendor-carouFredSel-touchSwipe','vendor-imagesloaded' ), null, true );
		
		wp_register_script( 'vendor-easing', NOO_VENDOR_URI . '/easing-1.3.0.min.js', array( 'jquery' ), null, true );
		wp_register_script( 'vendor-appear', NOO_VENDOR_URI . '/jquery.appear.js', array( 'jquery','vendor-easing' ), null, true );
		wp_register_script( 'vendor-countTo', NOO_VENDOR_URI . '/jquery.countTo.js', array( 'jquery', 'vendor-appear' ), null, true );
		wp_register_script( 'vc_pie_custom', NOO_ASSETS_URI . '/js/jquery.vc_chart.custom.js',array('jquery','progressCircle','vendor-appear'), null, true);
		
		wp_register_script( 'vendor-nivo-lightbox-js', NOO_VENDOR_URI . '/nivo-lightbox/nivo-lightbox.min.js', array( 'jquery' ), null, true );
		wp_register_script( 'vendor-fancybox-lightbox-js', NOO_VENDOR_URI . '/fancybox-lightbox/source/jquery.fancybox.pack.js', array( 'jquery' ), null, true );
		
		wp_register_script( 'vendor-parallax', NOO_VENDOR_URI . '/jquery.parallax-1.1.3.js', array( 'jquery'), null, true );
		//wp_register_script( 'vendor-nicescroll', NOO_VENDOR_URI . '/nicescroll-3.5.4.min.js', array( 'jquery' ), null, true );

        wp_register_script( 'noo-carousel', NOO_VENDOR_URI . '/owl.carousel.min.js', array(), null, true );

        wp_register_script( 'portfolio', NOO_ASSETS_URI . '/js/portfolio.js', array( 'jquery' ), null, true );
        wp_register_script( 'jquery-ui-custom', NOO_VENDOR_URI . '/datetimepicker/jquery-ui.js', array(), null, false );

        wp_register_script( 'jquery.ui.timepicker', NOO_VENDOR_URI . '/datetimepicker/jquery.ui.timepicker.js', array(), null, true );

        wp_register_script( 'jquery-projects', NOO_ASSETS_URI . '/js/project.js', array(), null, true );

//        wp_enqueue_script('google-map','http'.(is_ssl() ? 's':'').'://maps.googleapis.com/maps/api/js',array('jquery'), '1.0', false);

		$google_api = get_theme_mod('noo_google_map_api_key', '');
		wp_enqueue_script( 'google-map','http'.(is_ssl() ? 's':'').'://maps.googleapis.com/maps/api/js?v=3.exp&sensor=true&libraries=places' . ( !empty( $google_api ) ? '&key=' .$google_api : '' ), array('jquery'), '1.0' , false);


        if( is_page_template('page-onepage.php') ){
            wp_register_script( 'noo-nav', NOO_VENDOR_URI . '/jquery.nav.js', array(), null, true );
            wp_enqueue_script( 'noo-nav' );
        }

        if( is_singular('noo_project')){
            wp_enqueue_script('noo-carousel');
        }
		
		wp_register_script( 'noo-script', NOO_ASSETS_URI . '/js/noo.js', array( 'jquery' ), null, true );


		if ( ! is_admin() ) {
			wp_enqueue_script( 'vendor-modernizr' );
			
			if ( is_singular() ) wp_enqueue_script( 'comment-reply' );

			$is_shop				= NOO_WOOCOMMERCE_EXIST && is_shop();
			$is_project             = is_singular( 'portfolio_project' ) ? 'true' : 'false';
			$is_portfolio_attribute = is_tax( 'portfolio_tag' ) ? 'true' : 'false';
			$nooL10n = array(
				'ajax_url'        => admin_url( 'admin-ajax.php', 'relative' ),
				'ajax_finishedMsg'=>esc_html__('All posts displayed','noo-carle'),
				'home_url'        => home_url( '/' ),
				'is_blog'         => is_home() ? 'true' : 'false',
				'is_archive'      => is_post_type_archive('post') ? 'true' : 'false',
				'is_single'       => is_single() ? 'true' : 'false',
				// 'is_portfolio'    => is_post_type_archive( 'portfolio_project' ) || is_tax( 'portfolio_category') ? 'true' : 'false',
				// 'is_project'      => is_singular( 'portfolio_project' ) ? 'true' : 'false',
				'is_shop'         => NOO_WOOCOMMERCE_EXIST && is_shop() ? 'true' : 'false',
				'is_product'      => NOO_WOOCOMMERCE_EXIST && is_product() ? 'true' : 'false',
				'infinite_scroll_end_msg' => esc_html__('All posts displayed', 'noo-carle')
			);

			global $noo_post_types;
			if( !empty( $noo_post_types ) ) {
				foreach ($noo_post_types as $post_type => $args) {
					$nooL10n['is_' . $post_type . '_archive'] = is_post_type_archive( $post_type ) ? 'true' : 'false';
					$nooL10n['is_' . $post_type . '_single'] = is_singular( $post_type ) ? 'true' : 'false';
				}
			}
			
			
			wp_localize_script('noo-script', 'nooL10n', $nooL10n);


            wp_enqueue_script( 'noo-cabas', NOO_ASSETS_URI . '/js/off-cavnass.js', array(), null, true );
            wp_enqueue_script( 'noo-new', NOO_ASSETS_URI . '/js/noo_new.js', array(), null, true );
			wp_enqueue_script( 'noo-script' );

            $nooUrl = array(
                'ajax_url'        => admin_url( 'admin-ajax.php'),
            );
            wp_localize_script('noo-new', 'noo_admin', $nooUrl);
		}

	}
add_action( 'wp_enqueue_scripts', 'noo_enqueue_site_scripts' );
endif;
