<?php

if ( class_exists( 'woocommerce' ) ) {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
    remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
    remove_action('woocommerce_before_main_content','woocommerce_breadcrumb',20);
	function noo_add_to_cart_fragments( $fragments ) {
		$output = noo_minicart();
		$fragments['.minicart'] = $output;
		$fragments['.mobile-minicart-icon'] = noo_minicart_mobile();
		return $fragments;
	}
	add_filter( 'woocommerce_add_to_cart_fragments', 'noo_add_to_cart_fragments' );

	function noo_woocommerce_remove_cart_item() {
		global $woocommerce;
		$response = array();
		
		if ( ! isset( $_GET['item'] ) && ! isset( $_GET['_wpnonce'] ) ) {
			exit();
		}
		$woocommerce->cart->set_quantity( $_GET['item'], 0 );
		
		$cart_count = $woocommerce->cart->cart_contents_count;
		$response['count'] = $cart_count != 0 ? $cart_count : "";
		$response['minicart'] = noo_minicart( true );
		
		// widget cart update
		ob_start();
		woocommerce_mini_cart();
		$mini_cart = ob_get_clean();
		$response['widget'] = '<div class="widget_shopping_cart_content">' . $mini_cart . '</div>';
		
		echo json_encode( $response );
		exit();
	}
	add_action( 'wp_ajax_noo_woocommerce_remove_cart_item', 'noo_woocommerce_remove_cart_item' );
	add_action( 'wp_ajax_nopriv_noo_woocommerce_remove_cart_item', 'noo_woocommerce_remove_cart_item' );

	function noo_product_items_text( $count ) {
		$product_item_text = "";
		
		if ( $count > 1 ) {
			$product_item_text = str_replace( '%', number_format_i18n( $count ), esc_html__( '% items', 'noo-carle' ) );
		} elseif ( $count == 0 ) {
			$product_item_text = esc_html__( '0 items', 'noo-carle' );
		} else {
			$product_item_text = esc_html__( '1 item', 'noo-carle' );
		}
		
		return $product_item_text;
	}

	// Mobile icon
	function noo_minicart_mobile() {

		global $woocommerce;
		
		$cart_output = "";
		$cart_total = $woocommerce->cart->get_cart_total();
		$cart_count = $woocommerce->cart->cart_contents_count;
		$cart_output = '<a href="' . wc_get_cart_url() . '" title="' . esc_html__( 'View Cart', 'noo-carle' ) .
			 '"><span><i class="fa fa-shopping-cart"></i><em>' . $cart_count . '</em></span></a>';
		return $cart_output;
	}
    function noo_navbar_shop_icons_mini_simple( $items, $args ) {

        if( ! NOO_WOOCOMMERCE_EXIST ) return $items;
        $header_style = noo_get_post_meta(get_the_ID(),'_noo_wp_page_header_style');
        if ( ( $args->theme_location == 'primary' || $args->theme_location == 'onepage' ) &&  $header_style != 'header2' &&  $header_style != 'header5' &&  $header_style != 'header6') {
            $minicart = noo_minicart_mobile();
            $items .= '<li id="nav-menu-item-simple-cart" class="menu-item noo-menu-item-simple-cart">'.$minicart.'</li>';
        }
        return $items;
    }

    add_filter( 'wp_nav_menu_items', 'noo_navbar_shop_icons_mini_simple', 10, 2 );
	
	// Menu cart
	function noo_minicart( $content = false ) {
		global $woocommerce;
		
		$cart_output = "";
		$cart_total = $woocommerce->cart->get_cart_total();
		$cart_count = $woocommerce->cart->cart_contents_count;
		$cart_count_text = noo_product_items_text( $cart_count );
		
		$cart_has_items = '';
		if ( $cart_count != "0" ) {
			$cart_has_items = ' has-items';
		}
		
		$output = '';
		if ( ! $content ) {
			$output .= '<li id="nav-menu-item-carts" class="menu-item noo-menu-item-cart minicart"><a title="' .
				 esc_html__( 'View cart', 'noo-carle' ) . '" class="cart-button" href="' . wc_get_cart_url() .
				 '">' . '<span class="cart-item' . $cart_has_items . '"><i class="fa fa-shopping-cart icon-shopping"></i>';
			if ( $cart_count != "0" ) {
				$output .= "<span class='count'>" . $cart_count . "</span>";
			}
			$output .= '</span>';
			$output .= '<span class="cart-name">'.esc_html__('My cart','noo-carle').$cart_total.'</span></a>';
			$output .= '<div class="noo-minicart">';
		}
		if ( $cart_count != "0" ) {
			$output .= '<div class="minicart-body">';
			foreach ( $woocommerce->cart->cart_contents as $cart_item_key => $cart_item ) {
				
				$cart_product = $cart_item['data'];
				$product_title = $cart_product->get_title();
				$product_short_title = ( strlen( $product_title ) > 25 ) ? substr( $product_title, 0, 22 ) . '...' : $product_title;
				
				if ( $cart_product->exists() && $cart_item['quantity'] > 0 ) {
					$output .= '<div class="cart-product clearfix">';
					$output .= '<div class="cart-product-image"><a class="cart-product-img" href="' .
						 get_permalink( $cart_item['product_id'] ) . '">' . $cart_product->get_image() . '</a></div>';
					$output .= '<div class="cart-product-details">';
					$output .= '<div class="cart-product-title"><a href="' . get_permalink( $cart_item['product_id'] ) .
						 '">' .
						 apply_filters( 'woocommerce_cart_widget_product_title', $product_short_title, $cart_product ) .
						 '</a></div>';
					$output .= '<div class="cart-product-price">' . esc_html__( "Price", "woocommerce" ) . ' ' .
						 wc_price( $cart_product->get_price() ) . '</div>';
					$output .= '<div class="cart-product-quantity">' . esc_html__( 'Quantity', 'noo-carle' ) . ' ' .
						 $cart_item['quantity'] . '</div>';
					$output .= '</div>';
					$output .= apply_filters( 
						'woocommerce_cart_item_remove_link', 
						sprintf( 
							'<a href="%s" class="remove" title="%s">&times;</a>', 
							esc_url( $woocommerce->cart->get_remove_url( $cart_item_key ) ), 
							esc_html__( 'Remove this item', 'noo-carle' ) ),
						$cart_item_key );
					$output .= '</div>';
				}
			}
			$output .= '</div>';
			$output .= '<div class="minicart-footer">';
			$output .= '<div class="minicart-total">' . esc_html__( 'Cart Subtotal', 'noo-carle' ) . ' ' . $cart_total .
				 '</div>';
			$output .= '<div class="minicart-actions clearfix">';
			if ( version_compare( WOOCOMMERCE_VERSION, "2.1.0" ) >= 0 ) {
				$cart_url = apply_filters( 'woocommerce_get_cart_url', wc_get_cart_url() );
				$checkout_url = apply_filters( 'woocommerce_get_checkout_url', wc_get_checkout_url() );
				
				$output .= '<a class="button" href="' . esc_url( $cart_url ) . '"><span class="text">' .
					 esc_html__( 'View Cart', 'noo-carle' ) . '</span></a>';
				$output .= '<a class="checkout-button button" href="' . esc_url( $checkout_url ) .
					 '"><span class="text">' . esc_html__( 'Proceed to Checkout', 'noo-carle' ) . '</span></a>';
			} else {
				
				$output .= '<a class="button" href="' . esc_url( wc_get_cart_url() ) .
					 '"><span class="text">' . esc_html__( 'View Cart', 'noo-carle' ) . '</span></a>';
				$output .= '<a class="checkout-button button" href="' . esc_url( 
					wc_get_checkout_url() ) . '"><span class="text">' .
					 esc_html__( 'Proceed to Checkout', 'noo-carle' ) . '</span></a>';
			}
			$output .= '</div>';
			$output .= '</div>';
		} else {
			$output .= '<div class="minicart-header">' . esc_html__( 'Your shopping bag is empty.', 'noo-carle' ) . '</div>';
			$shop_page_url = "";
			if ( version_compare( WOOCOMMERCE_VERSION, "2.1.0" ) >= 0 ) {
				$shop_page_url = get_permalink( wc_get_page_id( 'shop' ) );
			} else {
				$shop_page_url = get_permalink( wc_get_page_id( 'shop' ) );
			}
			
			$output .= '<div class="minicart-footer">';
			$output .= '<div class="minicart-actions clearfix">';
			$output .= '<a class="button pull-left" href="' . esc_url( $shop_page_url ) . '"><span class="text">' .
				 esc_html__( 'Go to the shop', 'noo-carle' ) . '</span></a>';
			$output .= '</div>';
			$output .= '</div>';
		}
		
		if ( ! $content ) {
			$output .= '</div>';
			$output .= '</li>';
		}
		
		return $output;
	}

	function noo_navbar_shop_icons( $items, $args ) {

		if( ! NOO_WOOCOMMERCE_EXIST ) return $items;

		if ( $args->theme_location == 'primary' ) {
            $minicart = noo_minicart();
            $items .= $minicart;
			if( noo_get_option('noo_header_nav_icon_wishlist', true ) && defined( 'YITH_WCWL' ) ) {
				$wishlist_url = YITH_WCWL()->get_wishlist_url();
				$wishlist = '<li id="nav-menu-item-wishlist" class="menu-item noo-menu-item-wishlist"><a title="' .
				 esc_html__( 'View Wishlist', 'noo-carle' ) . '" class="wishlist-button" href="' . $wishlist_url .
				 '"><i class="fa fa-heart"></i></a></li>';

				$items .= $wishlist;
			}
		}
		return $items;
	}
	 //add_filter( 'wp_nav_menu_items', 'noo_navbar_shop_icons', 10, 2 );

	function noo_woocommerce_update_product_image_size() {
		$catalog = array( 'width' => '500', 'height' => '700', 'crop' => 1 );
		$single = array( 'width' => '500', 'height' => '700', 'crop' => 1 );
		$thumbnail = array( 'width' => '100', 'height' => '100', 'crop' => 1 );
		update_option( 'shop_catalog_image_size', $catalog );
		update_option( 'shop_single_image_size', $single );
		update_option( 'shop_thumbnail_image_size', $thumbnail );
	}


    // carle
    remove_action('woocommerce_after_shop_loop_item_title','woocommerce_template_loop_rating',5);
    add_action('noo_rating','woocommerce_template_loop_rating');
    add_action('noo_rating','noo_count_product_rating');

    function noo_count_product_rating(){
        global $product;
        $rating_count = $product->get_rating_count();
        echo '<span class="noo-count-rating">';
        printf(__( 'based on %s rating','noo-carle' ),esc_html($rating_count));
        echo '</span>';
    }

    add_action('woocommerce_after_shop_loop_item','noo_template_loop_wishlist',11);

    // Wishlist
    if ( ! function_exists( 'noo_woocommerce_wishlist_is_active' ) ) {

        /**
         * Check yith-woocommerce-wishlist plugin is active
         *
         * @return boolean .TRUE is active
         */
        function noo_woocommerce_wishlist_is_active() {
            $active_plugins = (array) get_option( 'active_plugins', array() );

            if ( is_multisite() )
                $active_plugins = array_merge( $active_plugins, get_site_option( 'active_sitewide_plugins', array() ) );

            return in_array( 'yith-woocommerce-wishlist/init.php', $active_plugins ) ||
            array_key_exists( 'yith-woocommerce-wishlist/init.php', $active_plugins );
        }
    }

    function noo_template_loop_wishlist() {
        if ( noo_woocommerce_wishlist_is_active() ) {
            echo do_shortcode( '[yith_wcwl_add_to_wishlist]' );
        }
    }

    // image
    remove_action('woocommerce_before_shop_loop_item_title','woocommerce_template_loop_product_thumbnail',10);
    add_action('woocommerce_before_shop_loop_item_title','noo_woocommerce_template_loop_product_thumbnail',10);
    function noo_woocommerce_template_loop_product_thumbnail(){
        the_post_thumbnail('noo-woo-thumbnail');
    }



    add_action('wp_ajax_noo_search_ajax_products','noo_search_ajax_products');
    add_action('wp_ajax_nopriv_noo_search_ajax_products','noo_search_ajax_products');
    function noo_search_ajax_products(){
        $title = $_POST['title'];
        if( isset($_POST['catid']) ):
            $catid = $_POST['catid'];
        endif;
        if( !isset($title) && empty($title)) exit;

        global $wpdb;
        if( isset($catid) && !empty($catid) ):
        $sql = "SELECT p.id, p.post_title, p.guid FROM $wpdb->posts as p INNER JOIN $wpdb->term_relationships as t on p.id = t.object_id WHERE p.post_title LIKE '%$title%' AND t.term_taxonomy_id = $catid AND p.post_status ='publish' AND p.post_type = 'product' LIMIT 10";
        else:
            $sql = "SELECT id, post_title, guid FROM $wpdb->posts  WHERE post_title LIKE '%$title%'  AND post_status ='publish' AND post_type = 'product' LIMIT 10";
        endif;
        $query = $wpdb->get_results( $sql, OBJECT );
        if( isset($query) && !empty($query) ):
            echo '<ul>';
            foreach($query as $value):

                $price = get_post_meta( $value->id, '_regular_price', true);
                ?>
                    <li>
                        <?php echo wp_get_attachment_image(get_post_thumbnail_id($value->id)); ?>
                        <div class="ajax_p_content">
                            <a href="<?php echo esc_url($value->guid); ?>">
                                <?php echo esc_html($value->post_title); ?>
                            </a>
                            <span class="price"><?php  echo esc_html($price) .' '.get_woocommerce_currency_symbol();  ?> </span>
                        </div>
                    </li>
                <?php
            endforeach;
            echo '</ul>';
        else: ?>
            <ul>
                <li>
                    <?php echo esc_html__('No results found', 'noo-carle'); ?>
                </li>
            </ul>
        <?php endif;
        exit;
    }
}

// Number of products per page
function noo_woocommerce_loop_shop_per_page() {
    return noo_get_option( 'noo_shop_num', 12 );
}
add_filter( 'loop_shop_per_page', 'noo_woocommerce_loop_shop_per_page' );

// Related products
add_filter( 'woocommerce_output_related_products_args', 'noo_woocommerce_output_related_products_args' );

function noo_woocommerce_output_related_products_args() {

    $args = array( 'posts_per_page' => noo_get_option('noo_woocommerce_product_related',3) );
    return $args;
}

remove_action('woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10);
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5);


function noo_woocommerce_shop_columns()
{
	return noo_get_option('noo_shop_grid_column', 3);
}
add_filter( 'loop_shop_columns', 'noo_woocommerce_shop_columns' );
add_filter('woocommerce_related_products_columns', 'noo_woocommerce_shop_columns');
