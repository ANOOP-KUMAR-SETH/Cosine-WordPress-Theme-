<?php
/**
 * NOO Meta Boxes Package
 *
 * Setup NOO Meta Boxes for Page
 * This file add Meta Boxes to WP Page edit page.
 *
 * @package    NOO Framework
 * @subpackage NOO Meta Boxes
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */

if (!function_exists('noo_page_meta_boxes')):
	function noo_page_meta_boxes() {
		// Declare helper object
		$prefix = '_noo_wp_page';
		$helper = new NOO_Meta_Boxes_Helper($prefix, array(
			'page' => 'page'
		));

		// Page Settings
		$meta_box = array(
			'id' => "{$prefix}_meta_box_page",
			'title' => esc_html__('Header Settings', 'noo-carle') ,
			'description' => esc_html__('Choose various setting for your Page.', 'noo-carle') ,
			'fields' => array(
                array(
					'id'    => "{$prefix}_header_style",
					'label' => esc_html__( 'Header Setting' , 'noo-carle' ),
					'desc'  => esc_html__( 'Header Setting.', 'noo-carle' ),
					'type'  => 'select',
                    'std'   => 'header',
                    'options' => array(
                        array('value'=>'header','label'=>'Using header in customizer'),
                        array('value'=>'header1','label'=>'Header Boxed'),
                        array('value'=>'header2','label'=>'Header Shop'),
                        array('value'=>'header3','label'=>'Header Business'),
                        array('value'=>'header4','label'=>'Header Transparent'),
                        array('value'=>'header5','label'=>'Header Minimalist'),
                        array('value'=>'header6','label'=>'Header Centralized')
                    )
				),
                array(
                    'id'    => "{$prefix}_menu_transparent_logo",
                    'label' => esc_html__( 'Menu Logo' , 'noo-carle' ),
                    'desc'  => esc_html__( 'Menu Logo.', 'noo-carle' ),
                    'type'  => 'image',
                ),
                array(
                    'id'    => '_heading_image',
                    'label' => esc_html__( 'Heading Background Image', 'noo-carle' ),
                    'desc'  => esc_html__( 'An unique heading image for this page', 'noo-carle'),
                    'type'  => 'image',
                ),
                array(
                    'label'=> esc_html__( 'Revolution Slider', 'noo' ),
                    'desc' => esc_html__( 'This option only using for Teamplate One page', 'noo' ),
                    'id'   => "{$prefix}_slider_rev",
                    'type' => 'rev_slider',
                    'std'  => ''
                ),
			)
		);




		$helper->add_meta_box( $meta_box );
	}
endif;

add_action('add_meta_boxes', 'noo_page_meta_boxes');