<?php

/**
 * NOO Meta Boxes control
 *
 */

require_once NOO_INCLUDES . '/add_metabox/page-meta-boxes.php' ;
require_once NOO_INCLUDES .'/add_metabox/post-meta-boxes.php';

// // Taxonomy Meta Fields
 require_once NOO_INCLUDES . '/add_metabox/taxonomy-meta.php';