<?php
// Variables

$noo_site_primary_hover_color       =   noo_get_option( 'noo_site_primary_color', noo_get_theme_default( 'primary_color' ) );

$color_status                       = noo_get_option('noo_multiple_color');


$color_one                          = noo_get_option('noo_site_primary_color','#011e9e');
$color_two                          = noo_get_option('noo_site_primary_color2','#f3e200');

$noo_site_link_color_lighten_10     =   noo_lighten( $noo_site_primary_hover_color, '10%' );
$noo_site_link_color_darken_5       =   noo_darken( $noo_site_primary_hover_color, '5%' );
$noo_site_link_color_darken_15      =   noo_darken( $noo_site_primary_hover_color, '15%' );
$noo_site_link_color_fade_50        =   noo_fade( $noo_site_primary_hover_color, '50%' );

$color_one_50        =   noo_fade( $color_one, '50%' );
$color_onelighten_10  =   noo_lighten( $color_one, '10%' );
$color_one_60        =   noo_fade( $color_one, '60%' );
$color_one_80        =   noo_fade( $color_one, '80%' );

$color_two_30        =   noo_fade( $color_two, '30%' );
$color_two_50        =   noo_fade( $color_two, '50%' );
$color_two_60        =   noo_fade( $color_two, '60%' );
$color_two_70        =   noo_fade( $color_two, '70%' );
$color_two_80        =   noo_fade( $color_two, '80%' );


if( isset($color_status) && $color_status !=0 ):
?>
a:focus,a:not(.button):not(.shopnow):hover, a:not(.button):not(.shopnow):hover i{
	color: <?php echo $color_two; ?> !important;
}
.noo-list  a:hover:before{
	background: <?php echo $color_two; ?> !important;
}
#noo_bd .noo-sidebar-wrap .widget-title,
#noo_bd .submit-offer,
#noo_bd .services-cat-title .cat-title-first .cat-title-last,
#noo_bd .noo-sidebar-services .widget_noo_services ul li a:hover,
#noo_bd .project-item .project-inner .project-ds .cat a,
#noo_bd .project-item .project-inner .project-ds .cat,
#noo_bd .product-left-content .shopnow,
#noo_bd .noo_testimonial_one li .noo_testimonial_name,
#noo_bd .noo_pricing .pricing_header span,
#noo_bd .noo-counter-wrap h6,
#noo_bd .title-newsltter,
#noo_bd .your-money2 .money-right .noo-button:hover,
#noo_bd .money-content .money-entry-content,
#noo_bd .header-5 .noo-wrap-menu .noo-main-menu .navbar-nav > li > a,
#noo_bd .header-5 .noo-wrap-menu .noo-main-menu .navbar-nav > li:hover > a,
#noo_bd .submit-offer .number-coupons,
#noo_bd .noo-sh-button.sh-bk,
#noo_bd .money-content  .noo-button:hover,
#noo_bd .header-5 .noo-wrap-menu .noo-main-menu .navbar-nav > li:hover > a,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta a.add_to_cart_button,
#noo_bd .noo-service-content .download a,
#comments #respond .form-submit input,
#noo_bd table.wishlist_table td.product-add-to-cart a,
#noo_bd .money-content .noo-button:hover,
#noo_bd nav.woocommerce-pagination ul li a.current,
#noo_bd nav.woocommerce-pagination ul li span.current,
#noo_bd nav.woocommerce-pagination ul li a:hover,
#noo_bd nav.woocommerce-pagination ul li span:hover,
#noo_bd .wc-proceed-to-checkout a,
#noo_bd .noo-topbar ul li a,
#noo_bd .woo-thumbnail .noo-product-meta .entry-cart-meta a.add_to_cart_button:hover,
.woo-thumbnail .noo-product-meta .entry-cart-meta .yith-wcwl-add-to-wishlist .add_to_wishlist:hover:before,
.woo-thumbnail .noo-product-meta .entry-cart-meta .yith-wcwl-wishlistexistsbrowse a:hover:before,
.woo-thumbnail .noo-product-meta .entry-cart-meta .yith-wcwl-wishlistaddedbrowse a:hover:before
{
color: #fff;
}

#noo_bd .project-sidebar-title,
#noo_bd .noo_testimonial_two li .testimonial_wrap .testimonial-content .testi-meta .noo_testimonial_name,
#noo_bd .project-item .project-inner .project-ds h3 a,
#noo_bd .services-title a,
#noo_bd .money-content .money-title,
#noo_bd .money-content .noo-button,
#noo_bd .your-money2 .money-right .noo-button,
#noo_bd .noo-main-menu .navbar-nav li#nav-menu-item-simple-cart > a span em,
#noo_bd .header-2 .noo-topbar ul li a
{
color: #000;
}

/*
* Color primary one
* ===============================
*/
#noo_bd .noo-list.yes span,
#noo_bd .noo-list span:hover,
<!--#noo_bd .noo-main-menu .navbar-nav li.current-menu-item > a,-->
<!--#noo_bd .noo-main-menu .navbar-nav li:hover > a,-->
#noo_bd .services-title a,
#noo_bd .noo-sh-button,
#noo_bd .noo-sh-button i,
#noo_bd .noo_team li .noo-team-item:hover .noo-team-info h4,
#noo_bd .widget_noo_infomation .noo-infomation-attr li span.fa,
#noo_bd .whychooseus .choose-icon i,
#noo_bd .widget_noo_infomation .noo-info-footer i,
#noo_bd .noo-services-item h3 a,
#noo_bd .noo-service-header .noo-service-attr h2,
#noo_bd .vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-panel-body h3,
#noo_bd .vc_toggle.vc_toggle_default .vc_toggle_title .vc_toggle_icon:before,
#noo_bd .noo_testimonial_three li .testimonial-header .testimonial-name .noo_testimonial_name,
#noo_bd .hentry .entry-content-wrap .entry-content .cat a,
#noo_bd .single-cat a,
#noo_bd .single-navigation span:hover a,
#noo_bd .single-navigation span:hover i,
#noo_bd .woocommerce-info a,
#noo_bd .order_review_wrap #order_review table.shop_table tfoot .cart-subtotal td .amount,
#noo_bd .order_review_wrap #order_review table.shop_table tfoot .cart-subtotal th .amount,
#noo_bd .noo-team-content .team-contact ul li i,
#noo_bd .noo-information i,
#noo_bd .cart-collaterals .cart_totals .car_totals_wrap table .cart-subtotal td,
#noo_bd #comments ol li .comment-wrap .comment-block .comment-header .comment-author,
#noo_bd #comments ul li .comment-wrap .comment-block .comment-header .comment-author,
#noo_bd .noo-sidebar-wrap .widget_recent_entries ul li a:hover,
#noo_bd .noo-sidebar-wrap .widget_categories ul li a:hover,
#noo_bd .noo-sidebar-wrap .widget_recent_entries ul li a:hover,
#noo_bd .noo-sidebar-wrap .widget_categories ul li a:hover,
#noo_bd .widget_noo_best_services .best_services li h4 a:hover,
#noo_bd .our-blog-item .blog-item .blog-hover .entry-sh-footer a:hover,
#noo_bd .blog-item-default .blog-sh-right .default-blog-footer a:hover,
#noo_bd .blog-item-default .blog-sh-right .default-blog-footer a:hover,
#noo_bd .hentry .entry-content-wrap .entry-post-footer a:hover,
#noo_bd blockquote:before,
#noo_bd .single-author-project .author-description strong a,
#noo_bd .noo-portfolio-list .noo-list-content .read-more:hover,
#noo_bd .masonry-filters-project .project-filters li a.selected,
#noo_bd .masonry-filters-project .project-filters li a:hover,
#noo_bd .project-filter span.active,
#noo_bd .project-filter span:hover,
#noo_bd .noo-list.list-default a:hover
{
	color: <?php echo esc_attr($color_one);  ?>;
}

#noo_bd .our-blog-item .blog-item .sh-entry-blog .cat a,
#noo_bd .our-blog-item .blog-item .blog-hover .sh-entry-blog2 .cat a{
	color: <?php echo esc_attr($color_one);  ?>;
}
#noo_bd .ajax_p_content .price
{
	color: <?php echo esc_attr($color_one);  ?>!important;
}

#noo_bd .team-contact ul li i, 
#noo_bd .team-contact .team_socials a,
.widget_noo_infomation .noo-infomation-attr li span.fa,
#noo_infomation-2 .noo-info-footer i.fa,
.noo-checklist li:before,
.single-author-project .author-description strong a,
.whychooseus .choose-icon i,
#noo_bd .blog-item-default .blog-sh-right .date,
#noo_bd .noo-information i, .single-cat a,
.noo-portfolio-list .noo-list-content .noo-cat a,
body .vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-panel-body h3, 
body .vc_tta-tabs.vc_tta-tabs-position-right .vc_tta-panel-body h3,
.noo_testimonial_three li .testimonial-header .testimonial-name .noo_testimonial_name,
.noo_team li .noo-team-item .noo-team-info h4,
.hentry .entry-content-wrap .entry-content .cat a,
#comments ol li .comment-wrap .comment-block .comment-header .comment-author, 
#comments ul li .comment-wrap .comment-block .comment-header .comment-author,
.woocommerce-cart .cart-collaterals .cart_totals .car_totals_wrap table .cart-subtotal td,
.woocommerce-cart .cart-collaterals .cart_totals .car_totals_wrap table .order-total td .amount,
#noo_bd .vc_toggle.vc_toggle_default .vc_toggle_title .vc_toggle_icon:before {
	color: <?php echo esc_attr($color_one);  ?>;	
}
/*
* background primary one
* ===============================
*/
#noo_bd .noo-mailchimp .mc4wp-form input[type='submit'],
#noo_bd .noo-sh-button.sh-bk,
#noo_bd .money-icon,
#noo_bd .money-icon:after,
#noo_bd .book-free .book-content input[type="submit"],
#noo_bd .services-content .services-entry a,
#noo_bd .noo-list span:before,
#noo_bd .vc_tta-tabs:not([class*="vc_tta-gap"]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab.vc_active > a span:before,
#noo_bd .vc_tta-tabs:not([class*="vc_tta-gap"]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab > a:hover span:before,
#noo_bd .clients .prev-client:hover,
#noo_bd .clients .next-client:hover,
#noo_bd .noo-newsltter-form button,
#noo_bd .noo_pricing .pricing_footer a,
#noo_bd .book-creative .book-form2 input[type="submit"],
#noo_bd .social-all,
#noo_bd .noo-infomation-cart ul li.noo-menu-item-cart .cart-button .cart-item .count,
#noo_bd .product-left-content .shopnow,
#noo_bd .vc_tta-tabs:not([class*="vc_tta-gap"]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab.vc_active > a span:before,
#noo_bd .simple-product .simple-content .entry-cart-meta a.add_to_cart_button,
#noo_bd .simple-product .simple-content .entry-cart-meta .yith-wcwl-wishlistexistsbrowse a,
#noo_bd .simple-product .simple-content .entry-cart-meta .yith-wcwl-wishlistaddedbrowse a,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta a.add_to_cart_button,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta .yith-wcwl-wishlistexistsbrowse a,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta .yith-wcwl-wishlistaddedbrowse a,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta .yith-wcwl-add-to-wishlist .add_to_wishlist,
#noo_bd .noo-poster .noo-poster-bk .nav-button:hover,
#noo_bd .wpcf7-form input[type="submit"],
#noo_bd .noo-service-content .download a,
#noo_bd .vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tabs-list li.vc_active a, body .vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tabs-list li:hover a,
#noo_bd .submit-offer .icon,
#noo_bd .author-avatar h5:before,
#noo_bd #comments #respond .form-submit input,
#noo_bd .widget_price_filter .ui-slider .ui-slider-range,
#noo_bd .widget_price_filter .price_slider_amount .button,
#noo_bd span.onsale,
#noo_bd div.product div.summary .cart .button,
#noo_bd div.product div.summary .yith-wcwl-wishlistexistsbrowse a,
#noo_bd div.product div.summary .yith-wcwl-wishlistaddedbrowse a,
#noo_bd div.product #reviews #review_form_wrapper form .form-submit input,
#noo_bd table.wishlist_table td.product-add-to-cart a,
#noo_bd #payment #place_order,
#noo_bd .money-content .noo-button:hover,
#noo_bd .header-5 .noo-wrap-menu,
#noo_bd .search-header5 form input[type='submit'],
#noo_bd .masonry-filters-services .services-filters li a.selected:before,
#noo_bd .masonry-filters-services .services-filters li a:hover:before,
#noo_bd .cart input.button,
#noo_bd .cart-collaterals .cart_totals .car_totals_wrap .wc-proceed-to-checkout a,
#noo_bd input.button,
#noo_bd form.lost_reset_password input[type='submit'],
#noo_bd nav.woocommerce-pagination ul li a.current,
#noo_bd nav.woocommerce-pagination ul li span.current,
#noo_bd nav.woocommerce-pagination ul li a:hover,
#noo_bd nav.woocommerce-pagination ul li span:hover,
#noo_bd div.product div.summary .yith-wcwl-add-to-wishlist .add_to_wishlist,
#noo_bd div.product .woocommerce-tabs ul.tabs li.active a:before,
#noo_bd div.product .woocommerce-tabs ul.tabs li:hover a:before,
#noo_bd .simple-product .simple-content .entry-cart-meta .yith-wcwl-add-to-wishlist .add_to_wishlist,
#noo_bd .ui-datepicker .ui-datepicker-header,
#noo_bd .ui-widget-header,
#noo_bd .vc_tta.vc_general.vc_tta-accordion .vc_tta-panel.vc_active .vc_tta-panel-heading,
#noo_bd .noo-sidebar-services .widget_noo_services ul li a:hover,
#noo_bd .your-money2 .money-right .noo-button,
#noo_bd .ui-datepicker-calendar tr td:hover
{
    background: <?php echo esc_attr($color_one);  ?>;
}


/*
* Color primary two
* ===============================
*/

#noo_bd .single-meta .single-meta-left a:hover,
#noo_bd .social-all a:hover,
#noo_bd .vc_tta-tabs:not([class*="vc_tta-gap"]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab > a:hover,
#noo_bd .vc_tta-tabs:not([class*="vc_tta-gap"]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab.vc_active > a,
#noo_bd .noo-news-slider li .noo-news-item .noo-container .cat a,
#noo_bd .noo-title,
#noo_bd .services-content .services-entry strong,
#noo_bd .blog-title .noo-blog-control button:hover i,
#noo_bd .recent-tweets li .twitter_user .twitter_username,
#noo_bd .team-title .noo-team-control button:hover i,
#noo_bd .noo-product-footer .price span,
#noo_bd .noo-left-menu .cate-name,
#noo_bd .fa-navicon:before, .fa-reorder:before, .fa-bars:before,
#noo_bd .noo-infomation-cart ul li.phone i,
#noo_bd .noo-infomation-cart ul li.noo-menu-item-cart .cart-button .cart-item .icon-shopping,
#noo_bd .noo-sh-product2 .product-right .price,
#noo_bd .white-gold .product-left-content h3 a,
#noo_bd .white-gold .product-right .price,
#noo_bd .simple-product .simple-content .price,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta .price,
#noo_bd  .noo-onepage .noo-wrap-menu .noo-main-menu .navbar-nav li.current-menu-item > a,
#noo_bd .noo-onepage .noo-wrap-menu .noo-main-menu .navbar-nav li:hover > a,
#noo_bd .noo-onepage .noo-wrap-menu .noo-main-menu .navbar-nav li.current > a,
#noo_bd .noo_testimonial_two li .testimonial_wrap .testimonial-content .noo-quote-icon,
#noo_bd .onepage-footer .widget_noo_infomation_onpage .noo-one-footer i,
#noo_bd .masonry-filters-services .services-filters li a.selected,
#noo_bd .masonry-filters-services .services-filters li a:hover,
#noo_bd ul.product_list_widget li .amount,
#noo_bd .noo-product-footer .price del,
#noo_bd div.product div.summary .price,
#noo_bd div.product .woocommerce-tabs ul.tabs li.active a,
#noo_bd div.product .woocommerce-tabs ul.tabs li:hover a,
#noo_bd .noo-left-menu .menu-categories li a:hover,
#noo_bd .noo-topbar ul li a:hover,
#noo_bd .header-2 .noo-main-menu .navbar-nav li:hover > a,
#noo_bd .single-author-project .author-description .project-icon,
#noo_bd .noo-main-menu .navbar-nav li#nav-menu-item-simple-cart > a:hover,
#noo_bd .noo-custom-menu ul li a:hover,
#noo_bd .onepage-footer .widget_noo_infomation_onpage .onepage-social a:hover,
#noo_bd .widget_noo_services ul li a:hover,
.noo_team li .noo-team-item:hover .noo-team-info h4,
.single-navigation span:hover a, .single-navigation span:hover i,
.noo-main-menu .navbar-nav li:hover > a,
.noo-main-menu .navbar-nav li.current-menu-item > a, .noo-main-menu .navbar-nav li:hover > a
{
color: <?php echo esc_attr($color_two);  ?>;
}



/*
* background primary two
* ===============================
*/
#noo_bd .whychooseus.choose_style3:hover .choose-icon .background-line2,
#noo_bd .noo-main-menu .navbar-nav li > a:before,
#noo_bd .book-free,
#noo_bd .our-blog-item .blog-item:before,
#noo_bd .noo_team li .noo-team-item .noo-team-info:before,
#noo_bd .noo-main-menu .navbar-nav li#nav-menu-item-simple-cart > a span em,
#noo_bd .noo_pricing .pricing_header,
#noo_bd .noo-team-content .team-title:before,
#noo_bd .header-2 .noo-wrap-menu .noo-main-menu .navbar-nav > li.current-menu-item > a:before,
#noo_bd .header-2 .noo-wrap-menu .noo-main-menu .navbar-nav > li:hover > a:before,
#noo_bd .blog-item-default:before,
#noo_bd .noo-main-menu .navbar-nav li#nav-menu-item-simple-cart > a span em,
#noo_bd .noo_testimonial_two li:before,
#noo_bd .book-form,
#noo_bd .services-cat-title .cat-title-first .cat-title-last,
#noo_bd .noo-service-header,
#noo_bd .vc_tta-tabs.vc_tta-tabs-position-left .vc_tta-tabs-list,
#noo_bd .noo_testimonial_three li:before,
#noo_bd .submit-offer,
#noo_bd .title-coupons:before,
#noo_bd .noo-sidebar-wrap .widget-title,
#noo_bd .widget_search,
#noo_bd  #customer_details h3:before,
#noo_bd  .order_review_wrap #order_review_heading:before,
#noo_bd .noo-checkout-complete h2:before,
#noo_bd .noo-checkout-complete h3:before,
#noo_bd .book-free .book-content input[type="submit"]:hover,
#noo_bd .services-content .services-entry a:hover,
#noo_bd .noo-sh-button.sh-bk:hover,
#noo_bd .woo-thumbnail .noo-product-meta .entry-cart-meta a.add_to_cart_button:hover,
#noo_bd .woo-thumbnail .noo-product-meta .entry-cart-meta .yith-wcwl-add-to-wishlist .add_to_wishlist:hover,
#noo_bd .woo-thumbnail .noo-product-meta .entry-cart-meta .yith-wcwl-wishlistexistsbrowse a:hover,
#noo_bd .wpcf7-form input[type="submit"]:hover,
#noo_bd .noo-newsltter-form button:hover,
#noo_bd .product-left-content .shopnow:hover,
#noo_bd .simple-product .simple-content .entry-cart-meta a.add_to_cart_button:hover,
#noo_bd .simple-product .simple-content .entry-cart-meta .yith-wcwl-wishlistexistsbrowse a:hover,
#noo_bd .simple-product .simple-content .entry-cart-meta .yith-wcwl-wishlistaddedbrowse a:hover,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta a.add_to_cart_button:hover,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta .yith-wcwl-wishlistexistsbrowse a:hover,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta .yith-wcwl-wishlistaddedbrowse a:hover,
#noo_bd .noo-poster .noo-poster-bk .noo_poster_products li .entry-poster-meta .yith-wcwl-add-to-wishlist .add_to_wishlist:hover,
#noo_bd .simple-product .simple-content .entry-cart-meta .yith-wcwl-add-to-wishlist .add_to_wishlist:hover,
#noo_bd #comments #respond .form-submit input:hover,
#noo_bd div.product div.summary .cart .button:hover,
#noo_bd div.product div.summary .yith-wcwl-wishlistexistsbrowse a:hover,
#noo_bd div.product div.summary .yith-wcwl-wishlistaddedbrowse a:hover,
#noo_bd div.product #reviews #review_form_wrapper form .form-submit input:hover,
#noo_bd table.wishlist_table td.product-add-to-cart a:hover,
#noo_bd #payment #place_order:hover,
#noo_bd div.product div.summary .yith-wcwl-add-to-wishlist .add_to_wishlist:hover,
#noo_bd .cart input.button:hover,
#noo_bd .cart-collaterals .cart_totals .car_totals_wrap .wc-proceed-to-checkout a:hover,
#noo_bd input.button:hover,
#noo_bd form.lost_reset_password input[type='submit']:hover,
#noo_bd .cart-collaterals .cart_totals h2:before,
#noo_bd .project-sidebar-title,
#noo_bd .project-title:before,
#noo_bd #comments .comments-title:before,
#noo_bd .noo-sidebar-services .widget_noo_services .widget-title,
#noo_bd  .noo-sidebar-services .widget_noo_services,
#noo_bd .noo-sidebar-services .widget-title,
#noo_bd  #comments #respond .comment-reply-title:before,
#noo_bd .masonry-filters-project .project-filters li a.selected:before,
#noo_bd .masonry-filters-project .project-filters li a:hover:before,
#noo_bd .project-filter span.active:before,
#noo_bd .project-filter span:hover:before,
#noo_bd .your-money2 .money-right .noo-button:hover
{
background: <?php echo esc_attr($color_two);  ?>;
}


/*-----custom------*/
#noo_bd .pagination .page-numbers.current,
#noo_bd .pagination a.page-numbers:hover{
    background: <?php echo esc_attr($color_one);  ?>;
    border-color: <?php echo esc_attr($color_one);  ?>;
}
.noo-topbar ul li a{
    border-left-color: #fff;
}
#noo_bd .noo-news-slider li .noo-news-item:before{
    background: rgba(0,0,0,0.4);
}
#noo_bd .noo-page-heading .page-title{
    text-shadow: 3px 0px <?php echo esc_attr($color_two);  ?>;
    -moz-text-shadow: 3px 0px <?php echo esc_attr($color_two);  ?>;
    -webkit-text-shadow: 3px 0px <?php echo esc_attr($color_two);  ?>;
    -o-text-shadow: 3px 0px <?php echo esc_attr($color_two);  ?>;
}
#noo_bd .services-cat-title {
background: <?php echo esc_attr($color_two_70); ?>;
}
#noo_bd .services-cat-title .cat-title-first {
background: <?php echo esc_attr($color_two_50); ?>;
}
#noo_bd .services-cat-title .cat-title-first:before {
border-right-color: <?php echo esc_attr($color_two_50); ?>;
}
#noo_bd .services-cat-title .cat-title-first:after {
border-left-color: <?php echo esc_attr($color_two_50); ?>;
}

#noo_bd .services-cat-title .cat-title-first .cat-title-last:before {
border-right-color: <?php echo esc_attr($color_two);  ?>;
}
#noo_bd .services-cat-title .cat-title-first .cat-title-last:after {
border-left-color: <?php echo esc_attr($color_two);  ?>;
}
#noo_bd .header-5 .noo-wrap-menu .icon-search2{
    background: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .header-2 .noo-wrap-menu .noo-main-menu .navbar-nav > li > a:before{
    background: rgb(105, 105, 105);
}
#noo_bd .noo_pricing .pricing_header:before{
    border-top-color: <?php echo esc_attr($color_two);  ?>;
}
#noo_bd .noo-page-heading:before{
    background: <?php echo esc_attr($color_one_80);  ?>;
}
#noo_bd .services-header{
    background: <?php echo esc_attr($color_one_80);  ?>;
}
#noo_bd .woo-thumbnail .bk,
#noo_bd  .project-item .project-inner .project-bk:before{
    background: <?php echo esc_attr($color_one_80);  ?>;
}

#noo_bd .noo-sh-button.sh-bk span{
    border: 0;
    color: #fff;
}
#noo_bd .submit-offer .icon:before{
    border-left-color: <?php echo esc_attr($color_one);  ?>;
}
#noo_bd .noo-sh-button {
    color: <?php echo esc_attr($color_one);  ?>;
}
#noo_bd .noo-sh-button span{
	border-color: <?php echo esc_attr($color_one);  ?>;
}
#noo_bd .noo-sh-button:hover {
	color: <?php echo esc_attr($color_two);  ?>;	
}
#noo_bd .noo-sh-button:hover span {
	color: <?php //echo esc_attr($color_two);  ?>;
	border-color: <?php echo esc_attr($color_two);  ?>;
}

#noo_bd .money-icon span{
    background: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .money-icon:before {
    border-left-color:<?php echo esc_attr($color_one);  ?>;
}
#noo_bd .money-icon span:before {
    border-left-color: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .money-icon span:after {
    border-right-color: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd ul.owl-theme .owl-controls .owl-page.active span,
#noo_bd ul.owl-theme .owl-controls .owl-page:hover span{
    background: <?php echo esc_attr($color_one);  ?>;
}
#noo_bd ul.owl-theme .owl-controls .owl-page.active,
#noo_bd ul.owl-theme .owl-controls .owl-page:hover {
    border-color: <?php echo esc_attr($color_one_60);  ?>;
}
#noo_bd ul.owl-theme .owl-controls .owl-page.active:before,
#noo_bd ul.owl-theme .owl-controls .owl-page:hover:before {
    background: <?php echo esc_attr($color_one_60);  ?>;
}
#noo_bd ul.owl-theme .owl-controls .owl-page.active:after,
#noo_bd ul.owl-theme .owl-controls .owl-page:hover:after {
    background: <?php echo esc_attr($color_one_60);  ?>;
}

#noo_bd ul.owl-theme .owl-controls .owl-page.active span:before,
#noo_bd ul.owl-theme .owl-controls .owl-page:hover span:before {
    background: <?php echo esc_attr($color_one_60);  ?>;
}
#noo_bd ul.owl-theme .owl-controls .owl-page.active span:after,
#noo_bd ul.owl-theme .owl-controls .owl-page:hover span:after {
    background: <?php echo esc_attr($color_one_60);  ?>;
}

#noo_bd ul.owl-theme .owl-controls .owl-page span{
    background: <?php echo esc_attr($color_one_60);  ?>;
}

#noo_bd .whychooseus.choose_style3 .choose-icon{
    background:  <?php echo esc_attr($color_one);  ?>;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon .background-line{
    background:  <?php echo esc_attr($color_two);  ?>;
}
#noo_bd .whychooseus.choose_style3 .choose-icon:before {
    border-bottom: 29px solid <?php echo esc_attr($color_one);  ?>;
}
#noo_bd .whychooseus.choose_style3 .choose-icon:after {
    border-top: 29px solid <?php echo esc_attr($color_one);  ?>;
}

#noo_bd .whychooseus.choose_style3 .choose-icon .background-line {
    border-left: 3px solid <?php echo esc_attr($color_onelighten_10);  ?>;
    border-right: 3px solid <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .whychooseus.choose_style3 .choose-icon .background-line:before {
    background: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .whychooseus.choose_style3 .choose-icon .background-line:after {
    background: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .whychooseus.choose_style3 .choose-icon .background-line .background-line-bottom:before {
    background: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .whychooseus.choose_style3 .choose-icon .background-line .background-line-bottom:after {
    background: <?php echo esc_attr($color_onelighten_10);  ?>;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon {
    background: <?php echo esc_attr($color_two_30);  ?>;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon:before {
    border-bottom-color: <?php echo esc_attr($color_two_30);  ?>;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon:after {
border-top-color: <?php echo esc_attr($color_two_30);  ?>;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon .icon_first {
    opacity: 0;
    filter: alpha(opacity=0);
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon .icon_last {
    opacity: 1;
    filter: alpha(opacity=100);
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon .background-line {
    border: 0;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon .background-line:before {
    position: absolute;
    left: 0;
    bottom: 100%;
    top: auto;
    right: auto;
    content: '';
    border-left: 45px solid transparent;
    border-right: 45px solid transparent;
    border-bottom: 25px solid <?php echo esc_attr($color_two);  ?>;
    -webkit-transform: translate(0, 0);
    -ms-transform: translate(0, 0);
    -o-transform: translate(0, 0);
    transform: translate(0, 0);
    width: auto;
    height: auto;
    background: none;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon .background-line:after {
    position: absolute;
    left: 0;
    top: 100%;
    bottom: auto;
    right: auto;
    content: '';
    border-left: 45px solid transparent;
    border-right: 45px solid transparent;
    border-top: 25px solid <?php echo esc_attr($color_two);  ?>;
    -webkit-transform: translate(0, 0);
    -ms-transform: translate(0, 0);
    -o-transform: translate(0, 0);
    transform: translate(0, 0);
    width: auto;
    height: auto;
    background: none;
}
#noo_bd .whychooseus.choose_style3:hover .choose-icon .background-line .background-line-bottom {
    display: none;
}

.noo-news-slider li .noo-news-item .noo-container .cat a,
.vc_tta-tabs:not([class*="vc_tta-gap"]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab.vc_active > a,
.vc_tta-tabs:not([class*="vc_tta-gap"]):not(.vc_tta-o-no-fill).vc_tta-tabs-position-top .vc_tta-tab > a:hover,
.noo-product-footer .price span,
.noo-infomation-cart ul li.noo-menu-item-cart .cart-button .cart-item .icon-shopping,
.blog-title .noo-blog-control button:hover i,
.woocommerce ul.product_list_widget li .amount,
.single-product div.product div.summary .price,
.single-product div.product .woocommerce-tabs ul.tabs li.active a, .single-product div.product .woocommerce-tabs ul.tabs li:hover a,
.social-all a:hover,
.services-content .services-entry strong,
.noo-sh-button:hover,
.our-blog-item .blog-item.style2 .sh-entry-blog .cat a,
.team-title .noo-team-control button:hover i,
    .noo-sh-product2 .product-right .price
    {
    color: <?php echo esc_attr($color_two);  ?>;
}

.noo-bg-color:before, .noo-bg-color .vc_parallax-inners:before{
	background: <?php echo esc_attr($color_two_80); ?>
}

<?php endif; ?>
