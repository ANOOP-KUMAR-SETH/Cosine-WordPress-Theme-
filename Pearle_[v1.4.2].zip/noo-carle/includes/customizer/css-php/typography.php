<?php
// Variables
$noo_typo_use_custom_fonts = noo_get_option( 'noo_typo_use_custom_fonts', false );
$noo_typo_headings_uppercase = noo_get_option( 'noo_typo_headings_uppercase', false );
$noo_typo_body_font_size = noo_get_option( 'noo_typo_body_font_size', noo_get_theme_default( 'font_size' ) );
$noo_typo_body_font_color =  noo_get_option( 'noo_typo_body_font_color' ) ;

if( $noo_typo_use_custom_fonts ) :
	$noo_typo_headings_font = noo_get_option( 'noo_typo_headings_font', noo_get_theme_default( 'headings_font' ) );
	$noo_typo_headings_font_weight = noo_get_option( 'noo_typo_headings_font_weight', 'bold' );
	$noo_typo_headings_uppercase = noo_get_option( 'noo_typo_headings_uppercase', false );
    $noo_typo_headings_color = noo_get_option( 'noo_typo_headings_font_color' );

	$noo_typo_body_font = noo_get_option( 'noo_typo_body_font', noo_get_theme_default( 'font_family' ) );
	$noo_typo_body_font_style = noo_get_option( 'noo_typo_body_font_style', 'normal' );
	$noo_typo_body_font_weight = noo_get_option( 'noo_typo_body_font_weight', noo_get_theme_default( 'font_weight' ) );

?>

    /* Body style */
    /* ===================== */
     body {
        font-family: "<?php echo esc_html( $noo_typo_body_font ); ?>", sans-serif;
        font-size: <?php echo esc_html( $noo_typo_body_font_size ) . 'px'; ?>;
        font-style: <?php echo esc_html( $noo_typo_body_font_style ); ?>;
        font-weight: <?php echo esc_html( $noo_typo_body_font_weight ); ?>;
    }

    /* Headings */
    /* ====================== */
    h1, h2, h3, h4, h5, h6,
    .h1, .h2, .h3, .h4, .h5, .h6 {
        font-family:    "<?php echo esc_html( $noo_typo_headings_font ); ?>", sans-serif;
        font-weight:    <?php echo esc_html( $noo_typo_headings_font_weight ); ?> !important;
        <?php if ( $noo_typo_headings_uppercase != false ) : ?>
            text-transform: uppercase !important;
        <?php else : ?>
            text-transform: none !important;
        <?php endif; ?>
    }
    h1, h2, h3, h4, h5, h6,
    .h1, .h2, .h3, .h4, .h5, .h6,
    h1 a, h2 a, h3 a, h4 a, h5 a, h6 a,
    .h1 a, .h2 a, .h3 a, .h4 a, .h5 a, .h6 a {
    color: <?php echo esc_html($noo_typo_headings_color); ?> !important;
    }

<?php else : ?>

/* Body style */
/* ===================== */
     body {
        font-size: <?php echo esc_html( $noo_typo_body_font_size ) . 'px'; ?>;
    }

    /* Headings */
    /* ====================== */
    h1, h2, h3, h4, h5, h6,
    .h1, .h2, .h3, .h4, .h5, .h6 {
        <?php if ( $noo_typo_headings_uppercase != false ) : ?>
            text-transform: uppercase;
        <?php else : ?>
            text-transform: none;
        <?php endif; ?>
    }

<?php endif; ?>