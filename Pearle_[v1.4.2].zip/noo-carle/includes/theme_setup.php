<?php
/**
 * Initialize Theme functions for NOO Themes.
 *
 * @package    NOO Themes
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */

// Content Width
if ( ! isset( $content_width ) ) :
	$content_width = 970;
endif;

// Initialize Theme
if (!function_exists('noo_init_theme')):
	function noo_init_theme() {
		load_theme_textdomain( 'noo-carle', get_template_directory() . '/languages' );

		require_once( NOO_FRAMEWORK . '/libs/noo-check-version.php' );
 
        if ( is_admin() ) {     
            $license_manager = new Noo_Check_Version(
                'noo-carle',
                'Noo Pearle',
                'http://update.nootheme.com/api/license-manager/v1',
                'theme',
                '',
                false
            );
        }

		// Title Tag -- From WordPress 4.1.
		add_theme_support('title-tag');
		// @TODO: Automatic feed links.
		add_theme_support('automatic-feed-links');
		// Add support for some post formats.
		add_theme_support('post-formats', array(
			'image',
			'gallery',
			'video',
			'audio'
		));

		add_theme_support( 'woocommerce' );

		// WordPress menus location.
		$menu_list = array();
		
		$menu_list['primary'] = esc_html__('Primary Menu', 'noo-carle');
        $menu_list['categories'] = esc_html__('Categories Menu', 'noo-carle');
        $menu_list['onepage'] = esc_html__('One Page Menu', 'noo-carle');

		if (noo_get_option( 'noo_header_top_bar', false ) && (noo_get_option('noo_top_bar_type', 'menu') == 'menu') ) {
			$menu_list['top-menu'] = esc_html__('Top Menu', 'noo-carle');
		}
		
		if (noo_get_option('noo_footer_top', false)) {
			$menu_list['footer-menu'] = esc_html__('Footer Menu', 'noo-carle');
		}

		// Register Menu
		register_nav_menus($menu_list);

		// Define image size
		add_theme_support('post-thumbnails');
		
		add_image_size('noo-thumbnail-square',600,450, true);

        add_image_size('noo-woo-thumbnail',270,350, true);

        add_image_size('noo-landscaping',800,600, true);

        add_image_size('noo-square',700,700, true);

		$default_values = array( 
				'primafy_color'         => '#000',
				'secondary_color'       => '#000',
				'font_family'           => 'Open Sans',
				'text_color'            => '#000',
				'font_size'             => '14',
				'font_weight'           => '400',
				'headings_font_family'  => 'Open Sans',
				'headings_color'        => '#000',
				'logo_color'            => '#000',
				'logo_font_family'      => 'Open Sans',
			);
		noo_set_theme_default( $default_values );
	}
	add_action('after_setup_theme', 'noo_init_theme');
endif;

// Deactivate libraries plugins
// This function used when moving custom post type from plugin to theme
if ( ! function_exists( 'noo_deactivate_plugins' ) ) :
	function noo_deactivate_plugins() {
		// if ( is_plugin_active( 'noo_notica_subscribe/plugin.php' ) ) {
		// 	deactivate_plugins( 'noo_notica_subscribe/plugin.php' );
		// }
	}
	// add_action( 'admin_init', 'noo_deactivate_plugins' );
endif;