<?php get_header(); ?>

<div class="container-wrap">
	
	<div class="noo-container">

        <div id="error-404">
            <h1><?php echo esc_html__('404', 'noo-carle'); ?></h1>
            <h2><?php echo esc_html__('Not Found.', 'noo-carle'); ?></h2>
        </div>
		
	</div><!--/container-->

</div>
<?php get_footer(); ?>

