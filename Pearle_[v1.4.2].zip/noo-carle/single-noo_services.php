
<?php get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main noo-container">
            <?php
                if( have_posts() ):
                    $theme_style = noo_get_option('noo_choose_theme','theme-carle');

                    if( $theme_style == 'theme-carle' ){

                        while( have_posts() ): the_post();

                            $price      = noo_get_post_meta(get_the_ID(),'_price');
                            $properties = noo_get_post_meta(get_the_ID(),'_properties');
                            $download   = noo_get_post_meta(get_the_ID(),'_attach');   ?>

                            <div class="noo-service-header">
                                <div class="noo-row">
                                    <div class="noo-md-8 noo-thumbnail">
                                        <?php the_post_thumbnail('full'); ?>
                                    </div>
                                    <div class="noo-md-4">
                                        <div class="noo-service-attr">
                                            <h2><?php the_title(); ?></h2>
                                            <ul>
                                                <li class="price">
                                                    <span><?php echo esc_html__('Estimated Pricing','noo-carle'); ?></span>
                                                    <span><?php echo esc_html($price); ?></span>
                                                </li>
                                                <?php if( isset($properties) && !empty($properties) ): ?>
                                                        <?php foreach($properties as $pro): ?>
                                                            <li>
                                                                <span><?php echo esc_html($pro['label']); ?></span>
                                                                <span><?php echo esc_html($pro['value']); ?></span>
                                                            </li>
                                                        <?php endforeach; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="noo-md-8 noo-md-offset-2">
                                    <div class="noo-service-content">
                                        <?php
                                            the_content();
                                            wp_link_pages();
                                        ?>
                                        <?php if( isset($download) && !empty($download) ): ?>
                                            <div class="download">
                                                <a href="<?php echo esc_url($download) ?>"><?php echo esc_html__('Download pricing table','noo-carle'); ?></a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                    <?php endwhile;

                    }else{ ?>
                        <div class="noo-md-8">
                            <?php while( have_posts() ): the_post(); ?>

                                <!--Content-->
                                <div class="single-servies">
                                    <?php
                                    the_content();
                                    wp_link_pages();
                                    ?>
                                </div>
                                <!--End Content-->

                            <?php endwhile; // end while( have_post) ?>

                            <div class="related-services">
                                <?php
                                $cat = get_the_terms(get_the_ID(),'services_category');
                                if( isset($cat[0]) && !empty($cat[0]) ):

                                    $args = array(
                                        'post_type'         =>  'noo_services',
                                        'posts_per_page'    =>  3,
                                        'post__not_in'      =>  array(get_the_ID()),
                                        'tax_query'       =>  array(
                                            array(
                                                'taxonomy'     =>  'services_category',
                                                'field'        =>  'term_id',
                                                'terms'         =>  $cat[0]->term_id
                                            )
                                        )
                                    );
                                    $query = new WP_Query( $args );
                                    if( $query->have_posts() ):

                                        ?>
                                        <h2 class="project-title"><?php echo esc_html__('Related Services','noo-carle'); ?></h2>

                                        <div class="noo-row">
                                            <?php  while( $query->have_posts() ):
                                                         $query->the_post();  ?>
                                                        <div class="noo-md-4 noo-sm-6">
                                                            <div class="project-item">
                                                                <div class="project-inner">
                                                                    <a href="<?php the_permalink() ?>" class="project-bk">
                                                                        <?php the_post_thumbnail('large') ?>
                                                                    </a>
                                                                    <div class="project-ds">
                                                                        <span class="cat"><?php the_terms(get_the_ID(),'services_category','',','); ?></span>
                                                                        <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                            <?php endwhile; // end while( have_post) ?>
                                        </div>

                                    <?php endif; // end if(have_post)
                                    wp_reset_postdata();
                                endif; // end if check cat
                                ?>
                            </div>
                        </div><!--end md-8-->

                        <div class="noo-md-4">
                            <div class="noo-sidebar-services">
                                <?php // Dynamic Sidebar
                                if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( 'noo-services-w' ) ) : ?>
                                    <!-- Sidebar fallback content -->

                                <?php endif; // End Dynamic Sidebar sidebar-main ?>
                            </div>
                        </div>
                    <?php } // end check theme style
                endif;

            ?>

    </main><!-- .site-main -->
</div><!-- .content-area -->


<?php get_footer(); ?>