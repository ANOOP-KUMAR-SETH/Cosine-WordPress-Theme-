function NooScrollTop() {
    var $fixed          = jQuery('.fixed_top');
    if( $fixed.length > 0 ){
        var $_height   = $fixed.height();
        var $_top = jQuery(window).scrollTop();

        $topbar_height = 0;
        if( jQuery('.noo-topbar').length > 0 ){
            var $topbar = jQuery('.noo-topbar');
            var $topbar_height = $topbar.innerHeight();
        }

        var $height_nav2   = jQuery('.header-2 .noo-wrap-menu').height();


        // header default
        if( $_top >= $topbar_height ){
            jQuery('.header-default .noo-nav-header4, .header-3 .noo-nav-header4, .header-4 .noo-nav-header4').addClass('fixed_top_eff');
        }else{
            jQuery('.header-default .noo-nav-header4, .header-3 .noo-nav-header4, .header-4 .noo-nav-header4').removeClass('fixed_top_eff');
        }

        // header 2
        var $header2 = $_height - $height_nav2;
        if( $_top >= $header2 ){
            jQuery('.header-style2 .noo-wrap-menu').addClass('fixed_top_eff');
        }else{
            jQuery('.header-style2 .noo-wrap-menu').removeClass('fixed_top_eff');
        }

        // header 5
        var $header5 = $height_nav2 - 35;
        if( $_top >= $header5 ){
            jQuery('.header-5 .noo-header4-position').addClass('fixed_top_eff2');
        }else{
            jQuery('.header-5 .noo-header4-position').removeClass('fixed_top_eff2');
        }

    }
}

function NooScrollOnepage(){
    if(jQuery('.noo-revo').length > 0){
        var $_revo      = jQuery('.noo-revo').height();
        var _top          = jQuery(window).scrollTop();

        if( _top >= $_revo ){
            jQuery('.noo-onepage').addClass('noo-onepage-eff');
            jQuery('body').addClass('padding-top');
        }else{
            jQuery('.noo-onepage').removeClass('noo-onepage-eff');
            jQuery('body').removeClass('padding-top');
        }
    }
}

jQuery(document).ready(function(){
    "use strict";
    NooScrollTop();
    if( jQuery('.nav-onepage').length > 0 ){
    jQuery('.nav-onepage').onePageNav();
    }

    if( jQuery('.nav-dropdown').length > 0 ){
        jQuery('.nav-dropdown ul li').click(function(){
            var $_control =  jQuery(this);
            var $name     =  $_control.attr('data-name');
            var $id       =  $_control.attr('data-id');
            jQuery('.cat_name').text($name);
            jQuery('.cat_name').attr('data-id',$id);
        });
    }

    // method search product
    jQuery('.search_ajax_value').keyup(function(){
        var $_value = jQuery(this).val();
        var $catid = jQuery('.cat_name').attr('data-id');
        if( $_value.length >= 3 ){
            jQuery('.search-input').addClass('eff_search');
            jQuery('.returs_ajax').html('').removeClass('returs_ajax_aff');
            jQuery.ajax({
               url: noo_admin.ajax_url,
               type: 'post',
                data: ({
                    action: 'noo_search_ajax_products',
                    title: $_value,
                    catid: $catid
                }),
                success: function(data){
                    if(data){
                        jQuery('.returs_ajax').html(data).addClass('returs_ajax_aff');
                        jQuery('.search-input').removeClass('eff_search');
                    }else{
                        jQuery('.search-input').removeClass('eff_search');
                    }
                }
            });
        }else{
            jQuery('.returs_ajax').html('').removeClass('returs_ajax_aff');
            jQuery('.search-input').removeClass('eff_search');
        }
    });


    // noo seach
    jQuery('.icon-search2').click(function(){
       jQuery('.search-header5').fadeIn(1).addClass('search-header-eff');
    });
    jQuery('.search-remove').click(function(){
       jQuery('.search-header5').fadeOut(1).removeClass('search-header-eff');
    });



    // noo team
    jQuery('.noo-team-item').click(function(){
        var $id = jQuery(this).attr('data-option-id');
        jQuery('.noo-team-fix').addClass('db');

        jQuery.ajax({
           url: noo_admin.ajax_url,
           type: 'POST',
            data: ({
                action: 'noo_team_detail',
                id:     $id
            }),
            success: function(data){
                if(data){
                    jQuery('.noo-team-fix').addClass('bk-noimage');
                    jQuery('.noo-team-wrap').html(data);
                    jQuery('.noo-team-wrap').animate({
                        'top': '50%',
                        opacity: 1
                    },350,function(){

                    });

                    jQuery('.team-remove').click(function(){

                        jQuery('.noo-team-wrap').animate({
                            'top': '80%',
                            opacity: 0
                        },350,function(){
                            jQuery('.noo-team-fix').removeClass('bk-noimage');
                            jQuery('.noo-team-fix').removeClass('db');
                        });

                    });
                }
            }
        });

    });

    // noo project slider
    jQuery('.project-filter span').live('click',function(){
        var $parent = jQuery(this).parent().parent();
        $parent.find('.project-filter span').removeClass('active');
        jQuery(this).addClass('active');
        $parent.find('.project-wrap').animate({
            opacity: 0.25
        },100);
        $parent.find('.project-wrap').addClass('eff');
        var $cat_id = jQuery(this).attr('data-option-id');
        var $limit = jQuery(this).attr('data-option-limit');
        jQuery.ajax({
            url: noo_admin.ajax_url,
            type: 'POST',
            data: ({
                action: 'noo_project_slider',
                catid: $cat_id,
                limit: $limit
            }),
            success: function(data){
                jQuery('.project-wrap').html(data);
                $parent.find('.project-wrap').removeClass('eff');

                jQuery('.project-wrap').animate({
                    opacity: 1
                },700);
                jQuery('.noo-project-slider').each(function(){
                    jQuery(this).owlCarousel({
                        items : 4,
                        itemsDesktop : [1199,4],
                        itemsDesktopSmall : [979,3],
                        itemsTablet: [768, 2],
                        slideSpeed:500,
                        paginationSpeed:800,
                        rewindSpeed:1000,
                        autoHeight: false,
                        addClassActive: true,
                        autoPlay: false,
                        loop:true,
                        pagination: true
                    });
                });

            }
        })
    });

    var sync1 = jQuery(".sync1");
    var sync2 = jQuery(".sync2");

    sync1.owlCarousel({
        singleItem : true,
        slideSpeed : 1000,
        navigation: false,
        pagination:false,
        autoHeight : true,
        responsiveRefreshRate : 200
    });

    sync2.owlCarousel({
        items : 5,
        itemsDesktop      : [1199,5],
        itemsDesktopSmall     : [979,5],
        itemsTablet       : [768,5],
        itemsMobile       : [479,2],
        pagination:false,
        responsiveRefreshRate : 100
    });

    sync2.on("click", ".owl-item", function(e){
        e.preventDefault();
        var number = jQuery(this).data("owlItem");
        sync1.trigger("owl.goTo",number);
    });


    jQuery('.control-appoinment').click(function(){
        jQuery('.noo-appoinment').toggleClass('eff');
    });


});

jQuery(window).scroll(function(){
    "use strict";
    NooScrollOnepage();
    NooScrollTop();
});

