<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <!--Start featured-->
    <?php if( noo_has_featured_content()) : ?>
        <div class="content-featured">
            <?php noo_featured_default(); ?>
        </div>
    <?php endif; ?>
    <!--Start end featured-->

    <!--Start content for post-->
    <div class="entry-content-wrap">
        <div class="author-avatar">
            <?php echo get_avatar( get_the_author_meta( 'user_email' ),70); ?>
            <h5>
                <a title="<?php printf( esc_html__( 'Post by %s','noo-carle'), get_the_author() ); ?>" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author">
                    <?php echo get_the_author() ?>
                </a>
            </h5>
            <?php noo_author_blog_social(); ?>

        </div>
        <div class="entry-content">
            <span class="cat">
                <?php echo get_the_category_list( ', ' ); ?>
            </span>
            <h2>
                <a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permanent link to: "%s"','noo-carle' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php the_title(); ?></a>
            </h2>

            <!--Start content-->
            <div class="entry-excerpt">
                <?php if(get_the_excerpt()):?>
                    <?php the_excerpt(); ?>
                <?php endif;?>
            </div>
            <!--Start end content-->

            <div class="entry-post-footer">
                <span class="entry-post-date">
                    <i class="fa fa-calendar"></i>
                    <?php echo get_the_date(); ?>
                </span>
                <span class="entry-post-comment">
                    <i class="fa fa-comments"></i>
                    <?php comments_popup_link( esc_html__( 'Leave a comment', 'noo-carle' ), esc_html__( '1 Comment', 'noo-carle' ), esc_html__( '% Comments', 'noo-carle' ) ); ?>
                </span>
            </div>
        </div>
    </div>
    <!--End content for post-->

</article> <!-- /#post- -->