<?php
/**
 * The main template file
 *
 */

get_header(); ?>
<div class="services-header"></div>
<div id="primary" class="content-area">
    <main id="main" class="site-main noo-container">

                <?php if ( have_posts() ) : ?>
                    <?php
                    // Start the loop.
                    while ( have_posts() ) : the_post();
                        /*
                         * Include the Post-Format-specific template for the content.
                         * If you want to override this in a child theme, then include a file
                         * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                         */
                        ?>

                        <article class="noo-portfolio-list">
                            <div class="noo-list-img">
                                <a href="<?php the_permalink() ?>">
                                    <?php the_post_thumbnail('noo-thumbnail-square') ?>
                                </a>
                            </div>
                            <div class="noo-list-content">
                                <span class="noo-cat"><?php  the_terms(get_the_ID(), 'project_category'); ?></span>
                                <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                                <?php the_excerpt(); ?>
                                <a class="read-more" href="<?php the_permalink(); ?>"><?php esc_html_e('Read more', 'noo-carle'); ?></a>
                            </div>
                        </article>
                    <?php

                        // End the loop.
                    endwhile;

                endif;
                ?>

    </main><!-- .site-main -->
</div><!-- .content-area -->

<?php get_footer(); ?>
