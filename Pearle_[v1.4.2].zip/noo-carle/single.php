
<?php get_header();

$author = noo_get_option('noo_blog_post_author_bio');
$tags = noo_get_option('noo_blog_post_show_post_meta');
$social = noo_get_option('noo_blog_social');

?>

<div id="primary" class="content-area">
    <main id="main" class="site-main noo-container">
        <div class="noo-row">
            <div class="<?php noo_main_class(); ?>">
                <?php
                    // Start the loop.
                    while ( have_posts() ) : the_post();

                        ?>

                        <!--single header-->
                        <span class="single-cat">
                            <?php echo get_the_category_list( ', ' ); ?>
                        </span>
                        <h1 class="single-title">
                            <?php the_title(); ?>
                        </h1>
                        <!--End single header-->

                        <?php
                            echo '<div class="single-thumbnail">';
                                switch(get_post_format()):
                                    case'image':
                                        noo_featured_default();
                                        break;
                                    case'audio':
                                        noo_featured_audio();
                                        break;
                                    case'gallery':
                                        noo_featured_gallery();
                                        break;
                                    case'video':
                                        $embed 	= noo_get_post_meta( get_the_ID(), "_noo_wp_post_video_embed", '' );
                                        echo stripslashes( htmlspecialchars_decode( $embed ) );
                                        break;
                                    default:
                                        noo_featured_default();
                                        break;
                                endswitch;
                            echo '</div>';

                        ?>

                        <!--Content-->
                        <div class="single-content">
                            <?php
                                the_content();
                                wp_link_pages();
                            ?>
                        </div>
                        <!--End Content-->

                        <!--Single meta-->
                        <?php if( $tags != false || $social != false ): ?>
                            <div class="single-meta">
                                <div class="noo-row">
                                    <div class="single-meta-left noo-md-7">
                                        <?php if( $tags != false ): ?>
                                            <span><?php echo esc_html__('tags:','noo-carle'); ?></span>
                                            <?php echo get_the_tag_list('','/ ') ?>
                                        <?php endif; ?>
                                    </div>
                                    <?php if( $social != false ): ?>
                                    <div class="single-meta-right noo-md-5">
                                        <?php noo_social_share(); ?>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <!--End single meta-->

                        <!--Single author-->
                        <?php if( $author != false ): ?>
                            <div class="single-author-bio noo-row">
                                <div class="author-avatar noo-md-3">
                                    <?php echo get_avatar( get_the_author_meta( 'user_email' ),70); ?>
                                    <h5>
                                        <a title="<?php printf( esc_html__( 'Post by %s','noo-carle'), get_the_author() ); ?>" href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" rel="author">
                                            <?php echo get_the_author() ?>
                                        </a>
                                    </h5>
                                    <?php noo_author_blog_social(); ?>

                                </div>
                                <div class="author-description noo-md-9">
                                    <?php echo get_the_author_meta('description'); ?>
                                </div>
                            </div>
                        <?php endif; ?>
                        <!--End single author-->

                        <!--Start navigation-->
                        <nav class="single-navigation">
                            <span class="s-prev"><?php  echo get_previous_post_link( '%link', _x( '<i class="fa fa-long-arrow-left"></i> %title', 'Previous post link', 'noo-carle' ) ); ?></span>
                            <span class="s-next"><?php  echo get_next_post_link( '%link', _x( '%title <i class="fa fa-long-arrow-right"></i>', 'Next post link', 'noo-carle' ) ); ?></span>
                        </nav>
                        <!--End navigation-->

                        <?php
                        // If comments are open or we have at least one comment, load up the comment template.
                        if ( comments_open() || get_comments_number() ) :
                            comments_template();
                        endif;

                        // End the loop.
                    endwhile;
                ?>
            </div>
            <?php get_sidebar(); ?>
        </div>


    </main><!-- .site-main -->
</div><!-- .content-area -->


<?php get_footer(); ?>