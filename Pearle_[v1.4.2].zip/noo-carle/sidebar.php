
<?php
$sidebar = noo_get_sidebar_id();
$check_layout = noo_get_page_layout();
if( ! empty( $sidebar ) && $check_layout != 'fullwidth' ) :

?>
<div class="<?php noo_sidebar_class(); ?>">
	<div class="noo-sidebar-wrap">
		<?php // Dynamic Sidebar
		if ( ! function_exists( 'dynamic_sidebar' ) || ! dynamic_sidebar( $sidebar ) ) : ?>
			<!-- Sidebar fallback content -->

		<?php endif; // End Dynamic Sidebar sidebar-main ?>
	</div>
</div>
<?php endif; // End sidebar ?> 
