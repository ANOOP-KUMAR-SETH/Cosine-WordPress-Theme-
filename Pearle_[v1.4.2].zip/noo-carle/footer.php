<?php if( !is_page_template('page-teamplate-print.php') ): ?>
    <?php
        $num = ( noo_get_option( 'noo_footer_widgets', '4' ) == '' ) ? '4' : noo_get_option( 'noo_footer_widgets', '4' );
        $background = noo_get_option('noo_footer_background','');
    ?>
        <?php if( is_page_template('page-onepage.php') ): ?>
            <footer class="onepage-footer">
                <div class="colophon wigetized">
                    <div class="noo-container">
                        <?php  dynamic_sidebar( 'noo-footer-onepage' ); ?>
                    </div>
                </div>
            </footer>
        <?php else: ?>
            <footer class="wrap-footer" <?php if( isset( $background ) && !empty($background)): ?> style="background-image: url('<?php echo esc_url($background); ?>') ;" <?php endif; ?>>
                <?php if ( $num != 0  ) : ?>
                    <!--Start footer widget-->
                    <div class="colophon wigetized">
                        <div class="noo-container">
                            <div class="noo-row">
                                <?php

                                $i = 0; while ( $i < $num ) : $i ++;
                                    switch ( $num ) {
                                        case 4 :
                                            $class = 'noo-md-custom noo-footer-4';
                                            break;
                                        case 3 :
                                            $class = 'noo-md-4 noo-sm-4';
                                            break;
                                        case 2 : $class = 'noo-md-6 noo-sm-12';  break;
                                        case 1 : $class = 'noo-md-12'; break;
                                    }
                                    if( $i == 1 && $num == 4){
                                        $class = 'noo-md-4 noo-sm-6 noo-footer-4';
                                    }
                                    ?>
                                    <div class="<?php echo esc_attr($class); ?>">
                                        <?php
                                        if( function_exists('dynamic_sidebar') && dynamic_sidebar( 'noo-footer-' . esc_attr($i) ) ):
                                        else:
                                            ?>
                                            <aside class="widget">
                                                <h4 class="widget-title">Footer <?php echo esc_attr($i); ?></h4>
                                                <a class="demo-widgets" href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>"><?php echo esc_html__( 'Click here to add your widgets', 'noo-carle' ); ?></a>
                                            </aside>
                                        <?php endif; ?>
                                    </div>
                                    <?php
                                endwhile;

                                ?>
                            </div>
                        </div>
                    </div>
                    <!--End footer widget-->
                <?php endif; ?>

                </footer>
        <?php endif; ?>
    </div>
    <!--End .site -->

 <?php endif; ?>

<?php wp_footer(); ?>

</body>
</html>
