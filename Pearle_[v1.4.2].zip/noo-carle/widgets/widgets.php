<?php

class Noo_Wiget extends WP_Widget {

	public $widget_cssclass;

	public $widget_description;

	public $widget_id;

	public $widget_name;

	public $settings;

	public $cached = true;

	/**
	 * Constructor
	 */
	public function __construct() {
		$widget_ops = array( 'classname' => $this->widget_cssclass, 'description' => $this->widget_description );
		
		$this->WP_Widget( $this->widget_id, $this->widget_name, $widget_ops );
		if ( $this->cached ) {
			add_action( 'save_post', array( $this, 'flush_widget_cache' ) );
			add_action( 'deleted_post', array( $this, 'flush_widget_cache' ) );
			add_action( 'switch_theme', array( $this, 'flush_widget_cache' ) );
		}
	}

	/**
	 * get_cached_widget function.
	 */
	function get_cached_widget( $args ) {
		$cache = wp_cache_get( apply_filters( 'dh_cached_widget_id', $this->widget_id ), 'widget' );
		
		if ( ! is_array( $cache ) ) {
			$cache = array();
		}
		
		if ( isset( $cache[$args['widget_id']] ) ) {
			echo $cache[$args['widget_id']];
			return true;
		}
		
		return false;
	}

	/**
	 * Cache the widget
	 * @param string $content
	 */
	public function cache_widget( $args, $content ) {
		$cache[$args['widget_id']] = $content;
		
		wp_cache_set( apply_filters( 'dh_cached_widget_id', $this->widget_id ), $cache, 'widget' );
	}

	/**
	 * Flush the cache
	 *
	 * @return void
	 */
	public function flush_widget_cache() {
		wp_cache_delete( apply_filters( 'dh_cached_widget_id', $this->widget_id ), 'widget' );
	}

	/**
	 * update function.
	 *
	 * @see WP_Widget->update
	 * @param array $new_instance
	 * @param array $old_instance
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		
		if ( ! $this->settings ) {
			return $instance;
		}
		
		foreach ( $this->settings as $key => $setting ) {
			
			if ( isset( $setting['multiple'] ) ) :
				$instance[$key] = implode( ',', $new_instance[$key] );
			 else :
				if ( isset( $new_instance[$key] ) ) {
					$instance[$key] = sanitize_text_field( $new_instance[$key] );
				} elseif ( 'checkbox' === $setting['type'] ) {
					$instance[$key] = 0;
				}
			endif;
		}
		if ( $this->cached ) {
			$this->flush_widget_cache();
		}
		
		return $instance;
	}

	/**
	 * form function.
	 *
	 * @see WP_Widget->form
	 * @param array $instance
	 */
	public function form( $instance ) {
		if ( ! $this->settings ) {
			return;
		}
		foreach ( $this->settings as $key => $setting ) {
			$value = isset( $instance[$key] ) ? $instance[$key] : $setting['std'];
			switch ( $setting['type'] ) {
				case "text" :
					?>
					<p>
						<label for="<?php echo $this->get_field_id( $key ); ?>"><?php echo esc_html($setting['label']); ?></label>
						<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo $this->get_field_name( $key ); ?>" type="text" value="<?php echo esc_attr( $value ); ?>" />
					</p>
					<?php
					break;
				
				case "number" :
					?>
					<p>
						<label for="<?php echo $this->get_field_id( $key ); ?>"><?php echo esc_html($setting['label']); ?></label>
						<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo $this->get_field_name( $key ); ?>" type="number" step="<?php echo esc_attr( $setting['step'] ); ?>" min="<?php echo esc_attr( $setting['min'] ); ?>" max="<?php echo esc_attr( $setting['max'] ); ?>" value="<?php echo esc_attr( $value ); ?>" />
					</p>
					<?php
					break;
				case "select" :
					if ( isset( $setting['multiple'] ) ) :
						$value = explode( ',', $value );					
					endif;
					?>
					<p>
						<label for="<?php echo $this->get_field_id( $key ); ?>"><?php echo esc_html($setting['label']); ?></label>
						<select class="widefat" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" <?php if(isset($setting['multiple'])):?> multiple="multiple" <?php endif;?> name="<?php echo $this->get_field_name( $key ); ?><?php if(isset($setting['multiple'])):?>[]<?php endif;?>">
							<?php foreach ( $setting['options'] as $option_key => $option_value ) : ?>
								<option value="<?php echo esc_attr( $option_key ); ?>"
								<?php if(isset($setting['multiple'])): selected( in_array ( $option_key, $value ) , true ); else: selected( $option_key, $value ); endif; ?>><?php echo esc_html( $option_value ); ?></option>
							<?php endforeach; ?>
						</select>
					</p>
					<?php
					break;
				
				case "checkbox" :
					?>
					<p>
						<input id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>" type="checkbox" value="1" <?php checked( $value, 1 ); ?> /> <label for="<?php echo $this->get_field_id( $key ); ?>"><?php echo $setting['label']; ?></label>
					</p>
					<?php
					break;
			}
		}
	}
}




class Noo_Widget_Categories extends WP_Widget {

	public function __construct() {
		$widget_ops = array( 'classname' => 'widget_noo_categories', 'description' => esc_html__( "A list or dropdown of categories.",'noo-carle' ) );
		parent::__construct('noo_categories', esc_html__('Noo Categories','noo-carle'), $widget_ops);
	}

	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? esc_html__( 'Categories','noo-carle' ) : $instance['title'], $instance, $this->id_base );
		$c = ! empty( $instance['count'] ) ? '1' : '0';
		$h = ! empty( $instance['hierarchical'] ) ? '1' : '0';
		$p = ! empty( $instance['parent'] ) ? 0 : '';
		echo $args['before_widget'];
		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		$cat_args = array('orderby' => 'name', 'show_count' => $c, 'parent' => $p, 'hierarchical' => $h);
?>
		<ul>
<?php
		$cat_args['title_li'] = '';

		/**
		 * Filter the arguments for the Categories widget.
		 *
		 * @since 2.8.0
		 *
		 * @param array $cat_args An array of Categories widget options.
		 */
		wp_list_categories( apply_filters( 'widget_noo_categories_args', $cat_args ) );
?>
		</ul>
<?php

		echo $args['after_widget'];
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['count'] = !empty($new_instance['count']) ? 1 : 0;
		$instance['hierarchical'] = !empty($new_instance['hierarchical']) ? 1 : 0;
		$instance['parent'] = !empty($new_instance['parent']) ? 1 : 0;

		return $instance;
	}

	public function form( $instance ) {
		//Defaults
		$instance = wp_parse_args( (array) $instance, array( 'title' => '') );
		$title = esc_attr( $instance['title'] );
		$count = isset($instance['count']) ? (bool) $instance['count'] :false;
		$hierarchical = isset( $instance['hierarchical'] ) ? (bool) $instance['hierarchical'] : false;
		$parent = isset( $instance['parent'] ) ? (bool) $instance['parent'] : false;
?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e( 'Title:','noo-carle' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('count'); ?>" name="<?php echo $this->get_field_name('count'); ?>"<?php checked( $count ); ?> />
		<label for="<?php echo $this->get_field_id('count'); ?>"><?php esc_html_e( 'Show post counts','noo-carle' ); ?></label><br />

		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('hierarchical'); ?>" name="<?php echo $this->get_field_name('hierarchical'); ?>"<?php checked( $hierarchical ); ?> />
		<label for="<?php echo $this->get_field_id('hierarchical'); ?>"><?php esc_html_e( 'Show hierarchy','noo-carle' ); ?></label></p>

		<input type="checkbox" class="checkbox" id="<?php echo $this->get_field_id('parent'); ?>" name="<?php echo $this->get_field_name('parent'); ?>"<?php checked( $parent ); ?> />
		<label for="<?php echo $this->get_field_id('parent'); ?>"><?php esc_html_e( 'Only Show Parent','noo-carle' ); ?></label></p>
<?php
	}
}

register_widget('Noo_Widget_Categories');
class WP_Widget_Recent_News extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget_recent_news', 'description' => esc_html__( "Your site&#8217;s most recent Posts.",'noo-carle') );
		parent::__construct('recent-news', esc_html__('Recent News','noo-carle'), $widget_ops);
		$this->alt_option_name = 'widget_recent_news';

		add_action( 'save_post', array($this, 'flush_widget_cache') );
		add_action( 'deleted_post', array($this, 'flush_widget_cache') );
		add_action( 'switch_theme', array($this, 'flush_widget_cache') );
	}

	public function widget($args, $instance) {
		$cache = array();
		if ( ! $this->is_preview() ) {
			$cache = wp_cache_get( 'widget_recent_news', 'widget' );
		}

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		if ( isset( $cache[ $args['widget_id'] ] ) ) {
			echo $cache[ $args['widget_id'] ];
			return;
		}

		ob_start();

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Recent News','noo-carle' );

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number )
			$number = 5;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

		/**
		 * Filter the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */
		$r = new WP_Query( apply_filters( 'widget_news_args', array(
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'meta_key' => '_noo_feature',
			'meta_value' 		=> '1',
		) ) );

		if ($r->have_posts()) :
?>
		<?php echo $args['before_widget']; ?>
		<?php if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} ?>
		<ul>
		<?php while ( $r->have_posts() ) : $r->the_post(); ?>
			<li>
			 <?php if ( has_post_thumbnail() ):
	            the_post_thumbnail(array(70, 70));
	        else: ?>
	            <img width="70" height="70" src="<?php echo NOO_ASSETS_URI.'/images/no-image.jpg' ; ?>" alt="<?php the_title_attribute(); ?>" />
	        <?php endif;  ?>
				<h5><a href="<?php the_permalink(); ?>"><?php get_the_title() ? the_title() : the_ID(); ?></a></h5>
			<?php if ( $show_date ) : ?>
				<span class="post-date"><?php echo get_the_date(); ?></span>
			<?php endif; ?>
			</li>
		<?php endwhile; ?>
		</ul>
		<?php echo $args['after_widget']; ?>
<?php
		// Reset the global $the_post as this query will have stomped on it
		wp_reset_postdata();

		endif;

		if ( ! $this->is_preview() ) {
			$cache[ $args['widget_id'] ] = ob_get_flush();
			wp_cache_set( 'widget_recent_news', $cache, 'widget' );
		} else {
			ob_end_flush();
		}
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = (int) $new_instance['number'];
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$this->flush_widget_cache();

		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['widget_recent_entries']) )
			delete_option('widget_recent_entries');

		return $instance;
	}

	public function flush_widget_cache() {
		wp_cache_delete('widget_recent_news', 'widget');
	}

	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:','noo-carle' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php esc_html_e( 'Number of posts to show:','noo-carle' ); ?></label>
		<input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo esc_attr($number); ?>" size="3" /></p>

		<p><input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" />
		<label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><?php esc_html_e( 'Display post date?','noo-carle' ); ?></label></p>
<?php
	}
}

register_widget('WP_Widget_Recent_News');

class Noo_Tabs_Widget extends  WP_Widget{

    /**
     * Resister widget width WordPress
     */
    function __construct(){
       parent::__construct(
            'noo_tabs',
            esc_html__('Tabs Widget', 'noo-carle'),
           array('description'  =>  esc_html__('Display post buy style tabs', 'noo-carle'))
       );
    }

    /**
     * Front-end display of widget
     */
     public function widget( $args, $instance ){

         $limit = $instance['limit'];
         ?>
                <div class="noo-widgettab widget">
                    <div class="widget-tabs-header">
                        <h6 data-option-value='noo_topview' class="box-title">
                            <span>
                                <?php esc_html_e('TRENDING', 'noo-carle') ?>
                            </span>
                        </h6>
                        <h6 data-option-value='noo_recent' class="box-title noo_widgetab">
                            <span>
                                <?php esc_html_e('RECENT', 'noo-carle') ?>
                            </span>
                        </h6>
                        <h6 data-option-value='noo_comment' class="box-title noo_widgetab">
                            <span>
                                <?php esc_html_e('COMMENT', 'noo-carle') ?>
                            </span>
                        </h6>
                    </div>
                    <div class="widget_tabs_content">
                        <div class="noo_topview noo_widget_content">
                            <ul>
                                <?php
                                    $args = array(
                                        'posts_per_page' => $limit,
                                        'meta_key'       => 'post_count_indate',
                                        'orderby'        => 'meta_value_num',
                                        'order'          => 'DESC',
                                        'tax_query'      => array(
                                            array(
                                                'taxonomy' => 'post_format',
                                                'field'    => 'slug',
                                                'terms' => array(
                                                    'post-format-aside',
                                                    'post-format-chat',
                                                    'post-format-audio',
                                                    'post-format-link',
                                                    'post-format-quote',
                                                    'post-format-status'
                                                ),
                                                'operator' => 'NOT IN'
                                            )
                                        )
                                    );
                                    $top_query = new WP_Query( $args );
                                    if ( $top_query -> have_posts() ):
                                        while( $top_query -> have_posts() ): $top_query -> the_post();
                                ?>
                                <li>
                                    <?php the_post_thumbnail('thumbnail') ?>
                                    <div class="noo_tb">
                                        <?php echo NooPost::get_category_label( 'cat', true ); ?>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    </div>
                                </li>

                                <?php
                                        endwhile;
                                    endif;
                                    wp_reset_postdata();
                                ?>
                            </ul>
                        </div>
                        <div class="noo_recent noo_widget_content">
                            <ul>
                                <?php
                                    $args = array(
                                        'posts_per_page' => $limit,
                                        'orderby'        => 'date',
                                        'order'          => 'DESC',
                                        'tax_query'      => array(
                                            array(
                                                'taxonomy' => 'post_format',
                                                'field'    => 'slug',
                                                'terms' => array(
                                                    'post-format-aside',
                                                    'post-format-chat',
                                                    'post-format-audio',
                                                    'post-format-link',
                                                    'post-format-quote',
                                                    'post-format-status'
                                                ),
                                                'operator' => 'NOT IN'
                                            )
                                        )
                                    );
                                    $top_query = new WP_Query( $args );
                                    if ( $top_query -> have_posts() ):
                                        while( $top_query -> have_posts() ): $top_query -> the_post();
                                ?>
                                <li>
                                    <?php the_post_thumbnail('thumbnail') ?>
                                    <div class="noo_tb">
                                        <?php echo NooPost::get_category_label( 'cat', true ); ?>
                                        <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                    </div>
                                </li>

                                <?php
                                        endwhile;
                                    endif;
                                    wp_reset_postdata();
                                ?>
                            </ul>
                        </div>
                        <div class="noo_comment noo_widget_content">
                            <?php
                            $comments = get_comments( apply_filters( 'widget_comments_args', array(
                                'number'      => $limit,
                                'status'      => 'approve',
                                'post_status' => 'publish'
                            ) ) );

                            $output = '';

                            $output .= '<ul class="recentcomments">';
                            if ( $comments ) {
                                // Prime cache for associated posts. (Prime post term cache if we need it for permalinks.)
                                $post_ids = array_unique( wp_list_pluck( $comments, 'comment_post_ID' ) );
                                _prime_post_caches( $post_ids, strpos( get_option( 'permalink_structure' ), '%category%' ), false );

                                foreach ( (array) $comments as $comment) {
                                    $output .= '<li class="recentcomments">';
                                    /* translators: comments widget: 1: comment author, 2: post link */
                                    $output .= sprintf( _x( '%1$s on %2$s', 'widgets','noo-carle' ),
                                        '<span class="comment-author-link">' . get_comment_author_link($comment->comment_ID) . '</span>',
                                        '<a href="' . esc_url( get_comment_link( $comment->comment_ID ) ) . '">' . get_the_title( $comment->comment_post_ID ) . '</a>'
                                    );
                                    $output .= '</li>';
                                }
                            }
                            $output .= '</ul>';
                            echo $output;
                            ?>
                        </div>
                    </div>
                    <script>

                        jQuery(document).ready(function(){
                            "use strict";
                            jQuery('.noo-widgettab').each(function(){
                                jQuery(this).find('.noo_widget_content:first').show();
                                jQuery(this).find('.widget-tabs-header h6:first').addClass('tab-active');
                            });

                            jQuery('.widget-tabs-header h6').click(function(){
                                jQuery(this).parent().find('h6').removeClass('tab-active');
                                jQuery(this).addClass('tab-active');
                                var $id = jQuery(this).attr('data-option-value');
                                jQuery(this).parent().parent().find('.noo_widget_content').fadeOut(0);
                                jQuery('.'+$id).fadeIn(0);

                            }) ;
                        });
                    </script>
                </div>
     <?php



     }

     /**
      * Back-end widget form
      */
     public function form($instance){
            extract(wp_parse_args($instance,array(
                'limit' =>  5
            )));
     ?>
        <p>
            <label for="<?php echo $this -> get_field_id('limit') ?>"><?php esc_html_e('Limit post', 'noo-carle') ?></label>
            <input type="text" name="<?php echo $this -> get_field_name('limit') ; ?>" id="<?php echo $this -> get_field_id('limit') ?>" class="widefat" value="<?php echo esc_attr($limit); ?>" />
        </p>
     <?php
     }

    /**
     * Update
     */
    public  function update($new_instance, $old_instance){
        $instance = array();
        $instance['limit']  =   ( !empty($new_instance['limit']) ) ? strip_tags($new_instance['limit']) : '';
        return $instance;
    }

}

register_widget('Noo_Tabs_Widget');

class WP_Widget_Post_Slider extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget_post_slider', 'description' => esc_html__( "Your site&#8217;s most recent Posts.",'noo-carle') );
		parent::__construct('post-slider', esc_html__('Post Slider','noo-carle'), $widget_ops);
		$this->alt_option_name = 'widget_post_slider';

		add_action( 'save_post', array($this, 'flush_widget_cache') );
		add_action( 'deleted_post', array($this, 'flush_widget_cache') );
		add_action( 'switch_theme', array($this, 'flush_widget_cache') );
	}

	public function widget($args, $instance) {
		$cache = array();
		if ( ! $this->is_preview() ) {
			$cache = wp_cache_get( 'widget_post_slider', 'widget' );
		}

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		if ( isset( $cache[ $args['widget_id'] ] ) ) {
			echo $cache[ $args['widget_id'] ];
			return;
		}

		ob_start();

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Post Slider','noo-carle' );

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number )
			$number = 5;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

		/**
		 * Filter the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */
		
		$ar =  array(
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true
		);
		$ar['tax_query'][]= array(
			'taxonomy' => 'post_format',
			'field'    => 'slug',
			'terms'    => 'post-format-gallery'
		);
		$r = new WP_Query( $ar );
		wp_enqueue_script('vendor-imagesloaded');
		wp_enqueue_script('noo-carousel');
		$posts_in_column = 1;
		$columns = 1;
		$noo_post_uid  		= uniqid('noo_post_');
		$class = '';
		$class .= ' '.$noo_post_uid;
		$class = ( $class != '' ) ? ' class="' . esc_attr( $class ) . '"' : '';
		if ($r->have_posts()) :
		?>
		<?php echo $args['before_widget']; ?>
		<?php if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} ?>
		<div <?php echo $class?>>

			<div class="row">
				<div class="widget-post-slider-content gallery">
					
					<?php $i=0; ?>
					<?php while ($r->have_posts()): $r->the_post(); global $post;
                    ?>
					
						<?php if($i++ % $posts_in_column == 0 ): ?>
						<div class="noo-post-slider-item col-sm-<?php echo absint((12 / $columns)) ?>">
						<?php endif; ?>
							<div class="noo-post-slider-inner">
								<div class="post-slider-featured" >
									<?php the_post_thumbnail('noo-thumbnail-square')?>
							    </div>
								<div class="post-slider-content">	
									<h5 class="post-slider-title">
										<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permanent link to: "%s"','noo-carle' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php the_title(); ?></a>
									</h5>
								</div>
							</div>
						<?php if($i % $posts_in_column == 0  || $i == $r->post_count): ?>
						</div>
						<?php endif;?>
					
					<?php endwhile;?>
				</div>
			</div>
			<div class="noo-post-navi">
				<div class="noo_slider_prev"><i class="fa fa-caret-left"></i></div>
				<div class="noo_slider_next"><i class="fa fa-caret-right"></i></div>
			</div>
		</div>
			<script type="text/javascript">
				jQuery('document').ready(function ($) {
					var postSliderOptions = {
					    infinite: true,
					    circular: true,
					    responsive: true,
					    debug : false,
						width: '100%',
					    height: 'variable',
					    scroll: {
					      items: <?php echo esc_attr($columns);?>,
					      duration: 600,
					      pauseOnHover: "resume",
					      fx: "scroll"
					    },
					    auto: {
					      timeoutDuration: 3000,
					      play: false
					    },

					    prev : {button:".<?php echo esc_attr($noo_post_uid) ?> .noo_slider_prev"},
    					next : {button:".<?php echo esc_attr($noo_post_uid) ?> .noo_slider_next"},
					    swipe: {
					      onTouch: true,
					      onMouse: true
					    },
					    items: {
					        visible: {
						      min: 1,
						      max: <?php echo esc_attr($columns);?>
						    },
						    height:'variable'
						}
					};
					jQuery('.<?php echo esc_attr($noo_post_uid) ?> .widget-post-slider-content').carouFredSel(postSliderOptions);
					imagesLoaded('<?php echo esc_attr($noo_post_uid) ?> .widget-post-slider-content',function(){
						jQuery('.<?php echo esc_attr($noo_post_uid) ?> .widget-post-slider-content').trigger('updateSizes');
					});
					jQuery(window).resize(function(){
						jQuery('.<?php echo esc_attr($noo_post_uid) ?> .widget-post-slider-content').trigger("destroy").carouFredSel(postSliderOptions);
					});
				});
			</script>
		<?php echo $args['after_widget']; ?>
<?php
		// Reset the global $the_post as this query will have stomped on it
		wp_reset_postdata();

		endif;

		if ( ! $this->is_preview() ) {
			$cache[ $args['widget_id'] ] = ob_get_flush();
			wp_cache_set( 'widget_post_slider', $cache, 'widget' );
		} else {
			ob_end_flush();
		}
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = (int) $new_instance['number'];
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$this->flush_widget_cache();

		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['widget_recent_entries']) )
			delete_option('widget_recent_entries');

		return $instance;
	}

	public function flush_widget_cache() {
		wp_cache_delete('widget_post_slider', 'widget');
	}

	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:','noo-carle' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php esc_html_e( 'Number of posts to show:','noo-carle' ); ?></label>
		<input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo esc_attr($number); ?>" size="3" /></p>

		<p><input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" />
		<label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><?php esc_html_e( 'Display post date?','noo-carle' ); ?></label></p>
<?php
	}
}

register_widget('WP_Widget_Post_Slider');

class WP_Widget_Latest_Ratting extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget_latest_ratting', 'description' => esc_html__( "Your site&#8217;s most recent Posts.",'noo-carle') );
		parent::__construct('latest-rating', esc_html__('Latest Ratting','noo-carle'), $widget_ops);
		$this->alt_option_name = 'widget_latest_ratting';

		add_action( 'save_post', array($this, 'flush_widget_cache') );
		add_action( 'deleted_post', array($this, 'flush_widget_cache') );
		add_action( 'switch_theme', array($this, 'flush_widget_cache') );
	}

	public function widget($args, $instance) {
		$cache = array();
		if ( ! $this->is_preview() ) {
			$cache = wp_cache_get( 'widget_latest_ratting', 'widget' );
		}

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		if ( isset( $cache[ $args['widget_id'] ] ) ) {
			echo $cache[ $args['widget_id'] ];
			return;
		}

		ob_start();

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : esc_html__( 'Latest Rating','noo-carle' );

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number )
			$number = 5;
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

		/**
		 * Filter the arguments for the Recent Posts widget.
		 *
		 * @since 3.4.0
		 *
		 * @see WP_Query::get_posts()
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 */
		$r = new WP_Query( apply_filters( 'widget_latest_rating_args', array(
			'posts_per_page'      => $number,
			'no_found_rows'       => true,
			'post_status'         => 'publish',
			'ignore_sticky_posts' => true,
			'meta_key'           =>  'noo_date_rating',
            'orderby'            =>  'meta_value',
            'order'              =>  'DESC',
		) ) );
		wp_enqueue_script('vendor-imagesloaded');
		wp_enqueue_script('noo-carousel');
		
		$posts_in_column = 1;
		$columns = 1;
		$noo_post_uid  		= uniqid('noo_post_');
		$class = '';
		$class .= ' '.$noo_post_uid;
		$class = ( $class != '' ) ? ' class="' . esc_attr( $class ) . '"' : '';
		if ($r->have_posts()) :
		?>
		<?php echo $args['before_widget']; ?>
		<?php if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} ?>
		<div <?php echo $class?>>

			<div class="row">
				<div class="widget-latest_ratting-content ">
					
					<?php $i=0; ?>
					<?php while ($r->have_posts()): $r->the_post(); global $post;
                    ?>
					
						<?php if($i++ % $posts_in_column == 0 ): ?>
						<div class="noo-latest_ratting-item col-sm-<?php echo absint((12 / $columns)) ?>">
						<?php endif; ?>
							<div class="noo-latest_ratting-inner">
								<div class="latest_ratting-featured" >
									<?php the_post_thumbnail('noo-thumbnail-square')?>
									<?php echo NooPost::get_category_label( 'noo-tncat' ); ?>
									<span class="noo_rating_point"><?php echo esc_html(noo_get_post_meta(get_the_ID(),'noo_total_point_rating',0)) ?></span>
							    </div>
								<div class="post-slider-content">	
									<h4 class="post-slider-title">
										<a href="<?php the_permalink(); ?>" title="<?php echo esc_attr( sprintf( esc_html__( 'Permanent link to: "%s"','noo-carle' ), the_title_attribute( 'echo=0' ) ) ); ?>"><?php the_title(); ?></a>
									</h4>
									<div class="noo-ratting-meta">
				                        <span class="noo-post-date"><i class="fa fa-calendar"></i><?php echo get_the_date(); ?></span>
				                        <span class="noo-post-comment"><i class="fa fa-comments-o"></i><?php comments_number('0',1,'%') ?></span>
				                    </div>
				                    <?php
				                    $excerpt = get_the_excerpt();
				                    $excerpt_ex = explode(' ', $excerpt);
				                    $excerpt_slice = array_slice($excerpt_ex,0,15);
				                    $excerpt_content = implode(' ',$excerpt_slice);
				                    ?>
				                    <p><?php echo esc_html($excerpt_content); ?></p>
								</div>
							</div>
						<?php if($i % $posts_in_column == 0  || $i == $r->post_count): ?>
						</div>
						<?php endif;?>
					
					<?php endwhile;?>
				</div>
			</div>
			<div class="noo-post-navi">
				<div class="noo_slider_prev"><i class="fa fa-caret-left"></i></div>
				<div class="noo_slider_next"><i class="fa fa-caret-right"></i></div>
			</div>
		</div>
			<script type="text/javascript">
				jQuery('document').ready(function ($) {
					var postSliderOptions = {
					    infinite: true,
					    circular: true,
					    responsive: true,
					    debug : false,
						width: '100%',
					    height: 'variable',
					    scroll: {
					      items: <?php echo esc_attr($columns);?>,
					      duration: 600,
					      pauseOnHover: "resume",
					      fx: "scroll"
					    },
					    auto: {
					      timeoutDuration: 3000,
					      play: false
					    },

					    prev : {button:".<?php echo esc_attr($noo_post_uid) ?> .noo_slider_prev"},
    					next : {button:".<?php echo esc_attr($noo_post_uid) ?> .noo_slider_next"},
					    swipe: {
					      onTouch: true,
					      onMouse: true
					    },
					    items: {
					        visible: {
						      min: 1,
						      max: <?php echo esc_attr($columns);?>
						    },
						    height:'variable'
						}
					};
					jQuery('.<?php echo esc_attr($noo_post_uid) ?> .widget-latest_ratting-content').carouFredSel(postSliderOptions);
					imagesLoaded('<?php echo esc_attr($noo_post_uid) ?> .widget-latest_ratting-content',function(){
						jQuery('.<?php echo esc_attr($noo_post_uid) ?> .widget-latest_ratting-content').trigger('updateSizes');
					});
					jQuery(window).resize(function(){
						jQuery('.<?php echo esc_attr($noo_post_uid) ?> .widget-latest_ratting-content').trigger("destroy").carouFredSel(postSliderOptions);
					});
				});
			</script>
		<?php echo $args['after_widget']; ?>
<?php
		// Reset the global $the_post as this query will have stomped on it
		wp_reset_postdata();

		endif;

		if ( ! $this->is_preview() ) {
			$cache[ $args['widget_id'] ] = ob_get_flush();
			wp_cache_set( 'widget_latest_ratting', $cache, 'widget' );
		} else {
			ob_end_flush();
		}
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['number'] = (int) $new_instance['number'];
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;
		$this->flush_widget_cache();

		$alloptions = wp_cache_get( 'alloptions', 'options' );
		if ( isset($alloptions['widget_recent_entries']) )
			delete_option('widget_recent_entries');

		return $instance;
	}

	public function flush_widget_cache() {
		wp_cache_delete('widget_latest_ratting', 'widget');
	}

	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:','noo-carle' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php esc_html_e( 'Number of posts to show:','noo-carle' ); ?></label>
		<input id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" type="text" value="<?php echo esc_attr($number); ?>" size="3" /></p>

		<p><input class="checkbox" type="checkbox" <?php checked( $show_date ); ?> id="<?php echo $this->get_field_id( 'show_date' ); ?>" name="<?php echo $this->get_field_name( 'show_date' ); ?>" />
		<label for="<?php echo $this->get_field_id( 'show_date' ); ?>"><?php esc_html_e( 'Display post date?','noo-carle' ); ?></label></p>
<?php
	}
}

register_widget('WP_Widget_Latest_Ratting');


if( !class_exists('Noo_Infomation') ):
    class Noo_Infomation extends  WP_Widget{

        public function __construct(){
            parent::__construct(
                'noo_infomation',
                'Noo Infomation',
                array('description', esc_html__('Noo Infomation', 'noo-carle'))
            );
            add_action('admin_enqueue_scripts', array($this, 'register_js'));
        }
        public function register_js(){

            wp_enqueue_media();
            wp_register_script('upload_img', NOO_ADMIN_ASSETS_URI . '/js/upload_img.js', false, false, $in_footer=true);
            wp_enqueue_script('upload_img');

        }
        public function widget($args, $instance){
            extract( $args );
            extract( $instance );
            echo $before_widget;
            $arg_social = array(
                array('id'       =>  'facebook'),
                array('id'       =>  'google'),
                array('id'       =>  'twitter'),
                array('id'       =>  'youtube'),
                array('id'       =>  'skype'),
                array('id'       =>  'linkedin'),
                array('id'       =>  'dribbble'),
                array('id'       =>  'pinterest'),
                array('id'       =>  'flickr')

            ) ;
            ?>
            <div class="social-all">
                <span><?php echo esc_html__('Follow us','noo-carle'); ?></span>
                <?php
                foreach($arg_social as $social):
                    if (!empty($instance[$social['id']])):
                        ?>
                        <a href="<?php echo esc_url($instance[$social['id']]); ?>" class="fa fa-<?php echo esc_attr($social['id']); ?>"></a>
                    <?php
                    endif;
                endforeach;
                ?>
            </div>
            <div class="noo-info-top">
                <?php if( isset($image) && !empty($image) ): ?>
                <a href="<?php echo esc_url($link); ?>">
                    <img src="<?php echo esc_url($image); ?>" alt="<?php bloginfo('title'); ?>">
                </a>
                <?php endif; ?>
                <p>
                    <?php if( isset($description) && !empty($description) )  echo esc_html($description); ?>
                </p>
            </div>
            <ul class="noo-infomation-attr">
                <li>
                    <span class="fa fa-map-marker infomation-left"></span>
                    <address>
                        <?php if( isset($address) && !empty($address) ) echo esc_html($address); ?>
                    </address>
                </li>
                <li>
                    <span class="fa fa-phone infomation-left"></span>
                    <span><?php if( isset($phone) && !empty($phone) ) echo esc_html($phone); ?></span>
                </li>
                <li>
                    <span class="fa fa-envelope infomation-left"></span>
                    <span class="phone-text"><a href="mailto:<?php echo esc_html($mail); ?>"><?php if( isset($mail) && !empty($mail) )  echo esc_html($mail); ?></a></span>
                </li>
                <li>
                    <span class="fa fa-globe infomation-left"></span>
                    <span><a href="<?php echo esc_url($website) ?>"><?php if( isset($website) && !empty($website) )  echo esc_html($website); ?></a></span>
                </li>
            </ul>
            <div class="noo-info-footer">
                <?php if( isset($copyright) && !empty($copyright) ) echo noo_html_content_filter($copyright); ?>
            </div>
            <?php
            echo $after_widget;
        }

        public function form( $instance ){
            $instance = wp_parse_args( $instance, array(
                'description'     =>  'Noo Infomation',
                'link'            =>  '',
                'image'           =>  '',
                'address'         =>  '',
                'phone'           =>  '',
                'mail'            =>  '',
                'website'         =>  '',
                'copyright'       =>  '',
                'facebook'        =>  '',
                'google'          =>  '',
                'twitter'         =>  '',
                'youtube'         =>  '',
                'skype'           =>  '',
                'linkedin'        =>  '',
                'dribbble'        =>  '',
                'pinterest'       =>  '',
                'flickr'          =>  ''
            ) );
            extract($instance);
            ?>
            <p>
                <label for="<?php echo $this -> get_field_id('description'); ?>"><?php echo esc_html_e('Description', 'noo-carle') ; ?></label>
                <textarea name="<?php echo $this -> get_field_name('description'); ?>" id="<?php echo $this -> get_field_id('description') ; ?>" cols="10" rows="5" class="widefat"><?php echo esc_attr($description); ?></textarea>
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('link'); ?>"><?php echo esc_html_e('Link Image:', 'noo-carle'); ?></label>
                <input type="text" id="<?php echo $this -> get_field_id('link'); ?>" name="<?php echo $this -> get_field_name('link') ?>" class="widefat" value="<?php echo esc_attr($link); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('image'); ?>"><?php echo esc_html_e('Image', 'noo-carle') ; ?></label>
                <input class="widefat" type="text" name="<?php echo $this -> get_field_name('image'); ?>" id="<?php echo $this -> get_field_id('image') ; ?>" value="<?php echo esc_attr($image); ?>">
                <a href="#" class="noo_upload_button button" rel="image"><?php echo esc_html_e('Upload', 'noo-carle') ?></a>
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('address'); ?>"><?php echo esc_html_e('Address', 'noo-carle') ; ?></label>
                <textarea name="<?php echo $this -> get_field_name('address'); ?>" id="<?php echo $this -> get_field_id('address') ; ?>" cols="10" rows="5" class="widefat"><?php echo esc_attr($address); ?></textarea>
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('phone'); ?>"><?php echo esc_html_e('Phone:', 'noo-carle'); ?></label>
                <input type="text" id="<?php echo $this -> get_field_id('phone'); ?>" name="<?php echo $this -> get_field_name('phone') ?>" class="widefat" value="<?php echo esc_attr($phone); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('mail'); ?>"><?php echo esc_html_e('Mail', 'noo-carle') ; ?></label>
                <input class="widefat" type="text" name="<?php echo $this -> get_field_name('mail'); ?>" id="<?php echo $this -> get_field_id('mail') ; ?>" value="<?php echo esc_attr($mail); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('website'); ?>"><?php echo esc_html_e('Website', 'noo-carle') ; ?></label>
                <input class="widefat" type="text" name="<?php echo $this -> get_field_name('website'); ?>" id="<?php echo $this -> get_field_id('website') ; ?>" value="<?php echo esc_attr($website); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('copyright'); ?>"><?php echo esc_html_e('Copyright', 'noo-carle') ; ?></label>
                <textarea name="<?php echo $this -> get_field_name('copyright'); ?>" id="<?php echo $this -> get_field_id('copyright') ; ?>" cols="10" rows="5" class="widefat"><?php echo esc_attr($copyright); ?></textarea>
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('facebook') ?>" >
                    <?php esc_html_e('Facebook','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('facebook') ; ?>" id="<?php echo $this -> get_field_id('facebook'); ?>" class="widefat" value="<?php echo esc_attr($facebook); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('google') ?>">
                    <?php esc_html_e('Google','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('google') ; ?>" id="<?php echo $this -> get_field_id('google'); ?>" class="widefat" value="<?php echo esc_attr($google); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('twitter') ?>">
                    <?php esc_html_e('Twitter','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('twitter') ; ?>" id="<?php echo $this -> get_field_id('twitter'); ?>" class="widefat" value="<?php echo esc_attr($twitter); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('youtube') ?>">
                    <?php esc_html_e('Youtube','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('youtube') ; ?>" id="<?php echo $this -> get_field_id('youtube'); ?>" class="widefat" value="<?php echo esc_attr($youtube); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('skype'); ?>">
                    <?php  esc_html_e('Skype','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('skype') ; ?>" id="<?php echo $this -> get_field_id('skype'); ?>" class="widefat" value="<?php echo esc_attr($skype); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('linkedin') ?>">
                    <?php esc_html_e('linkedin','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('linkedin') ; ?>" id="<?php echo $this -> get_field_id('linkedin'); ?>" class="widefat" value="<?php echo esc_attr($linkedin); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('dribbble') ?>">
                    <?php esc_html_e('Dribbble','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('dribbble') ; ?>" id="<?php echo $this -> get_field_id('dribbble'); ?>" class="widefat" value="<?php echo esc_attr($dribbble); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('pinterest') ?>">
                    <?php esc_html_e('Pinterest','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('pinterest') ; ?>" id="<?php echo $this -> get_field_id('pinterest'); ?>" class="widefat" value="<?php echo esc_attr($pinterest); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('flickr') ?>">
                    <?php esc_html_e('Flickr','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('flickr') ; ?>" id="<?php echo $this -> get_field_id('flickr'); ?>" class="widefat" value="<?php echo esc_attr($flickr); ?>">
            </p>

        <?php
        }
        // method update
        public function update( $new_instance, $old_instance ){
            $instance                 =   $old_instance;
            $instance['description']  =   $new_instance['description'];
            $instance['link']         =   $new_instance['link'];
            $instance['image']        =   $new_instance['image'];
            $instance['address']      =   $new_instance['address'];
            $instance['phone']        =   $new_instance['phone'];
            $instance['mail']         =   $new_instance['mail'];
            $instance['website']      =   $new_instance['website'];
            $instance['copyright']    =   $new_instance['copyright'];
            $instance['facebook']     =   ( ! empty( $new_instance['facebook'] ) ) ? strip_tags( $new_instance['facebook'] ) : ''  ;
            $instance['google']  =   ( ! empty( $new_instance['google'] ) ) ? strip_tags( $new_instance['google'] ) : ''  ;
            $instance['twitter']      =   ( ! empty( $new_instance['twitter'] ) ) ? strip_tags( $new_instance['twitter'] ) : ''  ;
            $instance['youtube']      =   ( ! empty( $new_instance['youtube'] ) ) ? strip_tags( $new_instance['youtube'] ) : ''  ;
            $instance['skype']        =   ( ! empty( $new_instance['skype'] ) ) ? strip_tags( $new_instance['skype'] ) : ''  ;
            $instance['linkedin']     =   ( ! empty( $new_instance['linkedin'] ) ) ? strip_tags( $new_instance['linkedin'] ) : ''  ;
            $instance['dribbble']     =   ( ! empty( $new_instance['dribbble'] ) ) ? strip_tags( $new_instance['dribbble'] ) : ''  ;
            $instance['pinterest']    =   ( ! empty( $new_instance['pinterest'] ) ) ? strip_tags( $new_instance['pinterest'] ) : ''  ;
            $instance['flickr']       =   ( ! empty( $new_instance['flickr'] ) ) ? strip_tags( $new_instance['flickr'] ) : ''  ;
            return $instance;
        }
    }
    register_widget('Noo_Infomation');
endif;


if( !class_exists('Noo_Widget_Services') ){
    class Noo_Widget_Services extends WP_Widget{
        public function __construct(){
            parent::__construct(
                'noo_services',
                'Noo Category Services',
                array('noo_services',esc_html__('Best Category Services','noo-carle'))
            );
        }
        public function widget($args, $instance){
            extract($args);
            $title = apply_filters('widget_title', $instance['title']);
            echo $before_widget ;
            if ( $title ) :
                echo $before_title.$title.$after_title ;
            endif;
            $args = array(
                'type'                     => 'noo_services',
                'child_of'                 => 0,
                'parent'                   => '',
                'orderby'                  => 'name',
                'order'                    => 'ASC',
                'hide_empty'               => 0,
                'hierarchical'             => 0,
                'exclude'                  => '',
                'include'                  => '',
                'number'                   => '',
                'taxonomy'                 => 'services_category',
                'pad_counts'               => false

            );
            $categories = get_categories( $args );
            if( isset( $categories ) && !empty( $categories ) ){
                echo '<ul>';
                foreach( $categories as $term ){
                    $term_link = get_term_link( $term );
                    if ( is_wp_error( $term_link ) ) {
                        continue;
                    }
                    echo '<li><a href="'.$term_link.'">'.$term->name.'</a></li>';


                }
                echo '</ul>';
            }
            echo $after_widget ;
            ?>

            <?php
        }
        public function form( $instance ){
            $instance = wp_parse_args( $instance, array(
                'title'     =>  '',
            ) );
            extract($instance);
            ?>
             <p>
                 <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:','noo-carle' ); ?></label>
                <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr($title); ?>" />
             </p>
            <?php
        }
        public function update( $new_instance, $old_instance ){
            $instance                 =   $old_instance;
            $instance['title']        =   $new_instance['title'];
            return $instance;
        }
    }
    register_widget('Noo_Widget_Services');
}

if( !class_exists('Noo_Custom_Menu') ):

    class Noo_Custom_Menu extends WP_Widget{

        public function __construct(){
            parent::__construct(
                'noo_menu',
                'Noo Custom Menu',
                array('description' => 'Noo Custom Menu')
            );
        }
        public function widget($args, $instance) {
            // Get menu
            $nav_menu = ! empty( $instance['nav_menu'] ) ? wp_get_nav_menu_object( $instance['nav_menu'] ) : false;

            if ( !$nav_menu )
                return;

            /** This filter is documented in wp-includes/default-widgets.php */
            $instance['title'] = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

            echo $args['before_widget'];

            if ( !empty($instance['title']) )
                echo $args['before_title'] . $instance['title'] . $args['after_title'];




            if ( isset($nav_menu) && $nav_menu != false ) {

                $menu = wp_get_nav_menu_object( $nav_menu );

                $menu_items = wp_get_nav_menu_items($menu->term_id);

                ?>
                    <div class="noo-custom-menu">
                <?php
                $i = 0;
                foreach ( (array) $menu_items as $key => $menu_item ) {
                    if( $i++ % 4 == 0 ): ?>
                        <ul>
                    <?php endif;
                    $title = $menu_item->title;
                    $url = $menu_item->url;
                    echo '<li><a href="'.esc_url($url).'">'.esc_html($title).'</a></li>';
                    if( $i % 4 == 0 || $i == count($menu_items)  ): ?>
                        </ul>
                    <?php endif;
                }
                ?>
                    </div>
                <?php
            }


            echo $args['after_widget'];
        }

        public function update( $new_instance, $old_instance ) {
            $instance = array();
            if ( ! empty( $new_instance['title'] ) ) {
                $instance['title'] = strip_tags( stripslashes($new_instance['title']) );
            }
            if ( ! empty( $new_instance['nav_menu'] ) ) {
                $instance['nav_menu'] = (int) $new_instance['nav_menu'];
            }
            return $instance;
        }

        public function form( $instance ) {
            $title = isset( $instance['title'] ) ? $instance['title'] : '';
            $nav_menu = isset( $instance['nav_menu'] ) ? $instance['nav_menu'] : '';

            // Get menus
            $menus = wp_get_nav_menus();

            // If no menus exists, direct the user to go and create some.
            if ( !$menus ) {
                echo '<p>'. sprintf( esc_html__('No menus have been created yet. <a href="%s">Create some</a>.','noo-carle'), esc_url(admin_url('nav-menus.php')) ) .'</p>';
                return;
            }
            ?>
            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Title:','noo-carle') ?></label>
                <input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('nav_menu'); ?>"><?php esc_html_e('Select Menu:','noo-carle'); ?></label>
                <select id="<?php echo $this->get_field_id('nav_menu'); ?>" name="<?php echo $this->get_field_name('nav_menu'); ?>">
                    <option value="0"><?php _e( '&mdash; Select &mdash;','noo-carle' ) ?></option>
                    <?php
                    foreach ( $menus as $menu ) {
                        echo '<option value="' . esc_attr($menu->term_id) . '"'
                            . selected( $nav_menu, $menu->term_id, false )
                            . '>'. esc_html( $menu->name ) . '</option>';
                    }
                    ?>
                </select>
            </p>
        <?php
        }

    }
    register_widget('Noo_Custom_Menu');

endif;


class Noo_Tweets extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'dh_tweets',  // Base ID
            'Recent Tweets',  // Name
            array( 'classname' => 'tweets-widget', 'description' => esc_html__( 'Display recent tweets', 'noo-carle' ) ) );
    }

    public function widget( $args, $instance ) {
        extract( $args );
        if ( ! empty( $instance['title'] ) ) {
            $title = apply_filters( 'widget_title', $instance['title'] );
        }
        echo $before_widget;
        if ( ! empty( $title ) ) {
            echo $before_title . $title . $after_title;
        }

        // check settings and die if not set
        if ( empty( $instance['consumerkey'] ) || empty( $instance['consumersecret'] ) || empty(
            $instance['accesstoken'] ) || empty( $instance['accesstokensecret'] ) || empty( $instance['cachetime'] ) ||
            empty( $instance['username'] ) ) {
            echo '<strong>' . esc_html__( 'Please fill all widget settings!', 'noo-carle' ) . '</strong>' . $after_widget;
            return;
        }

        $dh_widget_recent_tweets_cache_time = get_option( 'dh_widget_recent_tweets_cache_time' );
        $diff = time() - $dh_widget_recent_tweets_cache_time;

        $crt = (int) $instance['cachetime'] * 3600;

        if($diff >= $crt || empty($dh_widget_recent_tweets_cache_time)){

            if( ! class_exists('TwitterOAuth' ) ) {
                echo '<strong>' . esc_html__( 'Couldn\'t find twitteroauth.php!', 'noo-carle' ) . '</strong>' . $after_widget;
                return;
            }

            function getConnectionWithAccessToken( $cons_key, $cons_secret, $oauth_token, $oauth_token_secret ) {
                $connection = new TwitterOAuth( $cons_key, $cons_secret, $oauth_token, $oauth_token_secret );
                return $connection;
            }

            $connection = getConnectionWithAccessToken(
                $instance['consumerkey'],
                $instance['consumersecret'],
                $instance['accesstoken'],
                $instance['accesstokensecret'] );
            $tweets = $connection->get(
                "https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=" . $instance['username'] .
                "&count=10&exclude_replies=" . $instance['excludereplies'] );

            if ( ! empty( $tweets->errors ) ) {
                if ( $tweets->errors[0]->message == 'Invalid or expired token' ) {
                    echo '<strong>' . $tweets->errors[0]->message . '!</strong><br/>' . esc_html__(
                            'You\'ll need to regenerate it <a href="https://dev.twitter.com/apps" target="_blank">here</a>!',
                            'noo-carle' ) . $after_widget;
                } else {
                    echo '<strong>' . $tweets->errors[0]->message . '</strong>' . $after_widget;
                }
                return;
            }

            $tweets_array = array();
            for ( $i = 0; $i <= count( $tweets ); $i++ ) {
                if ( ! empty( $tweets[$i] ) ) {
                    $tweets_array[$i]['created_at'] = $tweets[$i]->created_at;
                    $tweets_array[$i]['name']	=	$tweets[$i]->user->name;
                    $tweets_array[$i]['screen_name'] = $tweets[$i]->user->screen_name;
                    $tweets_array[$i]['profile_image_url'] = $tweets[$i]->user->profile_image_url;
                    // clean tweet text
                    $tweets_array[$i]['text'] = preg_replace( '/[\x{10000}-\x{10FFFF}]/u', '', $tweets[$i]->text );

                    if ( ! empty( $tweets[$i]->id_str ) ) {
                        $tweets_array[$i]['status_id'] = $tweets[$i]->id_str;
                    }
                }
            }
            update_option( 'dh_widget_recent_tweets', serialize( $tweets_array ) );
            update_option( 'dh_widget_recent_tweets_cache_time', time() );
        }

        $dh_widget_recent_tweets = maybe_unserialize( get_option( 'dh_widget_recent_tweets' ) );
        if ( ! empty( $dh_widget_recent_tweets ) ) {
            echo '<div class="recent-tweets"><ul>';
            $i = '1';
            foreach ( $dh_widget_recent_tweets as $tweet ) {

                if ( ! empty( $tweet['text'] ) ) {
                    if ( empty( $tweet['status_id'] ) ) {
                        $tweet['status_id'] = '';
                    }
                    if ( empty( $tweet['created_at'] ) ) {
                        $tweet['created_at'] = '';
                    }

                    echo '<li><div class="twitter_user"><a class="twitter_profile" target="_blank" href="http://twitter.com/' .
                        $instance['username'] . '/statuses/' . $tweet['status_id'] . '"><img src="'.$tweet['profile_image_url'].'" alt="'. $tweet['name'] .'"></a><span class="twitter_username">@'.$tweet['screen_name'].'</span></div><span class="tw-content">' . $this->_convert_links( $tweet['text'] ) .
                        '</span></li>';
                    if ( $i == $instance['tweetstoshow'] ) {
                        break;
                    }
                    $i++;
                }
            }

            echo '</ul></div>';
        }

        echo $after_widget;
    }

    protected function _convert_links( $status, $targetBlank = true, $linkMaxLen = 50 ) {
        // the target
        $target = $targetBlank ? " target=\"_blank\" " : "";

        // convert link to url
        $status = preg_replace(
            "/((http:\/\/|https:\/\/)[^ )]+)/i",
            "<a href=\"$1\" title=\"$1\" $target >$1</a>",
            $status );

        // convert @ to follow
        $status = preg_replace(
            "/(@([_a-z0-9\-]+))/i",
            "<a href=\"http://twitter.com/$2\" title=\"Follow $2\" $target >$1</a>",
            $status );

        // convert # to search
        $status = preg_replace(
            "/(#([_a-z0-9\-]+))/i",
            "<a href=\"https://twitter.com/search?q=$2\" title=\"Search $1\" $target >$1</a>",
            $status );

        // return the status
        return $status;
    }

    protected function _relative_time( $a = '' ) {
        // get current timestampt
        $b = strtotime( "now" );
        // get timestamp when tweet created
        $c = strtotime( $a );
        // get difference
        $d = $b - $c;
        // calculate different time values
        $minute = 60;
        $hour = $minute * 60;
        $day = $hour * 24;
        $week = $day * 7;

        if ( is_numeric( $d ) && $d > 0 ) {
            // if less then 3 seconds
            if ( $d < 3 )
                return "right now";
            // if less then minute
            if ( $d < $minute )
                return sprintf( esc_html__( "%s seconds ago", 'noo-carle' ), floor( $d ) );
            // if less then 2 minutes
            if ( $d < $minute * 2 )
                return esc_html__( "about 1 minute ago", 'noo-carle' );
            // if less then hour
            if ( $d < $hour )
                return sprintf( esc_html__( '%s minutes ago', 'noo-carle' ), floor( $d / $minute ) );
            // if less then 2 hours
            if ( $d < $hour * 2 )
                return esc_html__( "about 1 hour ago", 'noo-carle' );
            // if less then day
            if ( $d < $day )
                return sprintf( esc_html__( "%s hours ago", 'noo-carle' ), floor( $d / $hour ) );
            // if more then day, but less then 2 days
            if ( $d > $day && $d < $day * 2 )
                return esc_html__( "yesterday", 'noo-carle' );
            // if less then year
            if ( $d < $day * 365 )
                return sprintf( esc_html__( '%s days ago', 'noo-carle' ), floor( $d / $day ) );
            // else return more than a year
            return esc_html__( "over a year ago", 'noo-carle' );
        }
    }

    public function form( $instance ) {
        $defaults = array(
            'title' => '',
            'consumerkey' => '',
            'consumersecret' => '',
            'accesstoken' => '',
            'accesstokensecret' => '',
            'cachetime' => '',
            'username' => '',
            'tweetstoshow' => '' );
        $instance = wp_parse_args( (array) $instance, $defaults );

        echo '
		<p>
			<label>' . esc_html__( 'Title', 'noo-carle' ) . ':</label>
			<input type="text" name="' .
            $this->get_field_name( 'title' ) . '" id="' . $this->get_field_id( 'title' ) . '" value="' .
            esc_attr( $instance['title'] ) . '" class="widefat" />
		</p>
		<p>
			<label>' . esc_html__( 'Consumer Key', 'noo-carle' ) . ':</label>
			<input type="text" name="' .
            $this->get_field_name( 'consumerkey' ) . '" id="' . $this->get_field_id( 'consumerkey' ) . '" value="' .
            esc_attr( $instance['consumerkey'] ) . '" class="widefat" />
		</p>
		<p>
			<label>' . esc_html__( 'Consumer Secret', 'noo-carle' ) . ':</label>
			<input type="text" name="' .
            $this->get_field_name( 'consumersecret' ) . '" id="' . $this->get_field_id( 'consumersecret' ) . '" value="' .
            esc_attr( $instance['consumersecret'] ) . '" class="widefat" />
		</p>
		<p>
			<label>' . esc_html__( 'Access Token', 'noo-carle' ) . ':</label>
			<input type="text" name="' .
            $this->get_field_name( 'accesstoken' ) . '" id="' . $this->get_field_id( 'accesstoken' ) . '" value="' .
            esc_attr( $instance['accesstoken'] ) . '" class="widefat" />
		</p>
		<p>
			<label>' . esc_html__( 'Access Token Secret', 'noo-carle' ) . ':</label>
			<input type="text" name="' .
            $this->get_field_name( 'accesstokensecret' ) . '" id="' . $this->get_field_id( 'accesstokensecret' ) .
            '" value="' . esc_attr( $instance['accesstokensecret'] ) . '" class="widefat" />
		</p>
		<p>
			<label>' .
            esc_html__( 'Cache Tweets in every', 'noo-carle' ) . ':</label>
			<input type="text" name="' .
            $this->get_field_name( 'cachetime' ) . '" id="' . $this->get_field_id( 'cachetime' ) . '" value="' .
            esc_attr( $instance['cachetime'] ) . '" class="small-text" />' . esc_html__( 'hours', 'noo-carle' ) . '
		</p>
		<p>
			<label>' . esc_html__( 'Twitter Username', 'noo-carle' ) . ':</label>
			<input type="text" name="' .
            $this->get_field_name( 'username' ) . '" id="' . $this->get_field_id( 'username' ) . '" value="' .
            esc_attr( $instance['username'] ) . '" class="widefat" />
		</p>
		<p>
			<label>' . esc_html__( 'Tweets to display', 'noo-carle' ) . ':</label>
			<select type="text" name="' .
            $this->get_field_name( 'tweetstoshow' ) . '" id="' . $this->get_field_id( 'tweetstoshow' ) . '">';
        $i = 1;
        for ( $i; $i <= 10; $i++ ) {
            echo '<option value="' . esc_attr($i) . '"';
            if ( $instance['tweetstoshow'] == $i ) {
                echo ' selected="selected"';
            }
            echo '>' . esc_attr($i) . '</option>';
        }
        echo '
			</select>
		</p>
		<p>
			<label>' . esc_html__( 'Exclude replies', 'noo-carle' ) . ':</label>
			<input type="checkbox" name="' .
            $this->get_field_name( 'excludereplies' ) . '" id="' . $this->get_field_id( 'excludereplies' ) .
            '" value="true"';
        if ( ! empty( $instance['excludereplies'] ) && esc_attr( $instance['excludereplies'] ) == 'true' ) {
            echo ' checked="checked"';
        }
        echo '/></p>';
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['consumerkey'] = strip_tags( $new_instance['consumerkey'] );
        $instance['consumersecret'] = strip_tags( $new_instance['consumersecret'] );
        $instance['accesstoken'] = strip_tags( $new_instance['accesstoken'] );
        $instance['accesstokensecret'] = strip_tags( $new_instance['accesstokensecret'] );
        $instance['cachetime'] = strip_tags( $new_instance['cachetime'] );
        $instance['username'] = strip_tags( $new_instance['username'] );
        $instance['tweetstoshow'] = strip_tags( $new_instance['tweetstoshow'] );
        $instance['excludereplies'] = strip_tags( $new_instance['excludereplies'] );

        if ( $old_instance['username'] != $new_instance['username'] ) {
            delete_option( 'dh_widget_recent_tweets_cache_time' );
        }

        return $instance;
    }
}

register_widget( 'Noo_Tweets' );


if( !class_exists('Noo_Infomation_Onepage') ):
    class Noo_Infomation_Onepage extends  WP_Widget{

        public function __construct(){
            parent::__construct(
                'noo_infomation_onpage',
                'Noo OnePage',
                array('description', esc_html__('This is widget using for template onepage', 'noo-carle'))
            );
        }
        public function widget($args, $instance){
            extract( $args );
            extract( $instance );
            echo $before_widget;
            $arg_social = array(
                array('id'       =>  'facebook'),
                array('id'       =>  'google'),
                array('id'       =>  'twitter'),
                array('id'       =>  'youtube'),
                array('id'       =>  'skype'),
                array('id'       =>  'linkedin'),
                array('id'       =>  'dribbble'),
                array('id'       =>  'pinterest'),
                array('id'       =>  'flickr')

            ) ;
            ?>
            <div class="onepage-social">
                <?php
                foreach($arg_social as $social):
                    if (!empty($instance[$social['id']])):
                        ?>
                        <a href="<?php echo esc_url($instance[$social['id']]); ?>" class="fa fa-<?php echo esc_attr($social['id']); ?>"></a>
                    <?php
                    endif;
                endforeach;
                ?>
            </div>
            <div class="noo-one-footer">
                <?php echo noo_html_content_filter($copyright); ?>
            </div>
            <?php
            echo $after_widget;
        }

        public function form( $instance ){
            $instance = wp_parse_args( $instance, array(
                'copyright'       =>  '',
                'facebook'        =>  '',
                'google'     =>  '',
                'twitter'         =>  '',
                'youtube'         =>  '',
                'skype'           =>  '',
                'linkedin'        =>  '',
                'dribbble'        =>  '',
                'pinterest'       =>  '',
                'flickr'          =>  ''
            ) );
            extract($instance);
            ?>
            <p>
                <label for="<?php echo $this -> get_field_id('copyright'); ?>"><?php esc_html_e('Copyright', 'noo-carle') ; ?></label>
                <textarea name="<?php echo $this -> get_field_name('copyright'); ?>" id="<?php echo $this -> get_field_id('copyright') ; ?>" cols="10" rows="5" class="widefat"><?php echo esc_attr($copyright); ?></textarea>
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('facebook') ?>" >
                    <?php esc_html_e('Facebook','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('facebook') ; ?>" id="<?php echo $this -> get_field_id('facebook'); ?>" class="widefat" value="<?php echo esc_attr($facebook); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('google-plus') ?>">
                    <?php esc_html_e('Google','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('google-plus') ; ?>" id="<?php echo $this -> get_field_id('google-plus'); ?>" class="widefat" value="<?php echo esc_attr($google); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('twitter') ?>">
                    <?php esc_html_e('Twitter','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('twitter') ; ?>" id="<?php echo $this -> get_field_id('twitter'); ?>" class="widefat" value="<?php echo esc_attr($twitter); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('youtube') ?>">
                    <?php esc_html_e('Youtube','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('youtube') ; ?>" id="<?php echo $this -> get_field_id('youtube'); ?>" class="widefat" value="<?php echo esc_attr($youtube); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('skype'); ?>">
                    <?php  esc_html_e('Skype','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('skype') ; ?>" id="<?php echo $this -> get_field_id('skype'); ?>" class="widefat" value="<?php echo esc_attr($skype); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('linkedin') ?>">
                    <?php esc_html_e('linkedin','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('linkedin') ; ?>" id="<?php echo $this -> get_field_id('linkedin'); ?>" class="widefat" value="<?php echo esc_attr($linkedin); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('dribbble') ?>">
                    <?php esc_html_e('Dribbble','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('dribbble') ; ?>" id="<?php echo $this -> get_field_id('dribbble'); ?>" class="widefat" value="<?php echo esc_attr($dribbble); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('pinterest') ?>">
                    <?php esc_html_e('Pinterest','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('pinterest') ; ?>" id="<?php echo $this -> get_field_id('pinterest'); ?>" class="widefat" value="<?php echo esc_attr($pinterest); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('flickr') ?>">
                    <?php esc_html_e('Flickr','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('flickr') ; ?>" id="<?php echo $this -> get_field_id('flickr'); ?>" class="widefat" value="<?php echo esc_attr($flickr); ?>">
            </p>

        <?php
        }
        // method update
        public function update( $new_instance, $old_instance ){
            $instance                 =   $old_instance;
            $instance['copyright']    =   $new_instance['copyright'];
            $instance['facebook']     =   ( ! empty( $new_instance['facebook'] ) ) ? strip_tags( $new_instance['facebook'] ) : ''  ;
            $instance['google']       =   ( ! empty( $new_instance['google-plus'] ) ) ? strip_tags( $new_instance['google'] ) : ''  ;
            $instance['twitter']      =   ( ! empty( $new_instance['twitter'] ) ) ? strip_tags( $new_instance['twitter'] ) : ''  ;
            $instance['youtube']      =   ( ! empty( $new_instance['youtube'] ) ) ? strip_tags( $new_instance['youtube'] ) : ''  ;
            $instance['skype']        =   ( ! empty( $new_instance['skype'] ) ) ? strip_tags( $new_instance['skype'] ) : ''  ;
            $instance['linkedin']     =   ( ! empty( $new_instance['linkedin'] ) ) ? strip_tags( $new_instance['linkedin'] ) : ''  ;
            $instance['dribbble']     =   ( ! empty( $new_instance['dribbble'] ) ) ? strip_tags( $new_instance['dribbble'] ) : ''  ;
            $instance['pinterest']    =   ( ! empty( $new_instance['pinterest'] ) ) ? strip_tags( $new_instance['pinterest'] ) : ''  ;
            $instance['flickr']       =   ( ! empty( $new_instance['flickr'] ) ) ? strip_tags( $new_instance['flickr'] ) : ''  ;
            return $instance;
        }
    }
    register_widget('Noo_Infomation_Onepage');
endif;

if( !class_exists('Noo_Best_Services') ):
    class Noo_Best_Services extends  WP_Widget{

        public function __construct(){
            parent::__construct(
                'noo_best_services',
                'Noo Best Services',
                array('description', esc_html__('Best Services', 'noo-carle'))
            );
            add_action('wp_enqueue_scripts', array($this, 'register_js'));
        }


        public function register_js(){
            wp_enqueue_script('noo-carousel');
        }
        public function widget($args, $instance){
            extract( $args );
            if ( ! empty( $instance['title'] ) ) {
                $title = apply_filters( 'widget_title', $instance['title'] );
            }
            echo $before_widget;
            if ( ! empty( $title ) ) {
                echo $before_title . $title . $after_title;
            }
                $args = array(
                    'post_type' =>  'noo_services'
                );
                $query = new WP_Query( $args );
                if( $query->have_posts() ):
                    ?>
                        <button class="best_services-prev">
                            <i class="fa fa-long-arrow-left"></i>
                        </button>
                        <button class="best_services-next">
                            <i class="fa fa-long-arrow-right"></i>
                        </button>
                    <?php
                    echo '<ul class="best_services">';
                        while( $query->have_posts() ):
                            $query->the_post();
                            ?>
                                <li>
                                    <a href="<?php the_permalink(); ?>">
                                        <?php the_post_thumbnail('noo-thumbnail-square'); ?>
                                    </a>
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                </li>
                            <?php
                        endwhile;
                    echo '</ul>';
                endif;
                wp_reset_postdata();
            ?>
            <script>
                jQuery(document).ready(function(){
                    jQuery('.best_services').each(function(){
                        jQuery(this).owlCarousel({
                            items : 1,
                            itemsDesktop : [1199,1],
                            itemsDesktopSmall : [979,1],
                            itemsTablet: [768, 1],
                            itemsMobile: [479, 1],
                            slideSpeed:500,
                            paginationSpeed:1000,
                            rewindSpeed:1000,
                            autoHeight: false,
                            addClassActive: true,
                            autoPlay: false,
                            loop:true,
                            pagination: false
                        });
                        var $_parent = jQuery(this);
                        $_parent.parent().parent().find('.best_services-prev').click(function(){
                            $_parent.trigger('owl.prev');
                        }) ;
                        $_parent.parent().parent().find('.best_services-next').click(function(){
                            $_parent.trigger('owl.next');
                        }) ;
                    });
                });
            </script>
            <?php
            echo $after_widget;
        }

        public function form( $instance ){
            $instance = wp_parse_args( $instance, array(
                'title'       =>  '',
                'limit'        =>  '',
                'orderby'     =>  '',
                'order'         =>  ''
            ) );
            extract($instance);
            ?>
            <p>
                <label for="<?php echo $this -> get_field_id('title') ?>" >
                    <?php esc_html_e('Title','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('title') ; ?>" id="<?php echo $this -> get_field_id('title'); ?>" class="widefat" value="<?php echo esc_attr($title); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('limit') ?>">
                    <?php esc_html_e('Limit','noo-carle') ; ?>
                </label>
                <br>
                <input type="text" name="<?php echo $this -> get_field_name('limit') ; ?>" id="<?php echo $this -> get_field_id('limit'); ?>" class="widefat" value="<?php echo esc_attr($limit); ?>">
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('orderby') ?>">
                    <?php esc_html_e('Orderby','noo-carle') ; ?>
                </label>
                <br>
                <select id="<?php echo $this->get_field_id('orderby'); ?>" name="<?php echo $this->get_field_name('orderby'); ?>">
                    <option value="date" <?php echo selected(esc_attr($orderby),'date', false); ?>><?php echo esc_html__('Date','noo-carle'); ?></option>
                    <option value="title" <?php echo selected(esc_attr($orderby),'title', false); ?>><?php echo esc_html__('Title','noo-carle'); ?></option>
                    <option value="id" <?php echo selected(esc_attr($orderby),'id', false); ?>><?php echo esc_html__('ID','noo-carle'); ?></option>
                </select>
            </p>
            <p>
                <label for="<?php echo $this -> get_field_id('order') ?>">
                    <?php esc_html_e('Order','noo-carle') ; ?>
                </label>
                <br>
                <select id="<?php echo $this->get_field_id('order'); ?>" name="<?php echo $this->get_field_name('order'); ?>">
                    <option value="desc" <?php echo selected(esc_attr($order),'desc', false); ?>><?php echo esc_html__('DESC','noo-carle'); ?></option>
                    <option value="asc" <?php echo selected(esc_attr($order),'asc', false); ?>><?php echo esc_html__('ASC','noo-carle'); ?></option>
                </select>
            </p>
        <?php
        }
        // method update
        public function update( $new_instance, $old_instance ){
            $instance                 =   $old_instance;
            $instance['title']     =   ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : ''  ;
            $instance['limit']       =   ( ! empty( $new_instance['limit'] ) ) ? strip_tags( $new_instance['limit'] ) : ''  ;
            $instance['orderby']      =   ( ! empty( $new_instance['orderby'] ) ) ? strip_tags( $new_instance['orderby'] ) : ''  ;
            $instance['order']      =   ( ! empty( $new_instance['order'] ) ) ? strip_tags( $new_instance['order'] ) : ''  ;
            return $instance;
        }
    }
    register_widget('Noo_Best_Services');
endif;

