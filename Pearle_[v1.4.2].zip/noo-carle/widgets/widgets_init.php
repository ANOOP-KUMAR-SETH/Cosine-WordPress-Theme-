<?php
/**
 * This file initialize widgets area used in this theme.
 *
 *
 * @package    NOO Framework
 * @subpackage Widget Initiation
 * @version    1.0.0
 * @author     Kan Nguyen <khanhnq@nootheme.com>
 * @copyright  Copyright (c) 2014, NooTheme
 * @license    http://opensource.org/licenses/gpl-2.0.php GPL v2 or later
 * @link       http://nootheme.com
 */

if ( ! function_exists( 'noo_widgets_init' ) ) :

	function noo_widgets_init() {
		
		// Default Sidebar (WP main sidebar)
		register_sidebar( 
			array(  // 1
				'name' => esc_html__( 'Main Sidebar', 'noo-carle' ),
				'id' => 'sidebar-main', 
				'description' => esc_html__( 'Default Blog Sidebar.', 'noo-carle' ),
				'before_widget' => '<div id="%1$s" class="widget %2$s">', 
				'after_widget' => '</div>', 
				'before_title' => '<h4 class="widget-title">', 
				'after_title' => '</h4>' ) );

		 register_sidebar(
		 	array(
		 		'name' => esc_html__( 'Footer One Page', 'noo-carle' ),
		 		'id' => 'noo-footer-onepage',
		 		'description' => esc_html__( 'Ony display for template one page', 'noo-carle' ),
		 		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		 		'after_widget' => '</div>',
		 		'before_title' => '<h4 class="widget-title">',
		 		'after_title' => '</h4>' ) );

        register_sidebar(
		 	array(
		 		'name' => esc_html__( 'Services sidebar', 'noo-carle' ),
		 		'id' => 'noo-services-w',
		 		'description' => esc_html__( 'Ony display for single services', 'noo-carle' ),
		 		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		 		'after_widget' => '</div>',
		 		'before_title' => '<h4 class="widget-title">',
		 		'after_title' => '</h4>' ) );

		
		// Footer Columns (Widgetized)
		$num = ( noo_get_option( 'noo_footer_widgets' ) == '' ) ? 4 : noo_get_option( 'noo_footer_widgets' );
		for ( $i = 1; $i <= $num; $i++ ) :
			register_sidebar( 
				array( 
					'name' => __( 'NOO - Footer Column #', 'noo-carle' ) . $i,
					'id' => 'noo-footer-' . $i, 
					'before_widget' => '<div id="%1$s" class="widget %2$s">', 
					'after_widget' => '</div>', 
					'before_title' => '<h4 class="widget-title">', 
					'after_title' => '</h4>' ) );
		endfor
		;
	}
	add_action( 'widgets_init', 'noo_widgets_init' );

endif;
